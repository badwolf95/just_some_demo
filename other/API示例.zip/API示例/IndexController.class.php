<?php

namespace Service\Controller;

use Think\Controller;

class IndexController extends Controller{

	protected $SERVER_URL = 'http://app.all-wifi.cn/';
	//protected $SERVER_URL = 'http://localhost:83/wifi/';
	protected $UPLOAD_PATH = 'Uploads/admin/image/';
	//微信登录
	protected $AppID = 'wx29ff183f17dcca27';
	protected $AppSecret = '65469e67af235b2693a1310e047eda6b';
	private $IS_LOG = '';             

	public function __construct(){
		parent::__construct();
		$this->IS_LOG = true;
	
	}

    public function index(){

    	$sid = session('allWifiAdminId');
        //判断用户是否登陆
        if(!isset($sid)) {
            redirect($this->SERVER_URL.'admin.php/Login');
        }

		$actions	= I('actions');


		$input['getauthcode'] = array(
									'field'=> array('u_Phone','encodestr'),
									'note' => '1.短信验证码'
							);  
		$input['checkMobile'] = array(
									'field'=> array('u_Phone','code','encodestr'),
									'note' => '2.用户登录'
							); 
		$input['getUserInfo'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '3.获取用户个人信息（等级、积分)'
							); 
		$input['pointlist'] = array(
									'field'=> array('u_Phone','u_Session','currentPage','encodestr'),
									'note' => '4.积分列表'
							); 
		$input['mychange'] = array(
									'field'=> array('u_Phone','u_Session','currentPage','use_state','encodestr'),
									'note' => '5.我的兑换记录'
							); 
		$input['signIn'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '6.签到'
							);
		$input['chageheadimage'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '7.更换头像'
							);
		$input['getheadimage'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '8.获取头像'
							);
		$input['address'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '9.获取收货地址'
							);
		$input['setAddress'] = array(
									'field'=> array('u_Phone','u_Session','areaname','order_address','order_name','order_phone','encodestr'),
									'note' => '10.新增/修改收货地址'
							);
		$input['routemap'] = array(
									'field'=> array('u_Phone','u_Session','lng','lat','distance','encodestr'),
									'note' => '11.附近热点'
							);
		// $input['delAddress'] = array(
		// 							'field'=> array('address_id','u_Session','encodestr'),
		// 							'note' => '12.删除收货地址'
		// 					);
		$input['getEmail'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '13.获取邮箱'
							);
		$input['bindmail'] = array(
									'field'=> array('u_Phone','u_Session','email','encodestr'),
									'note' => '14.绑定邮箱'
							);
		$input['emailcode'] = array(
									'field'=> array('u_Phone','u_Session','email','encodestr'),
									'note' => '15.发送邮箱验证码'
						);
		$input['feedback'] = array(
									'field'=> array('u_Phone','u_Session','content','encodestr'),
									'note' => '16.意见反馈'
						);
		$input['saveFlow'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '17.已节省流量'
						);
		$input['hotPut'] = array(
									'field'=> array('u_Phone','u_Session','u_Mac','encodestr'),
									'note' => '18.allwifi热点放行接口'
						);
		$input['getuserToken'] = array(
									'field'=> array('user_id','u_Session','encodestr'),
									'note' => '19.获取token (需调用第三方api)'
						);
		$input['refreshUserInfo'] = array(
									'field'=> array('u_Phone','u_Session','userName','personal_sign','gender','encodestr'),
									'note' => '20.更新用户信息(需调用第三方api)'
						);
		$input['addFriend'] = array(
									'field'=> array('u_Phone','u_Session','targetUphone','message','encodestr'),
									'note' => '21.发送好友添加信息(需调用第三方api)'
						);
		$input['getFriendsList'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '22.获取好友列表(需调用第三方api)'
						);
		$input['send_id'] = array(
									'field'=> array('user_id','userName','userPortrait'),
									'note' => '23.测试发送'
						);
		$input['createGroup'] = array(
									'field'=> array('u_Phone','u_Session','group_id','groupname','group_portrait','group_notice','encodestr'),
									'note' => '24.创建/编辑群(需调用第三方api)'
						);
		$input['getGroup'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '25.获取群组列表(先获取后同步)'
						);
		$input['addFriendCallBack'] = array(
									'field'=> array('u_Phone','u_Session','targetId','callback_type','message','encodestr'),
									'note' => '26.接受/拒绝好友(需调用第三方api)'
						);
		$input['getFriendsAddList'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '27.IM 获取好友请求列表'
						);
		$input['joinGroup'] = array(
									'field'=> array('u_Phone','u_Session','group_id','message','encodestr'),
									'note' => '28.IM 加入群组'
						);
		$input['update_id'] = array(
									'field'=> array('user_id','userName','userPortrait'),
									'note' => '29.更新测试id'
						);
		$input['deleteFriend'] = array(
									'field'=> array('u_Phone','u_Session','targetId','encodestr'),
									'note' => '30.IM 删除好友'
				);
		$input['getGroupMemberInfo'] = array(
									'field'=> array('u_Phone','u_Session',' group_id','request_type','encodestr'),
									'note' => '31.IM 获取群成员列表'
		);
		$input['joinGroupCallBack'] = array(
									'field'=> array('u_Phone','u_Session','targetId','group_id','callback_type','message','encodestr'),
									'note' => '32.IM 回复申请加入群主的请求'
		);
		$input['joinGroupList'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '33.IM 获取进群请求(需调用第三方api)'
		);
		$input['createRoom'] = array(
									'field'=> array('id'),
									'note' => '34.IM 发送创建聊天室(需调用第三方api)'
		);
		$input['getChatRoomList'] = array(
									'field'=> array('u_Phone','u_Session','encodestr'),
									'note' => '35.IM 获取聊天室(需调用第三方api)'
		);
		$input['joinChatRoom'] = array(
									'field'=> array('u_Phone','u_Session','chatroom_id','encodestr'),
									'note' => '36.IM 加入聊天室(需调用第三方api)'
		);
		$input['getChatRoomUser'] = array(
									'field'=> array('u_Phone','u_Session','chatroom_id','encodestr'),
									'note' => '37.IM 获取聊天室成员(需调用第三方api)'
		);
		$input['friendsNameRemark'] = array(
									'field'=> array('u_Phone','u_Session','targetId','remarkName','encodestr'),
									'note' => '38.IM 好友备注(需调用第三方api)'
		);
		$input['groupOwnerKick'] = array(
									'field'=> array('u_Phone','u_Session','targetId','groupId','message','encodestr'),
									'note' => '39.IM 群主踢人操作(需调用第三方api)'
		);
		$input['dimissGroup'] = array(
									'field'=> array('u_Phone','u_Session','groupId','message','encodestr'),
									'note' => '40.IM 解散群(需调用第三方api)'
		);
		$input['quitGroup'] = array(
									'field'=> array('u_Phone','u_Session','group_id','encodestr'),
									'note' => '41.IM 退出群(需调用第三方api)'
		);
		$input['getPersonInfo'] = array(
									'field'=> array('u_Phone','u_Session','targetId','encodestr'),
									'note' => '42.IM 获取用户信息'
		);
		$input['reportData'] = array(
									'field'=> array('usermac','apmac','ssid','brand','strength','status','remark','chain','longitude','latitude','position','encodestr'),
									'note' => '43.IM 上报数据'
		);
		$input['getData'] = array(
									'field'=> array('usermac','encodestr'),
									'note' => '44.IM 取数据'
		);
		$input['getwechat_access_token'] = array(
									'field'=> array('code','grant_type','encodestr'),
									'note' => '45.微信登录获取access_token (需调用第三方api)'
		);
		$input['unionidBindPhone'] = array(
									'field'=> array('u_Phone','code','unionid','userName','headimgurl','gender','encodestr'),
									'note' => '46.微信unionid 绑定手机号'
		);




		//接口字段
        $this->assign('input', $input[$actions]['field']);
        //总接口
		$this->assign('inputArr', $input);
		//方法
        $this->assign('actions', $actions);
		$this->display();
    }


	

	//1.获取验证码
    public function getauthcode(){
		$u_Phone = I('post.u_Phone','','trim');
		$salt  =	"action_getcode";
		$encodestr = I('post.encodestr');
		
		
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$map['telephone'] = $u_Phone;

	

		//发送短信，新增短信表
		if (md5(md5($u_Phone.$salt)) != $encodestr){
			$result['errcode']='1';
			$result['data']="校验失败！";
			$this->ajaxReturn($result,"JSON");			
		}

		$telchk = M('verification')->where($map)->find();
		$data['code'] = $this->randstr(6,'num');
		$data['lastrequesttime'] = time();

		if ($telchk){
			// if (time() - $telchk['lastrequesttime'] < 10){
			// 	$result['errcode']='1';
			// 	$result['data']='您的请求过于频繁，请稍后重试';
			// 	$this->ajaxReturn($result,"JSON");	
			// }
			//更新验证码
			M('verification')->where($map)->save($data);
		}else{
			//新增
			$data['telephone'] = $u_Phone;
			M('verification')->add($data);
		}		


			//执行短信发送操作
		if(curl_sentSMS($u_Phone,$data['code'])){
			$result['errcode']='0';
			$result['data']='验证码发送成功!';
		}else{
			$result['errcode']='1';
			$result['data']='短信发送失败';
				
		}		
		$this->ajaxReturn($result,"JSON");

		
		
		
		
    }
	



    //2.用户登陆
    public function checkMobile(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$code = I('post.code','','trim');
		$salt  =	"action_login";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

		//验证
		if (md5(md5($u_Phone.$code.$salt))!=$encodestr){
			$result['errcode']='1';
			$result['data']= '校验失败';
			$this->ajaxReturn($result,"JSON");			
		}else{
			$User = M('user');
			$one = $User->field('user_id,phone,email,username,img,ry_token,sex AS gender,personal_sign')->where($map)->find();
			if(empty($one)){

				//判断验证码是否正确
				$verifyCode = M('verification')->where('telephone='.$u_Phone)->getField('code');
				if($code != $verifyCode){
					$result['errcode']='1';
					$result['data']= '验证码不正确';
					$this->ajaxReturn($result,"JSON");	
				}

				//新增用户
				$data['phone'] = $u_Phone;
				$data['sex'] = 1;
				$data['username'] = substr_replace($u_Phone,'****',3,4);
				$data['level'] = 1;
				$data['img'] = 'noface.jpg';
				$data['time'] = time();
				$data['point'] = 0;
				$uid = $User->add($data);
				if(!empty($uid)){
					$u_Session=md5(md5($u_Phone.time()));



					//获取token
					$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
					$portraitUri = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$data['img'];
					$ret = $p->getToken($uid,$data['username'],$portraitUri);
					$ret = json_decode($ret);


					$result['errcode']='0';
					$result['data'][] = array('u_Session'=>$u_Session,'email'=>'unbind','ry_token'=>$ret->token);

					//前台生成session
					$one = array('user_id'=>$uid,'phone'=>$u_Phone);
					session('wifi_user',$one);


		    		//ry_token存入数据库
		    		if(!$User->where($map)->setField('ry_token',$ret->token)){
		    			$result['errcode']= 1;
						$result['data']= '服务器繁忙';
		    		}
				


				}else{
					$result['errcode']='1';
					$result['data']= '操作繁忙！';
				}
			}else{

				//判断验证码是否正确
				$verifyCode = M('verification')->where('telephone='.$u_Phone)->getField('code');
				//判断验证码是否失效
				// if($verifyCode == '****'){
				// 	$result['errcode']='1';
				// 	$result['data']= "验证码已失效";
				// 	$this->ajaxReturn($result,"JSON");
				// }


				if($code != $verifyCode){
					$result['errcode']='1';
					$result['data']= "验证码不正确";
					$this->ajaxReturn($result,"JSON");	
				}

				$u_Session=md5(md5($u_Phone.time()));



				//获取token
				if(empty($one['ry_token'])){
					$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
					$portraitUri = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$one['img'];
					$ret = $p->getToken($one['user_id'],$one['username'],$portraitUri);
					$ret = json_decode($ret);
		    		//ry_token存入数据库
		    		if(!$User->where($map)->setField('ry_token',$ret->token)){
		    			$result['errcode']= 1;
						$result['data']= '服务器繁忙';
		    		}

					$ry_token = $ret->token;
				}else{
					$ry_token = $one['ry_token'];
				}


				$result['errcode']='0';
				$user_id = !empty($one['user_id']) ? $one['user_id'] : $uid;
				$gender = !empty($one['gender']) ?  $one['gender'] : $data['sex'];
				$personal_sign = !empty($one['personal_sign']) ?  $one['personal_sign'] : '';
				$u_name = !empty($one['username']) ?  $one['username'] : $data['username'];
				$email = !empty($one['email']) ?  $one['email'] : 'unbind';
				$u_portrait = !empty($one['img']) ?  $one['img'] : $data['img'];
				$u_portrait =  $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$u_portrait;

				$result['data'][] = array(
					'user_id'=>$user_id,
					'u_phone'=>$u_Phone,
					'gender'=>$gender,
					'u_portrait'=>$u_portrait,
					'u_name'=>$u_name,
					'u_Session'=>$u_Session,
					'email'=>$email,
					'ry_token'=>$ry_token,
					'personal_sign'=>$personal_sign
					);


				//前台生成session
				session('wifi_user',$one);


			}

			//登录成功后修改验证码，防止下次可继续登录
			//M('verification')->where('telephone='.$u_Phone)->setField('code','****');
			//存储接口session
		 	$one =M('user')->where('phone='.$u_Phone)->setField('session',$u_Session);
			$this->ajaxReturn($result,"JSON");	
		}
		
    }



    	
    //3.获取用户个人信息（等级、积分）
    public function getUserInfo(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
		$salt  =	"action_nearap";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

		
		//验证u_session是否正确
		$this->checkSession();

		//验证
		if (md5(md5($u_Phone.$u_Session.$salt))!=$encodestr){
			$result['errcode']='1';
			$result['data']="校验失败！";
			$this->ajaxReturn($result,"JSON");			
		}


		



		$userInfo = M('user')->field('user_id,phone,level,point,img,img_time')->where($map)->find();
		//验证手机用户是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//今天
		$today = strtotime(date('Y-m-d', time()));

		//签到时间如果大于今天凌晨返回true
		$recordInfo =  M('record')->field('time')->where('user_id='.$userInfo['user_id'])->order('time desc')->find();
	
		$userInfo['sign'] = $recordInfo['time'] > $today ? 'true' : 'false';

		$userInfo['img'] = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$userInfo['img'];
		$result['errcode'] = '0';
		$result['data'][] = $userInfo;
		$this->ajaxReturn($result,"JSON");		
		
    }

    





    //4.我的积分列表
    public function pointlist(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
    	$currentPage = I('post.currentPage','0','trim');
		$salt  =	"action_point";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');



		//验证效验码
		if (md5(md5($u_Phone.$u_Session.$currentPage.$salt))!=$encodestr){
			$result['errcode']='1';
			$result['data']="校验失败！";
			$this->ajaxReturn($result,"JSON");			
		}

		//验证u_session是否正确
		$this->checkSession();

		


		$user_id = M('user')->where($map)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//获取积分列表
		$currentPage = $currentPage+1;
		$Record =  M('record');
        $list = $Record->field('record_id,point_id,ecoupon_id,record.value,record.time')->page($currentPage.',15')->where('user_id='.$user_id)->order('time desc')->select();


		if(empty($list)){
			$result['errcode']='0';
			$result['data']="积分列表为空";
		}else{
			
	        $Point = M('Point');
	        $Ecoupon = M('Ecoupon');
	        //筛选是积分奖励或者电子券兑换,筛选是领取还是兑换或者签到之类
	        foreach ($list as $key => $value) {
	        	//积分类型
	            if(!empty($value['point_id'])){
	                $pointInfo = M('Point')->field('name,mark')->where('point_id='.$value['point_id'])->find();
	                $list[$key]['name'] = $pointInfo['name'];
	                $pointInfo['mark'] = $pointInfo['mark'] == 1 ? '+' : '-';
	                $list[$key]['value'] = $pointInfo['mark'].$value['value'];
	                $strtime = $pointInfo['mark'] == '+' ? '领取日期 ' : '使用日期 ';

	            }else{
	            	//兑换类型
	                $ecouponInfo = M('Ecoupon')->field('name')->where('ecoupon_id='.$value['ecoupon_id'])->find();
	                $list[$key]['name'] = $ecouponInfo['name'];
	                $list[$key]['value'] = '-'.$value['value'];


	                $strtime = '兑换日期 ';
	               
	            }



	      
	            unset($list[$key]['point_id']);
	            unset($list[$key]['ecoupon_id']);
	            $list[$key]['time'] = $strtime.date('Y.m.d',$value['time']);
	        }
				$result['errcode'] = '0';
				$result['data'] = $list;
			}
			$this->ajaxReturn($result,"JSON");	
    }








    //5.我的兑换记录
    public function mychange(){

		$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$currentPage = I('post.currentPage','0','trim');
		$use_state = I('post.use_state','','trim');
		$salt  =	"action_change";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'手机号码不能为空');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($use_state,'邮箱不能为空');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

	
		//验证效验码
		$password = md5(md5($u_Phone.$u_Session.$currentPage.$use_state.$salt));
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$currentPage.$use_state.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}

		//验证u_session是否正确
		$this->checkSession();


		$User = M('user');
		$userInfo = $User->field('user_id')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

	





		//筛选数据
		
		$where['exchange.user_id'] = $userInfo['user_id'];
		$where['exchange.use_state'] = $use_state;
		//已使用
        if($where['exchange.use_state'] == 2){
            $field = 'exchange.exchange_id AS exchange_id,
            			exchange.ems_code,
            			exchange.address AS exchange_address, 
            			ecoupon.address AS ecoupon_address,
            			exchange.delivery_state,
            			ecoupon.image AS image,
            			ecoupon.type AS type';
        }else{
            //未使用或已作废
            $field = 'exchange.exchange_id AS exchange_id,
            			exchange.gift_code,
            			ecoupon.image AS image,
            			ecoupon.start_expire AS start_expire,
            			ecoupon.end_expire AS end_expire,
            			ecoupon.type AS type';
        }
       	$currentPage = $currentPage+1;
		$list = M('Exchange')->field($field)->join('LEFT JOIN ecoupon ON exchange.ecoupon_id=ecoupon.ecoupon_id')->page($currentPage.',5')->where($where)->order('exchange.exchange_id DESC')->select();





		if(!empty($list)){
			foreach ($list as $key => $value) {


	            //判断有效期，可使用过期变为已报废
	            $time = time();
				if(($where['exchange.use_state'] == 1) && ($time > $value['end_expire'])){
					M('Exchange')->where('exchange_id='.$value['exchange_id'])->setField('use_state',3);
					unset($list[$key]);
					
				}else{
					$list[$key]['image'] =  $this->SERVER_URL.$this->UPLOAD_PATH.'ecoupon/'.$value['image'];
            	 	$value['start_expire'] && $list[$key]['start_expire'] = date("Y.m.d",$value['start_expire']);
            	 	$value['end_expire'] && $list[$key]['end_expire'] = date("Y.m.d",$value['end_expire']);
					//地址
					if($value['type'] == 3){
						if($where['exchange.use_state'] == 2){
							//实物券收货地址
							$list[$key]['address'] = $value['exchange_address'];
						}else{
							//电子券使用地址
							$list[$key]['address'] = $value['ecoupon_address'];
						}
					}

                    
				}
	            //清除多余字段
				unset($list[$key]['type']);
				unset($list[$key]['exchange_address']);
				unset($list[$key]['ecoupon_address']);
					
        	}

			$result['errcode']='0';
			$result['data'] = $list;
		}else{
			$result['errcode']='0';
			$result['data']="兑换列表为空";
			
		}
		$this->ajaxReturn($result,"JSON");	
	}



    




	//6.签到
    public function signIn(){
    	$u_Phone = I('post.u_Phone','','trim');
        $u_Session = I('post.u_Session');
		$salt  =	"action_feedback";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

		//验证效验码
		if (md5(md5($u_Phone.$u_Session.$salt))!=$encodestr){
			$result['errcode']='1';
			$result['data']="校验失败！";
			$this->ajaxReturn($result,"JSON");			
		}


		//验证u_session是否正确
		$this->checkSession();
		
		$user_id = M('user')->where($map)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		$where['name'] = '签到奖励';
		$pointInfo = M('point')->field('point_id,value')->where($where)->find();

		//签到一天只能一次判断
        $recordWhere['user_id'] = $user_id;
        $recordWhere['point_id'] =  $pointInfo['point_id'];
        $Record = M('Record');
        $recordInfo = $Record->field('time')->where($recordWhere)->order('time desc')->limit(1)->select();

        //获取当天的年份
        $y = date("Y");
        //获取当天的月份
        $m = date("m");
        //获取当天的号数
        $d = date("d");
        //将今天开始的年月日时分秒，转换成unix时间戳(开始示例：2015-10-12 00:00:00)
        $todayTime= mktime(0,0,0,$m,$d,$y);
        if($recordInfo[0]['time'] > $todayTime){
            $result['errcode']='1';
            $result['data']="一天只能签到一次";
            $this->ajaxReturn($result,"JSON");  
        }

		/*等级计算，待~*/


		//更新用户积分
		$rows = M('user')->where($map)->setInc('point',$pointInfo['value']);
		if(!empty($rows)){
			//新增纪录表
			$data['user_id'] = $user_id;
			$data['point_id'] = $pointInfo['point_id'];
			$data['value'] = $pointInfo['value'];
			$data['time'] = time();
			if($Record->add($data)){
				$result['errcode']='0';
				$result['data']="签到成功";
			}else{
				$result['errcode']='1';
				$result['data']="操作繁忙";
			}
		}else{
			$result['errcode']='1';
			$result['data']="操作繁忙";

		}
		$this->ajaxReturn($result,"JSON");	

    }


    







    //7.更换头像
    public function chageheadimage(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
		$salt  =	"action_headimage";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

		//验证效验码
		if (md5(md5($u_Phone.$u_Session.$salt))!=$encodestr){
			$result['errcode']='1';
			$result['data']=md5(md5($u_Phone.$u_Session.$salt));
			$this->ajaxReturn($result,"JSON");			
		}



		//验证u_session是否正确
		$this->checkSession();
		

		$User = M('user');
		$userInfo = $User->field('user_id,username,img')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo['user_id']){
			$this->errorReturn('不存在该用户');
				
		}




		//文件上传地址提交给他，并且上传完成之后返回一个信息，让其写入数据库
        if (empty($_FILES)) {
            $result['errcode'] = '1';
            $result['data'] = '必须选择上传文件';
            $this->ajaxReturn($result, 'JSON');
        } else {
        	$filePath = 'admin/image/user/';
            $a = $this->up($filePath);
            $data['img'] = $a['savename'];
            $data['img_time'] = time();
            if (isset($a)) {
                //写入数据库的自定义c方法
				if($User->where('user_id='.$userInfo['user_id'])->save($data)){


					//群成员更新头像
					$memberMap['phone'] = $u_Phone;
					if(M('Groupmember')->where($memberMap)->setField('img',$data['img']) === false){
						$this->errorReturn('群成员头像更新失败');
					}

					//群主创建人头像
					$groupMap['phone'] = $u_Phone;
					if(M('Usergroup')->where($groupMap)->setField('img',$data['img']) === false){
						$this->errorReturn('群主头像更新失败');
					}




					$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
					$portraitUri = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$data['img'];
				    $ret = $p->userRefresh($userInfo['user_id'],$userInfo['username'],$portraitUri);
				    $ret = json_decode($ret);
				    if($ret->code == 200){
				        $result['errcode']= 0;
						$result['data']= '上传成功';
						$this->ajaxReturn($result,"JSON");	
				    }else{
				        $this->errorReturn($ret->code);
				    }

                } else {
                	$this->errorReturn('写入数据库失败');
              
                }
            } else {
            	$this->errorReturn('上传文件异常，请与系统管理员联系');
          
            }
        }

		
		


    }






    //8.获取头像
    public function getheadimage(){
    	$u_Phone = I('post.u_Phone','','trim');
      	$u_Session = I('post.u_Session');
		$salt  =	"action_headimage";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

		//验证效验码
		if (md5(md5($u_Phone.$u_Session.$salt))!=$encodestr){
			$result['errcode']='1';
			$result['data']=md5(md5($u_Phone.$u_Session.$salt));
			$this->ajaxReturn($result,"JSON");			
		}



		//验证u_session是否正确
		$this->checkSession();
		

		$User = M('user');
		$userInfo = $User->field('img,img_time')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//更新头像
		if(!empty($userInfo['img'])){
			$img = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$userInfo['img'];
			$result['errcode'] = '0';
			// $result['data']['img'] = $img;
			// $result['data']['img_time'] = $userInfo['img_time'];
			$result['data'][] = array('img'=>$img,'img_time'=>$userInfo['img_time']);
		}else{
			$result['errcode']='0';
			$result['data']="头像为空";
		}

		$this->ajaxReturn($result,"JSON");		
    }



    //9.获取收货地址
    public function address(){
    	$u_Phone = I('post.u_Phone','','trim');
      	$u_Session = I('post.u_Session');
    	$salt  =	"action_address";
		$encodestr = I('post.encodestr');

		$this->checkNull($u_Phone,'电话号码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');

		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}



		//验证u_session是否正确
		$this->checkSession();
		

		$User = M('user');
		$user_id = $User->where('phone='.$u_Phone)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		$one = M('address')->where('user_id='.$user_id)->find();
		if(empty($one)){
			$result['errcode']='0';
			$result['data'] = "";
		 	$this->ajaxReturn($result,"JSON");
		 }
		$addressInfo = M('address')->field('areaname,address_id,order_address,order_phone,order_name')->where('address.user_id='.$user_id)->find();
	 	
		$result['errcode']='0';
	 	$result['data'][] = $addressInfo;
	
		 $this->ajaxReturn($result,"JSON");
    }




    //10.新增/修改收货地址
    public function setAddress(){
    	$u_Phone = I('post.u_Phone','','trim');
      	$u_Session = I('post.u_Session');
      	$areaname = I('post.areaname','','trim');
      	$order_address = I('post.order_address','','trim');
      	$order_name = I('post.order_name','','trim');
    	$order_phone = I('post.order_phone','','trim');



		$salt  =	"action_setAddress";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($order_phone,'电话号码不能为空！');
		$this->checkNull($order_name,'收货人不能为空');
		$this->checkNull($order_address,'收货地址不能为空！');
		$this->checkNull($areaname,'收货省份不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkTel($order_phone,'收货人手机号码有误');


		$password = md5(md5($u_Phone.$u_Session.$areaname.$order_address.$order_name.$order_phone.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$areaname.$order_address.$order_name.$order_phone.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}




		//验证u_session是否正确
		$this->checkSession();
		
		$User = M('user');
		$user_id = $User->where($map)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		
		$Address = M('address');
		$data['areaname'] = $areaname;
		$data['order_name'] = $order_name;
		$data['order_address'] = $order_address;
		$data['user_id'] = $user_id;
		$data['order_phone'] = $order_phone;

		//判断是否已有收货地址，如果有，实行修改操作
		$address_id = $Address->where('user_id='.$user_id)->getField('address_id');
		//新增操作
		if(empty($address_id)){
			if(!$Address->add($data)){
				$result['errcode']='1';
				$result['data']="新增失败";
				$this->ajaxReturn($result,"JSON");	
			}
		}else{
			//修改操作
			if($Address->where('address_id='.$address_id)->save($data)){
				$result['errcode']='0';
				$result['data']='修改成功';
				$this->ajaxReturn($result,"JSON");	
			}
		}
		$result['errcode']='0';
		$result['data']="操作成功";
		$this->ajaxReturn($result,"JSON");	

    }



    //11.附近热点
    public function routemap(){
    	$u_Phone = I('post.u_Phone','','trim');
      	$u_Session = I('post.u_Session');
      	$lng = I('post.lng','','trim');
      	$lat = I('post.lat','','trim');
      	$distance = I('post.distance','','trim');



		$salt  =	"action_routemap";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($lng,'经度不能为空！');
		$this->checkNull($lat,'纬度不能为空');
		$this->checkNull($distance,'距离不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');


		$password = md5(md5($u_Phone.$u_Session.$lng.$lat.$distance.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}




		//验证u_session是否正确
		$this->checkSession();
		
		$User = M('user');
		$user_id = $User->where($map)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		$newArray = array();
		// $info = M('Routemap')->field('lng,lat')->where('state')->select();
		// foreach ($info as $key => $value) {
		// 	$new_distance = $this->getDistance($lat, $lng, $value['lat'], $value['lng']);
		// 	if($new_distance <= $distance){
		// 		$newArray[] = array('lat'=>$value['lat'],'lng'=>$value['lng']);
		// 	}
		// }


		$Model = M(); 
		$newArray = $Model->query("SELECT latitude,longitude FROM wlan_data 
		WHERE 
			ROUND(6378.138*2*ASIN(SQRT(POW(SIN(($lat*PI()/180-latitude*PI()/180)/2),2)+
											COS($lat*PI()/180)*COS(latitude*PI()/180)*POW(SIN(($lng*PI()/180-longitude*PI()/180)/2),2)))
											*1000) <= $distance GROUP BY name 
		");



		// $newArray = $Model->query("SELECT ROUND(6378.138*2*ASIN(SQRT(POW(SIN(($lat*PI()/180-lat*PI()/180)/2),2)+
		//  									COS($lat*PI()/180)*COS(lat*PI()/180)*POW(SIN(($lng*PI()/180-lng*PI()/180)/2),2)))
		//  									*1000) AS juli FROM routemap");



		$result['errcode']='0';
		$result['data']= $newArray;
		$this->ajaxReturn($result,"JSON");	

    }





   	//13.获取邮箱，判断状态（1未发送，已发送未激活，已激活）
    public function getEmail(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
		$salt  =	"action_getEmail";
		$encodestr = I('post.encodestr');
		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'手机号码不能为空');

		//验证效验码
		$password = md5(md5($u_Phone.$u_Session.$salt));
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}


		//验证u_session是否正确
		$this->checkSession();



		$User = M('user');
		$userInfo = $User->field('token,email')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		//判断邮箱状态
		if(empty($userInfo['token'])){
			$result['errcode']='0';
			$result['data']="邮箱未绑定";
		}else if(!empty($userInfo['token']) && empty($userInfo['email'])){
			$result['errcode']='0';
			$result['data']="邮箱未激活";
		}else{
			$result['errcode']='0';
			$result['data']= $userInfo['email'];
		}

		$this->ajaxReturn($result,"JSON");	




    }



	//14.绑定邮箱
	public function bindmail(){
		$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
		$email = I('post.email','','trim');
		$salt  =	"action_bindmail";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'手机号码不能为空');
		$this->checkNull($email,'邮箱不能为空');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkEmail($email,'邮箱格式不正确');
		$this->checkNull($u_Session,'用户登录不能为空！');
	
		//验证效验码
		$password = md5(md5($u_Phone.$u_Session.$email.$salt));
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$email.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}


		//验证u_session是否正确
		$this->checkSession();
		

		$User = M('user');
		$userInfo = $User->field('user_id,email')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		//验证是否已激活
		if($userInfo['email']){
			$result['errcode']='1';
			$result['data']="该用户邮箱已激活";
			$this->ajaxReturn($result,"JSON");		
		}

		
		//验证邮箱是否被占用
		$where['email'] = $email;
		$one = $User->where($where)->select();
		if($one){
			$result['errcode']='1';
			$result['data']= '该邮箱被占用或邮箱已绑定';
			$this->ajaxReturn($result,"JSON");		
		}

		$email_expire = time()+60*60*24;//过期时间为24小时后
		$token = urlencode(md5($email_expire)); //创建用于激活识别码


		$data['token'] = $token;
		$data['email_expire'] = $email_expire;

		$condition['user_id'] = $userInfo['user_id'];
		if($User->where($condition)->save($data)){//写入成功，发邮件

			$smtpserver = "smtp.163.com";//SMTP服务器
			$smtpserverport =25;//SMTP服务器端口
			$smtpusermail = "15960720920@163.com";//SMTP服务器的用户邮箱
			$smtpemailto = $email;//发送给谁
			$smtpuser = "15960720920@163.com";//SMTP服务器的用户帐号
			$smtppass = "zxc8282883";//SMTP服务器的用户密码
			$mailtitle = 'allwifi 用户邮箱激活';//邮件主题

			$mailcontent = "亲爱的".$u_Phone."：请点击链接激活您的邮箱。
							<br/><a href=".$this->SERVER_URL."Service.php?a=active&email=".$email."&token=".$token." target='_blank'>".$this->SERVER_URL."Service.php?a=active&email=".$email."&token=".$token."</a>
							<br/>如果以上链接无法点击，请将它复制到你的浏览器地址栏中刷新进入访问，该链接24小时内有效。<br/>如果此次激活请求非你本人所发，请忽略本邮件。
							<br/><p style='text-align:right'>-------- allwifi 敬上</p>";

			$mailtype = "HTML";//邮件格式（HTML/TXT）,TXT为文本邮件
			$smtp = new \Think\Smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);//这里面的一个true是表示使用身份验证,否则不使用身份验证.

			$smtp->debug = false;//是否显示发送的调试信息
			$state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailtitle, $mailcontent, $mailtype);

			if($state != ''){
				$msg = "恭喜您，注册成功！请登录到您的邮箱及时激活您的邮箱！";	
			}else{
				$msg = "对不起，邮件发送失败！请检查邮箱填写是否有误";	
			}
			$result['errcode']='0';
			$result['data']= $msg;
			$this->ajaxReturn($result,"JSON");		
		
		}else{
			$result['errcode']='1';
			$result['data']= '操作繁忙';
			$this->ajaxReturn($result,"JSON");		
		}

	}






	//激活
	public function active(){
		header('Content-Type:text/html;charset=utf-8');
		$token = I('get.token');
		$email = I('get.email');


		$User = M('user');
		$map['token'] = $token;
		//验证邮箱是否被占用
		$where['email'] = $email;
		if($User->where($where)->count()){
			echo "该邮箱被占用或邮箱已绑定";
			exit();		
		}


		//判断效验码是否正确
		$userInfo = $User->field('user_id,email_expire')->where($map)->find();
		if(empty($userInfo['email_expire'])){
			echo "该效验码无效";
			exit();	
		}

		//新增邮箱
		if(time() > $userInfo['email_expire']){
			echo "该链接已过期";
			exit();
		}


		$data['email'] = $email;
		if($User->where($map)->save($data)){
			/*绑定邮箱奖励*/
			//1.用户积分增加
			$condition['name'] = "绑定邮箱奖励";
			$pointInfo = M('point')->field('point_id,mark,value')->where($condition)->find();
			if($pointInfo['mark'] == '1'){
				//正
				if(!$User->where($map)->setInc('point',$pointInfo['value'])){
					echo "邮箱激活失败"	;
					exit();
				}
			}else{
				//负
				if(!$User->where($map)->setDec('point',$pointInfo['value'])){
					echo "邮箱激活失败"	;
					exit();
				}
			}
			



			//2.新增记录表
			$recordData['user_id'] = $userInfo['user_id'];
			$recordData['point_id'] = $pointInfo['point_id'];
			$recordData['value'] = $pointInfo['value'];
			$recordData['time'] = time();
			if(M('record')->data($recordData)->add()){
				echo "邮箱激活成功"	;
				exit();
			}
			echo "邮箱激活失败"	;
			exit();
		}else{
			echo "邮箱激活失败"	;
		}


	}





	//15.发送邮箱验证码
	public function emailcode(){
		$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
		$email = I('post.email','','trim');
		$salt  =	"action_code";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'手机号码不能为空');
		$this->checkNull($email,'邮箱不能为空');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkEmail($email,'邮箱格式不正确');
		$this->checkNull($u_Session,'用户登录不能为空！');
	
		//验证效验码
		$password = md5(md5($u_Phone.$u_Session.$email.$salt));
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$email.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}


		//验证u_session是否正确
		$this->checkSession();
		
		$User = M('user');
		$userInfo = $User->field('user_id')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

	
	


		$data['mailcode'] = $this->randstr();

		$condition['user_id'] = $userInfo['user_id'];
		if($User->where($condition)->save($data)){//写入成功，发邮件

			$smtpserver = "smtp.163.com";//SMTP服务器
			$smtpserverport =25;//SMTP服务器端口
			$smtpusermail = "15960720920@163.com";//SMTP服务器的用户邮箱
			$smtpemailto = $email;//发送给谁
			$smtpuser = "15960720920@163.com";//SMTP服务器的用户帐号
			$smtppass = "zxc8282883";//SMTP服务器的用户密码
			$mailtitle = 'allwifi 邮箱验证码';//邮件主题

			$mailcontent = "亲爱的".$u_Phone."：<br/>您的邮箱验证码为".$data['mailcode'];

			$mailtype = "HTML";//邮件格式（HTML/TXT）,TXT为文本邮件
			$smtp = new \Think\Smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);//这里面的一个true是表示使用身份验证,否则不使用身份验证.

			$smtp->debug = false;//是否显示发送的调试信息
			$state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailtitle, $mailcontent, $mailtype);

			if($state != ''){
				$msg = "邮箱验证码发送成功";	
			}else{
				$msg = "邮箱验证码发送失败";	
			}
			$result['errcode']='0';
			$result['data'][]= array('mailcode'=>$data['mailcode']);
			$this->ajaxReturn($result,"JSON");		
		
		}else{
			$result['errcode']='1';
			$result['data']= '操作繁忙';
			$this->ajaxReturn($result,"JSON");		
		}

	}







	//16.意见反馈
	public function feedback(){
		$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session');
		$content = I('post.content');
		$salt  =	"action_feedback";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Phone,'手机号码不能为空');
		$this->checkNull($content,'内容不能为空');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');

	
		//验证效验码
		$password = md5(md5($u_Phone.$u_Session.$content.$salt));
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$content.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}



		//验证u_session是否正确
		$this->checkSession();
		
		$User = M('user');
		$userInfo = $User->field('user_id')->where($map)->find();
		//验证手机是否存在
		if(!$userInfo){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->print_log('',$result['data'],ACTION_NAME);
			$this->ajaxReturn($result,"JSON");		
		}

		$Feedback = M('feedback');
		$data['user_id'] = $userInfo['user_id'];
		$data['content'] = $content;
		$data['time'] = time();


		$Feedback  = M('feedback');

		$fb = $Feedback->field('time')->where('user_id='.$userInfo['user_id'])->order('time desc')->limit(1)->select();
		$interval = time() - $fb[0]['time'];
		if($interval < 10){
			$result['errcode']='1';
			$result['data']= '请不要频繁提交';
			$this->ajaxReturn($result,"JSON");	
		}
		if($Feedback ->add($data)){
			$result['errcode']='0';
			$result['data']="反馈成功";
		}else{
			$result['errcode']='1';
			$result['data']="操作繁忙";
				
		}
		$this->ajaxReturn($result,"JSON");		

	
	


	}




	//17.已节省流量接口
    public function saveFlow(){
    	$u_Phone = I('post.u_Phone','','trim');
      	$u_Session = I('post.u_Session');
		$salt  =	"action_flow";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');


		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}




		//验证u_session是否正确
		$this->checkSession();
		
		$User = M('user');
		$user_id = $User->where($map)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		$arr = M("online","ns_","mysql://radius:ds549gGF32fdkk2Ter675wiyi23de5@112.5.16.68:3306/portal")
					->query("SELECT SUM(inputoctets + outputoctets) AS total FROM ns_online WHERE username='{$map['phone']}'");

		$result['errcode']='0';
		if(!empty($arr[0]['total'])){
			$result['data']['u_flow'] = $arr[0]['total']/8/1024/1024;
		}else{
			$result['data']['u_flow'] = 0;
		}
		
		$this->ajaxReturn($result,"JSON");	

    }	





	//18.allwifi热点放行接口
    public function hotPut(){
    	$u_Phone = I('post.u_Phone','','trim');
      	$u_Session = I('post.u_Session');
      	//物理地址
      	$u_Mac = I('post.u_Mac');
		$salt  =	"action_flow";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($u_Session,'用户登录不能为空！');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');


		$password = md5(md5($u_Phone.$u_Session.$u_Mac.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $u_Phone.$u_Session.$u_Mac.$salt.'/'.$password;
			$this->ajaxReturn($result,"JSON");					
		}




		//验证u_session是否正确
		$this->checkSession();
		
		$User = M('user');
		$user_id = $User->where($map)->getField('user_id');
		//验证手机是否存在
		if(!$user_id){
			$result['errcode']='1';
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//获取账号密码
		$arr = M("online","ns_","mysql://radius:ds549gGF32fdkk2Ter675wiyi23de5@112.5.16.68:3306/portal")
					->query("SELECT username,password  FROM ns_user WHERE mac='{$u_Mac}'  LIMIT 1");
		


		//模拟发送
		$url = 'http://112.5.16.68:8082/cgi-bin/index.cgi';
		$data['username'] =18750590730;
		$data['userpasswd'] =3679;

		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt ( $ch, CURLOPT_POST, 1 );
		curl_setopt ( $ch, CURLOPT_HEADER, 0 );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
		$return = curl_exec ( $ch );
		curl_close ( $ch );
		 
	
		// $result['errcode']='1';
		// $result['data']=$return;
		// $this->ajaxReturn($result,"JSON");	
		// $result['errcode']='0';
		// $result['data']['access_Open']='';
		// $this->ajaxReturn($result,"JSON");	
	

    }



	//19.获取token (需调用第三方api)
    public function getuserToken(){
    	$user_id = I('post.user_id','','trim');
    	$u_Session = I('post.u_Session'); 
		$salt  =	"action_getToken";
		$encodestr = I('post.encodestr');

		$map['user_id'] = $user_id;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkNull($u_Session,'用户登录不能为空！');


		$password = md5(md5($user_id.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,phone,img,username,ry_token')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

	

		//token已经存在直接返回
		if(!empty($info['ry_token'])){
        	$result['errcode']= 0;
			$result['data']['ry_token']= $info['ry_token'];
			$this->ajaxReturn($result,"JSON");	
		}

      

		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$portraitUri = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$info['img'];
	    $ret = $p->getToken($info['user_id'],$info['username'],$portraitUri);
	    if(empty($ret)){
	        	$result['errcode']= 1;
				$result['data']= '非法操作！';
	    }else{
	    		$ret = json_decode($ret);

	    		//token存入数据库
	    		if(!$User->where($map)->setField('ry_token',$ret->token)){
	    			$result['errcode']= 1;
					$result['data']= '服务器繁忙';
	    		}


	        	$result['errcode']= 0;
				$result['data']['ry_token']= $ret->token;
	    }
	           
	      $this->ajaxReturn($result,"JSON");		

    }



  	//20.更新用户信息 (需调用第三方api)
    public function refreshUserInfo(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session'); 
        $userName = I('post.userName','','trim');
        $personal_sign = I('post.personal_sign','','trim');
        $gender = I('post.gender','','trim');

		$salt  =	"action_refreshUserInfo";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($userName,'用户名不能为空');
		$this->checkNull($gender,'性别不能为空');
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');


		$password = md5(md5($u_Phone.$u_Session.$userName.$personal_sign.$gender.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$this->errorReturn($password);				
		}

		//验证u_session是否正确
		$this->checkSession();

		
		$User = M('user');
		$info = $User->field('user_id,phone,img,username,personal_sign,sex')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$this->errorReturn("不存在该用户");
		}


		if(($gender!=1) && ($gender!=2)){
	
			$this->errorReturn("非法操作");
			
		}



		//如果数据没变就不更新
		if(($userName == $info['username']) && ($personal_sign == $info['personal_sign']) && ($gender == $info['sex'])){
			$result['errcode']= 0;
			$result['data']= 'success';
			$this->ajaxReturn($result,"JSON");
		}
	





		//更新信息
		$data['username'] = $userName;
		$data['personal_sign'] = $personal_sign;
		$data['sex'] = $gender;
		if($User->where($map)->save($data) === false){
			$this->errorReturn("操作繁忙");
		
		}


		//群成员更新头像
		$memberMap['phone'] = $u_Phone;
		if(M('Groupmember')->where($memberMap)->setField('username',$userName) === false){
			$this->errorReturn('群成员名称更新失败');
		}

		//群主创建人头像
		$groupMap['phone'] = $u_Phone;
		if(M('Usergroup')->where($groupMap)->setField('username',$userName) === false){
			$this->errorReturn('群组名称更新失败');
		}






		$portraitUri = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$info['img'];
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
	    $ret = $p->userRefresh($info['user_id'],$userName,$portraitUri);
	    $ret = json_decode($ret);
	    if($ret->code == 200){
	        $result['errcode']= 0;
			$result['data']= 'success';
			$this->ajaxReturn($result,"JSON");	
	    }else{
	        $this->errorReturn($ret->code);
	    }
	           
	     	

    }



  	//21.发送添加好友信息 (需调用第三方api)
    public function addFriend(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session'); 
    	//对方ID， 不是手机号码
        $targetUphone = I('post.targetUphone','','trim');
        $message = I('post.message','','trim');

		$salt  =	"action_addFriend";
		$encodestr = I('post.encodestr');

		
	
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		//$this->checkTel($targetUphone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');


		
		//验证u_session是否正确
		$this->checkSession();


		$password = md5(md5($u_Phone.$u_Session.$targetUphone.$message.$salt));
		//验证效验码
		if ($password !=$encodestr){

			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}

	

		$sendMap['phone'] = $u_Phone;
		$recMap['user_id'] = $targetUphone;
			
		$User = M('user');
		$s_info = $User->field('user_id,username')->where($sendMap)->find();
		$r_info = $User->field('user_id,username,phone')->where($recMap)->find();


		
		//验证手机是否存在
		if(empty($s_info) || empty($r_info)){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}



		if($u_Phone == $r_info['phone']){
			$result['errcode']='1';			
			$result['data']=  '不能添加自己为好友';
			$this->ajaxReturn($result,"JSON");	
		}



		//查询是否已经为好友
		if($this->check_is_friend($s_info['user_id'],$r_info['user_id'])){
			$result['errcode']= 1;
			$result['data']="对方已是您的好友";
			$this->ajaxReturn($result,"JSON");
		}

		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));


		//请求好友用6666，假ID作为系统
		//组装发送内容
		//$contentArr['operation'] = '好友请求';
		if(!empty($message)) $newmessage = '('.$message.')'; 
		$contentArr['content'] = $s_info['user_id'].'请求添加你为好友'.$newmessage;
		$contentArr['extra'] = 'asdsad';
		// $contentArr['sourceUserId'] = $list[0]['user_id'];
		// $contentArr['targetUserId'] = $list[1]['user_id'];
		$contentJson = json_encode($contentArr);

		$pushContent = $newmessage;
		$pushData['pushData'] =  $newmessage;
	
	
		$pushData = json_encode($pushData);
		$idArr = array($r_info['user_id']);
	    $ret = $p->messageSystemPublish(6666,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);
	    $ret = json_decode($ret);



	    if($ret->code == 200){
	    	/*新增消息表,只允许数据库里存在一条,先查表在新增，如果存在就更新内容和发送时间*/

	    	//查表
	    	$msgMap['send_id'] = $s_info['user_id'];
	    	$msgMap['rec_id'] = $r_info['user_id'];
	    	$FriendReqMsg = M('FriendReqMsg');
	    	$msgInfo = $FriendReqMsg->where($msgMap)->find();

	    	//存在更新
	    	if(!empty($msgInfo)){

	    
	    		$data['time'] = time();
	    		$data['status'] = 1;
	    		$data['message'] = $message;
	    		if($FriendReqMsg->where($msgMap)->save($data)){
	    			$result['errcode']= 0;
					$result['data']= 'success';
	    		}else{
	    			$result['errcode']= 1;
					$result['data']= '更新内容失败';
	    		}
	    	
				$this->ajaxReturn($result,"JSON");
	    	}


	    	//不存在新增
	    	$data['send_id'] = $s_info['user_id'];
	    	$data['rec_id'] = $r_info['user_id'];
	    	$data['time'] = time();
	    	$data['message'] = $message;
	    	$data['status'] = 1;
	    	if($FriendReqMsg->add($data)){
	    		$result['errcode']= 0;
				$result['data']= 'success';
	    	}else{
    			$result['errcode']= 1;
				$result['data']= '操作繁忙';
	    	}
	    }else{
	        
	    	$result['errcode']= 1;
			$result['data']= $ret;
	    }
	           
	      $this->ajaxReturn($result,"JSON");		

    }

    //验证是否也是好友
    protected function check_is_friend($left_id,$right_id){
    	$leftMap = array();
    	$leftMap['left_id'] = $left_id;
    	$leftMap['right_id'] = $right_id;
    	$rightMap = array();
    	$rightMap['left_id'] = $right_id; 
    	$rightMap['right_id'] = $left_id;
		$leftInfo = M('Friends')->where($leftMap)->find();
		$rightInfo = M('Friends')->where($rightMap)->find();
		if(!empty($leftInfo) || !empty($rightInfo)){
			return true;
		}
		return false;
    }


    //22.获取好友列表 (需调用第三方api)
    public function getFriendsList(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$salt = "action_getFriendsList";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();


		//获取好友
		$list = M('Friends')->alias('f')
							->field('u.user_id,u.username,u.img,u.phone,remark,u.personal_sign')
							->join('LEFT JOIN user u ON f.right_id=u.user_id')
							->where("left_id={$info['user_id']}")->select();


		if(empty($list)){
			$result['errcode']= 0;
			$result['data']= '好友列表为空';
			$this->ajaxReturn($result,"JSON");
		}


		foreach ($list as $key => $value) {
			

			if(empty($value['remark'])){
				$list[$key]['friendsNameRemark'] = '';
			}else{
				$list[$key]['friendsNameRemark'] = $value['remark'];
			}  
			

			if(empty($value['personal_sign'])) $list[$key]['personal_sign'] = '';
			
			unset($list[$key]['remark']);
			$list[$key]['userId'] = $value['user_id'];
			unset($list[$key]['user_id']);
			$list[$key]['userName'] = $value['username'];
			unset($list[$key]['username']);
			$list[$key]['userPortrait'] = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$value['img'];
			unset($list[$key]['img']);
		}

		




		//$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));

		//获取是否在线
		// foreach ($list as $key => $value) {
		// 	$ret = $p->userCheckOnline($value['fid']);
		// 	$ret = json_decode($ret);
	 //       	$list[$key]['isOnline'] = $ret->status;
		// }


	   
	        $result['errcode']= 0;
			$result['data']= $list;
	    
	           
	      $this->ajaxReturn($result,"JSON");		

    }


    //30.删除好友 
    public function deleteFriend(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$targetId = I('post.targetId'); 
		$salt = "action_deleteFriend";
		$encodestr = I('post.encodestr');

		$u_map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($targetId,'对方ID不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$targetId.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($u_map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();



		$t_map['user_id'] = $targetId;
		$t_info = $User->field('user_id,username')->where($t_map)->find();
		//验证目标用户是否存在
		if(!$t_info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}



		if($t_info['user_id'] == $info['user_id']){
			$result['errcode']= 1;
			$result['data']="不能删除自己";
			$this->ajaxReturn($result,"JSON");
		}





		//删除左好友表
		$Friends = M('Friends');
		$l_map['left_id'] = $info['user_id'];
		$l_map['right_id'] = $t_info['user_id'];
		if($Friends->where($l_map)->delete() === false){
			$result['errcode']= 1;
			$result['data']= '删除左表好友失败';
			$this->ajaxReturn($result,"JSON");	
		}

		
		//删除右好友表
		$r_map['left_id'] = $t_info['user_id'];
		$r_map['right_id'] = $info['user_id'];
		if($Friends->where($r_map)->delete() === false){
			$result['errcode']= 1;
			$result['data']= '删除右好友表失败';
			$this->ajaxReturn($result,"JSON");	
		}


 
		//删除请求消息表
		$m_map['user_id'] = $info['user_id'];
		$m_map['rec_id'] = $t_info['user_id'];
		$affect = M('FriendReqMsg')->where($m_map)->delete();
		if($affect === false){
			$result['errcode']= 1;
			$result['data']="删除好友请求信息失败";
			$this->ajaxReturn($result,"JSON");	
		}

		if(empty($affect)){
			$m_map['user_id'] = $t_info['user_id'];
			$m_map['rec_id'] = $info['user_id'];
			$affect = M('FriendReqMsg')->where($m_map)->delete();
			if($affect === false){
				$result['errcode']= 1;
				$result['data']="删除好友请求信息失败";
				$this->ajaxReturn($result,"JSON");	
			}
		}


	

       
	    
		$result['errcode']= 0;
		$result['data']="success";
	           
	    $this->ajaxReturn($result,"JSON");		

    }


   
    //38. IM 好友备注
    public function friendsNameRemark(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$targetId = I('post.targetId'); 
		$remarkName = I('post.remarkName','','trim');
		$salt = "action_friendsNameRemark";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($targetId,'对方ID不能为空！');  
		$this->checkNull($remarkName,'备注名称不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$targetId.$remarkName.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('User');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();

		$t_map['user_id'] = $targetId;
		$t_info = $User->field('user_id,username,phone')->where($t_map)->find();
		//验证手机是否存在
		if(!$t_info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}






		//更新朋友表
		$friendMap['left_id'] = $info['user_id'];
		$friendMap['right_id'] = $t_info['user_id'];
		$affect = M('Friends')->where($friendMap)->setField('remark',$remarkName);
		if($affect === false){
			$result['errcode']= 1;
			$result['data']= '增加备注失败';
		
		}elseif(empty($affect)){
			$result['errcode']= 0;
			$result['data']= '没有修改';
		}else{
			$result['errcode']= 0;
			$result['data']= 'success';
		}

		
		
	           
	    $this->ajaxReturn($result,"JSON");		

    }


   
 



    //23.测试发送接口
    public function send_id(){
    	$user_id = I('post.user_id','','trim');
    	$userName = I('post.userName','','trim');
    	$userPortrait = I('post.userPortrait','','trim');


    	$this->checkNull($user_id,'id不能为空');
		$this->checkNull($userName,'名称不能为空');
		$this->checkNull($userPortrait,'用户头像不能为空！');


    	$cc_f = '6666好友请求信息';
    	$cc_f = '6667好友请求信息';
    	$c_f = '7777群组请求信息';
    	$c = '7778群主反馈信息';


		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$portraitUri = $this->SERVER_URL.'Uploads/service/image/usergroup/'.$userPortrait;
	    $ret = $p->getToken($user_id,$userName,$portraitUri);
	    if(empty($ret)){
	        	$result['errcode']= 1;
				$result['data']= '非法操作！';
	    }else{
	    		$ret = json_decode($ret);
	        	$result['errcode']= 0;
				$result['data']['ry_token']= $ret->token;
	    }
	           
	      $this->ajaxReturn($result,"JSON");		

    }





    //20.测试更新接口
    public function update_id(){
    	$user_id = I('post.user_id','','trim');
        $userName = I('post.userName','','trim');
        $userPortrait = I('post.userPortrait','','trim');


		$this->checkNull($user_id,'user_id不能为空');
		$this->checkNull($userName,'名称不能为空');
		$this->checkNull($userPortrait,'用户头像不能为空！');




		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));

	    $ret = $p->userRefresh($user_id,$userName,$userPortrait);
	    $ret = json_decode($ret);
	    if($ret->code == 200){
	        $result['errcode']= 0;
			$result['data']= 'success';
	    }else{	        
	    	$result['errcode']= 1;
			$result['data']= '非法操作！';
	    }	   
	      $this->ajaxReturn($result,"JSON");		

    }

    //34.创建聊天室
    public function createRoom(){
    	$id = I('post.id','','trim');


    	$this->checkNull($id,'user_id不能为空');

    	$map['id'] = $id;
        $roomname = M('Chatroom')->where($map)->getField('roomname');





		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$data[$id] = $roomname;
	    $ret = $p->chatroomCreate($data);
	    $ret = json_decode($ret);
	    if($ret->code == 200){
	        $result['errcode']= 0;
			$result['data']= 'success';
	    }else{	        
	    	$result['errcode']= 1;
			$result['data']= '非法操作！';
	    }	   
	      $this->ajaxReturn($result,"JSON");		

    }


   



    



		

  	//26.接收/拒绝好友请求 (需调用第三方api)
    public function addFriendCallBack(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session'); 
        $targetId = I('post.targetId','','trim');
        $callback_type = I('post.callback_type','','trim');
        $message = I('post.message','','trim');
		$salt  =	"action_addFriendCallBack";
		$encodestr = I('post.encodestr');

		
	
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($targetId,'对方ID不能为空');
		$this->checkNull($u_Session,'用户登录不能为空！');


	

		//验证u_session是否正确
		$this->checkSession();


		$password = md5(md5($u_Phone.$u_Session.$targetId.$callback_type.$message.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}

		
		//找出用户
		$sendMap['user_id'] = $targetId;
		$recMap['phone'] = $u_Phone;
		
			
		$User = M('user');
		$s_info = $User->field('user_id,username,img,phone')->where($sendMap)->find();
		$r_info = $User->field('user_id,username,img,phone')->where($recMap)->find();


		
		//验证用户是否存在
		if(empty($s_info) || empty($r_info)){
			$result['errcode']= 1;
			$result['data']=$r_info;
			$this->ajaxReturn($result,"JSON");		
		}


		if($s_info['phone'] == $r_info['phone']){
			$result['errcode']='1';			
			$result['data']=  '不能添加自己为好友';
			$this->ajaxReturn($result,"JSON");	
		}




		//接受的话，就增加记录,1表示接受，2表示拒绝
		if($callback_type == '1'){
			$Friends = M('Friends');
			$leftData['left_id'] = $s_info['user_id'];
			$leftData['right_id'] = $r_info['user_id'];
			$leftData['time'] = time();
			if($Friends->add($leftData)){
					$rightData['left_id'] = $r_info['user_id'];
					$rightData['right_id'] = $s_info['user_id'];
					$rightData['time'] = $leftData['time'];
					if(!$Friends->add($rightData)){
						$result['errcode']= 1;
						$result['data']= '新增好友表失败';
	      				$this->ajaxReturn($result,"JSON");	
					}
			}else{
					$result['errcode']= 1;
					$result['data']= '新增发送方好友表失败';
	      			$this->ajaxReturn($result,"JSON");	
			}
		}elseif($callback_type != '2'){
			$result['errcode']='1';			
			$result['data']=  '非法操作！';
			$this->ajaxReturn($result,"JSON");	
		}


		//严格的话还需验证申请消息是否存在

		//更新消息状态
		if($callback_type == '1'){
			$status = 2;
			$pre_content = '接受';
		}else{
			$status = 3;
			$pre_content = '拒绝';
		}

		$map['status'] = 1;
		$map['send_id'] = $s_info['user_id'];
		$map['rec_id'] = $r_info['user_id'];
		if(M('FriendReqMsg')->where($map)->setField('status',$status) === false){
			$result['errcode']= 1;
			$result['data']= '更新状态失败';		
	        $this->ajaxReturn($result,"JSON");	
		}
		

		//发送消息请求
        if(!empty($message)) $message = '('. $message.')';


		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));

		$contentArr['content'] = $r_info['user_id'].'已'.$pre_content.'您的请求'.$message;
		$contentJson = json_encode($contentArr);

		$pushContent = $contentArr['content'];
		$pushData['pushData'] =  $contentArr['content'];
	
	
		$pushData = json_encode($pushData);
		$idArr = array($s_info['user_id']);


	    $ret = $p->messageSystemPublish(6667,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);


	    $ret = json_decode($ret);
	    if($ret->code == 200){
	        $result['errcode']= 0;
			$result['data']= 'success';
	    }else{
	        
	    	$result['errcode']= 1;
			$result['data']= $ret;
	    }
	           
	      $this->ajaxReturn($result,"JSON");		

    }



    //27.IM获取好友请求列表
    public function getFriendsAddList(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$salt = "action_getFriendsAddList";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();


		//获取好友请求列表
		$list = M('FriendReqMsg')->field('u.user_id AS source_id,u.username AS source_username,u.img AS source_portrait,m.message AS add_message,m.status AS callback_type')
								->alias('m')->join('LEFT JOIN user u ON m.send_id = u.user_id')->where('m.rec_id='.$info['user_id'])->select();
		

		if(empty($list)){
			$result['errcode']= 0;
			$result['data']= '没有该类信息';
			$this->ajaxReturn($result,"JSON");
		}




	   
        $result['errcode']= 0;
		$result['data']= $list;
    
	           
	     $this->ajaxReturn($result,"JSON");		

    }



    //42.IM 获取用户信息
    public function getPersonInfo(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$targetId = I('post.targetId');  //用户ID或手机号码
		$salt = "action_getUserInfo";
		$encodestr = I('post.encodestr');

		

		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($targetId,'对方ID不能为空');  
		$this->checkNull($encodestr,'校验码不能为空！');



		$password = md5(md5($u_Phone.$u_Session.$targetId.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}

		//验证手机是否存在
		$map['phone'] = $u_Phone;
		$User = M('user');
		$user_id = $User->where($map)->getField('user_id');
		if(empty($user_id)){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();


		//查询用户信息,判断参数是手机号码还是ID
		if(preg_match("/^1[34578]{1}\d{9}$/",$targetId)){
			$t_map['phone'] = $targetId;
		}else{
			$t_map['user_id'] = $targetId;
		}

		
		$t_info = $User->field('user_id,username AS user_name,img AS user_portrait,sex AS gender,personal_sign')->where($t_map)->find();
		//验证手机是否存在
		if(!$t_info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}

		$t_info['gender'] = $t_info['gender'] == 1 ? '男' : '女' ;
		$t_info['user_portrait'] = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$t_info['user_portrait'];

		

		//查询是否为好友
		$friendMap['left_id'] = $user_id;
		$friendMap['right_id'] = $t_info['user_id'];
		$friendInfo = M('Friends')->field('remark,left_id')->where($friendMap)->find();


		//$t_info['user_id'] = $t_info['phone'];
		//unset($t_info['phone']);
		$t_info['is_friend'] = !empty($friendInfo) ? 'true' : 'false';
		$t_info['remark_name'] = !empty($friendInfo['remark']) ? $friendInfo['remark'] : '';
		$t_info['personal_sign'] = !empty($friendInfo['personal_sign']) ? $friendInfo['personal_sign'] : '';
		  
		

		

        $result['errcode']= 0;
		$result['data']= $t_info;
    
	           
	     $this->ajaxReturn($result,"JSON");		

    }





	//上传接口
    private function up($savePath,$saveName = 'uniqid')
    {
        //完成与thinkphp相关的，文件上传类的调用
        $upload = new \Think\Upload();
        $upload->maxSize = '1000000';
        //默认为-1，不限制上传大小
        $upload->savePath = $savePath;
        //保存路径建议与主文件平级目录或者平级目录的子目录来保存
        $upload->saveName = $saveName;
        //如果存在同名文件是否进行覆盖
        $upload->replace = true;
        //去掉时间子目录
        $upload->subName = '';

       
        $upload->exts = array('jpg', 'mp3','jpeg', 'png', 'gif');
        //准许上传的文件类型
        $upload->mimes = array('image/png', 'audio/mpeg', 'image/jpeg', 'image/gif', 'image/jpg','application/octet-stream');
        //检测mime类型
        //$upload->thumb=true;//是否开启图片文件缩略图
        //$upload->thumbMaxWidth='300,500';
        //$upload->thumbMaxHeight='200,400';
        //$upload->thumbPrefix='s_,m_';//缩略图文件前缀
        //$upload->thumbRemoveOrigin=1;//如果生成缩略图，是否删除原图
        $info = $upload->upload();
        if (!$info) {
            // 上传错误提示错误信息
            $result['errcode'] = '1';
            $result['data'] = $upload->getError();
            $this->ajaxReturn($result, 'JSON');
        } else {
            // 上传成功
            $result['errcode'] = '0';
            foreach ($info as $file) {
                $filepath = $file['savepath'] . $file['savename'];
            }
            $result['data'] = $upload->rootPath . $filepath;
            $result['savename'] = $file['savename'];
            return $result;
        }
    }
		

    //24.创建/编辑群组 (需调用第三方api)
    public function createGroup(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$group_id = I('post.group_id'); 
		$groupname = I('post.groupname','','trim'); 
		$group_notice = I('post.group_notice','','trim'); 
		$salt = "action_createGroup";
		$encodestr = I('post.encodestr');


	


		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		if(empty($group_id)) $this->checkNull($groupname,'群名称不能为空！');

		$password = md5(md5($u_Phone.$u_Session.$group_id.$groupname.$group_notice.$salt));
	
		//验证效验码
		if ($password !=$encodestr){
			$this->errorReturn($password);				
		}






		
		$User = M('user');
		$info = $User->field('user_id,username,img,phone')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$this->errorReturn('不存在该用户');
		}


		//验证u_session是否正确
		$this->checkSession();


		
		//文件上传地址提交给他，并且上传完成之后返回一个信息，让其写入数据库,不为空时候，新增修改都操作，为空只判断新增时
        if (empty($_FILES)) {
        	if(empty($group_id)){
        		$this->errorReturn('必须选择上传文件');
        	}
           
        } else {
        	$filePath = 'service/image/usergroup/';
            $a = $this->up($filePath);
            if (!isset($a)) {     
            	$this->errorReturn('上传文件异常，请与系统管理员联系');              
            }
        }

		


		

        //新增操作
		if(empty($group_id)){
			$Usergroup = D('Usergroup');
			//新增群数据
			$data['groupname'] = $groupname;
			$data['user_id'] = $info['user_id'];
			$data['username'] = $info['username'];
			$data['phone'] = $info['phone'];
			$data['img'] = $info['img'];
			$data['groupface'] = $a['savename'];
			$data['time'] = time();

			 //如果用户提交数据
	        if (!$Usergroup->create($data)) {
	            // 如果创建失败 表示验证没有通过 输出错误提示信息
	            $result['errcode']=1;
	            $result['data']=  $Usergroup->getError();
	            $this->ajaxReturn($result);
	            exit();
	        } else {

				$gid = $Usergroup->add();

	            if (empty($gid)) {
	            	$this->errorReturn('创建群失败');
	            }
	        }

	        //新增群组成员
	        $menberData['groupid'] = $gid;
	        $menberData['user_id'] = $info['user_id'];
	        $menberData['username'] = $info['username'];
	        $menberData['phone'] = $info['phone'];
	        $menberData['img'] = $info['img'];
	        $menberData['time'] = $data['time'];
	        $menberData['is_manager'] = 3;
	 
	        if(!M('Groupmember')->add($menberData)){
	        	$this->errorReturn('创建成员失败');	   
	        }

	        //新增群公告
	        if(!empty($group_notice)){
	        	$noticeData['groupid'] = $gid;
	        	$noticeData['message'] = $group_notice;
	        	$noticeData['time'] = time();
		        if(!M('GroupNotice')->add($noticeData)){
		        	$this->errorReturn('新增群公告失败！');	   
		        }
	        }
	


			//融云创建群
	        $p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
			$idArr = array($info['user_id']);
		 	$ret = $p->groupCreate($idArr,$gid,$groupname);
			$ret = json_decode($ret);
		 	
			if($ret->code != 200){
	   			$result['errcode']= 1;
				$result['data']= $ret->code;
				$this->ajaxReturn($result,"JSON");	
	   		}
       		


			//同步融云服务器
		    $groupMap['m.user_id'] = $info['user_id'];
			$returnArr = $this->groupSync($groupMap);
			if($returnArr['code'] != 200){
		  		$this->errorReturn($returnArr['code']);
			}


       
		}else{

			//修改操作
			if(empty($groupname) && empty($a['savename']) && empty($group_notice)){
				$result['errcode']= 0;
				$result['data']= '没有任何修改';  
      			$this->ajaxReturn($result,"JSON");	
			}else{

				//群信息
				if(!empty($groupname)) $data['groupname'] = $groupname;
				if(!empty($a['savename']))	$data['groupface'] = $a['savename'];
				$Usergroup = D('Usergroup');
				$groupMap['id'] = $group_id;
				$groupMap['user_id'] = $info['user_id'];
				if($Usergroup->where($groupMap)->save($data) === false){
					$this->errorReturn();
				}


				//群公告
				if(!empty($group_notice)){
					$noticeData['groupid'] = $group_id;
					$noticeData['message'] = $group_notice;
					$noticeData['time'] = time();
					if(!M('GroupNotice')->add($noticeData)){
						$this->errorReturn();
					}
				}
		

			}
			$gid = $group_id;
			$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));

			
		}
		


	


	    

	    //刷新群组信息
	 	$ret = $p->groupRefresh($gid,$groupname);
		$ret = json_decode($ret);

   		if($ret->code == 200){
   			$result['errcode']= 0;
			$result['data']= 'success';
   		}else{
   			$result['errcode']= 1;
			$result['data']= $ret->code;
   		}
       
	 
	           
	     $this->ajaxReturn($result,"JSON");		

    }


    //25.获取群组列表 (先获取后同步)
    public function getGroup(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$salt = "action_getGroup";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();





	    //同步融云服务器
	    $groupMap['m.user_id'] = $info['user_id'];
		$returnArr = $this->groupSync($groupMap);


		if($returnArr['code'] == 200){
   			$result['errcode']= 0;
			$result['data']= $returnArr['list'];
   		}else{
   			$result['errcode']= 1;
			$result['data']= $returnArr['code'];
   		}
       
	    
	    
	           
	    $this->ajaxReturn($result,"JSON");		

    }



    //28.IM加入群组
    public function joinGroup(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$group_id = I('post.group_id'); 
		$message = I('post.message','','trim'); 
		$salt = "action_joinGroup";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($group_id,'群ID不能为空');  
		$password = md5(md5($u_Phone.$u_Session.$group_id.$message.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username,img')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();


		//验证群是否存在
		$UserGroup = M('Usergroup');
		$groupInfo = $UserGroup->field('id,groupname,user_id,username,phone')->where('id='.$group_id)->find();
		if(empty($groupInfo)){
			$result['errcode']= 1;
			$result['data']="不存在该群组";
			$this->ajaxReturn($result,"JSON");
		}


		//验证用户是否已经加入该群
		$Groupmember = M('Groupmember');
		$groupMap['user_id'] = $info['user_id'];
		$groupMap['groupid'] = $group_id;
		$is_join = $Groupmember->field('user_id')->where($groupMap)->find();
		if(!empty($is_join)){
			$result['errcode']= 1;
			$result['data']= '您已加入该群';
			$this->ajaxReturn($result,"JSON");
		}



		



	    //向群主发送消息，7777
		//组装发送内容
		//$contentArr['operation'] = '好友请求';
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		if(!empty($message)) $newmessage = '('.$message.')'; 
		$contentArr['content'] = '['.$groupInfo['groupname'].']'.$info['user_id'].'申请加入该群'.$newmessage;
		$contentArr['extra'] = 'asdsad';
		// $contentArr['sourceUserId'] = $list[0]['user_id'];
		// $contentArr['targetUserId'] = $list[1]['user_id'];
		$contentJson = json_encode($contentArr);

		$pushContent = $newmessage;
		$pushData['pushData'] =  $newmessage;
	
	
		$pushData = json_encode($pushData);
		$idArr = array($groupInfo['user_id']);
	    $ret = $p->messageSystemPublish(7777,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);
	    $ret = json_decode($ret);


	

		if($ret->code == 200){

			//查表，存在更新，不存在新增
			$grmMap['send_id'] = $info['user_id'];
			$grmMap['groupid'] = $group_id;
			$GroupReqMsg = M('GroupReqMsg');
			$grmInfo = $GroupReqMsg->where($grmMap)->find();
			if(empty($grmInfo)){
				//新增请求信息
				$data['send_id'] = $info['user_id'];
				$data['groupid'] = $group_id;
				$data['create_id'] = $groupInfo['user_id'];
				$data['time'] = time();
				$data['message'] = $message;
				$data['status'] = 1;
				if($GroupReqMsg->add($data)){
					$result['errcode']= 0;
					$result['data']= '申请成功';
				}else{
					$result['errcode']= 1;
					$result['data'] = '新增请求信息失败';
				}
			
			}else{
				$data['time'] = time();
				$data['message'] = $message;
				$data['status'] = 1;
				if($GroupReqMsg->where($grmMap)->save($data) !== false){
					$result['errcode']= 0;
					$result['data'] = '修改请求信息成功';
				}else{
					$result['errcode']= 1;
					$result['data'] = '修改请求信息失败';
				}
			}
			
   			
   		}else{
   			$result['errcode']= 1;
			$result['data']= $ret->code;
   		}
       
	  		$result['errcode']= 0;
			$result['data']= '请求发送成功';
    
	           
	    $this->ajaxReturn($result,"JSON");		

    }


  

    //32.IM 接收/拒绝加入群组请求
    public function joinGroupCallBack(){
    	//群主
    	$u_Phone = I('post.u_Phone','','trim');
    	$u_Session = I('post.u_Session'); 
        $targetId = I('post.targetId','','trim');
        $group_id = I('post.group_id','','trim');
        $callback_type = I('post.callback_type','','trim');
        $message = I('post.message','','trim');
		$salt  =	"action_joinGroupCallBack";
		$encodestr = I('post.encodestr');

		
	
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($targetId,'对方ID不能为空');
		$this->checkNull($group_id,'群主ID不能为空');
		$this->checkNull($u_Session,'用户登录不能为空！');


	

		//验证u_session是否正确
		$this->checkSession();


		$password = md5(md5($u_Phone.$u_Session.$targetId.$group_id.$callback_type.$message.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		$map['phone'] = $u_Phone;
		$User = M('user');
		$info = $User->field('user_id,username,img')->where($map)->find();
		//验证群主
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}



		$t_map['user_id'] = $targetId;
		$t_info = $User->field('user_id,username,img,phone')->where($t_map)->find();
		//验证目标用户是否存在
		if(!$t_info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		
		//验证该群是否存在，是否为管理员或群主
		$groupMap['groupid'] = $group_id;
		$groupMap['is_manager'] = array('in','2,3');
		$groupMap['user_id'] = $info['user_id'];
		$Groupmember = M('Groupmember');
		$groupInfo = $Groupmember->where($groupMap)->find();
		if(empty($groupInfo)){
			$result['errcode']= 1;
			$result['data']= '不存在该群,或该用户不是管理员或群主';
			$this->ajaxReturn($result,"JSON");	
		}




		//验证消息内容状态是否为1
		$grmMap['status'] = 1;
		$grmMap['send_id'] = $t_info['user_id'];
		$grmMap['groupid'] = $group_id;
		$grmMap['create_id'] = $info['user_id'];
		$GroupReqMsg = M('GroupReqMsg');
		$msgInfo = $GroupReqMsg->where($grmMap)->find();
		if(empty($msgInfo)){
			$result['errcode']= 1;
			$result['data']= '非法操作！';		
	        $this->ajaxReturn($result,"JSON");	
		}
		




		//接受的话，就增加群成员,1表示接受，2表示拒绝
		if($callback_type == '1'){
			$groupData['groupid'] = $group_id;
			$groupData['user_id'] = $t_info['user_id'];
			$groupData['username'] = $t_info['username'];
			$groupData['phone'] = $t_info['phone'];
			$groupData['img'] = $t_info['img'];
			$groupData['time'] = time();
			$groupData['is_manager'] = 1;
			if(!$Groupmember->add($groupData)){
				$result['errcode']= 1;
				$result['data']= '加入群失败';
			}
			 
		}elseif($callback_type != '2'){
			$result['errcode']='1';			
			$result['data']=  '非法操作！';
			$this->ajaxReturn($result,"JSON");	
		}


		//严格的话还需验证申请消息是否存在

		//更新消息状态
		$groupname = M('Usergroup')->where('id='.$group_id)->getField('groupname');
		if($callback_type == '1'){
			$status = 2;
			$contentArr['content'] = '您已加入['.$groupname.']';
		}else{
			$status = 3;
			$contentArr['content'] = '['.$groupname.']管理员拒绝您的请求';
		}

		if(!$GroupReqMsg->where($grmMap)->setField('status',$status)){
			$result['errcode']= 1;
			$result['data']= '更新状态失败';		
	        $this->ajaxReturn($result,"JSON");	
		}
		

		//发送消息请求
        if(!empty($message)) $message = '('. $message.')';


		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));

		$contentJson = json_encode($contentArr);

		$pushContent = $contentArr['content'];
		$pushData['pushData'] =  $contentArr['content'];
	
	
		$pushData = json_encode($pushData);
		$idArr = array($t_info['user_id']);


	    $ret = $p->messageSystemPublish(7778,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);
    	if($callback_type == '1'){

			//同步融云服务器
		    $groupSyncMap['m.user_id'] = $t_info['user_id'];
			$returnArr = $this->groupSync($groupSyncMap);

			if($returnArr['code'] != 200){
				$result['errcode']= 1;
				$result['data']= $returnArr['code'];  
	      		$this->ajaxReturn($result,"JSON");	
			}
			
		}



	    $ret = json_decode($ret);
	    if($ret->code == 200){

	        $result['errcode']= 0;
			$result['data']= 'success';
	    }else{
	        
	    	$result['errcode']= 1;
			$result['data']= $ret;
	    }
	           
	      $this->ajaxReturn($result,"JSON");		

    }



    //同步融云服务器
    public function groupSync($groupMap){
		$Usergroup = D('Usergroup');
		$list = $Usergroup->getList($groupMap);
		if(!empty($list)){
			foreach ($list as $key => $value) {
				$data[$value['group_id']] = $value['group_name'];
			}
		}else{
			$returnData['code'] = 200;
			$returnData['list'] = '群组列表为空';
			return $returnData;
		}

		//同步融云服务器
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));

		//$idArr = array($groupMap['m.user_id']);
	 	$ret = $p->groupSync($groupMap['m.user_id'], $data);
		$ret = json_decode($ret);
		$returnData['code'] = $ret->code;
		$returnData['list'] = $list;
		return $returnData;

	   
    }


    //31.IM获取群成员列表 
    public function getGroupMemberInfo(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$group_id = I('post.group_id'); 
		$request_type = I('post.request_type'); 
		$salt = "action_getGroupMemberInfo";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($group_id,'群主ID不能为空！');  

		if(($request_type != 'search') && ($request_type != 'all')){
			$result['errcode']='1';			
			$result['data']=  '非法操作！';
			$this->print_log('',$result['data'],ACTION_NAME);  
			$this->ajaxReturn($result,"JSON");	
		}




		$password = md5(md5($u_Phone.$u_Session.$group_id.$request_type.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();



		//获取群信息
		$groupInfo = M('Usergroup')->field('groupname AS group_name,groupface AS group_icon,user_id AS group_belong')->where('id='.$group_id)->find();
		if(empty($groupInfo)){
			$result['errcode']= 1;
			$result['data']= '不存在该群';
	   		$this->ajaxReturn($result,"JSON");	
		}



		if($request_type == 'search'){
			$result['errcode']= 0;
			$result['data']= '存在该群';
	   		$this->ajaxReturn($result,"JSON");
		}






		$groupInfo['group_icon'] = $this->SERVER_URL.'Uploads/service/image/usergroup/'.$groupInfo['group_icon'];
		//获取最新群公告
		$noticeMap['groupid'] = $group_id;
		$noticeInfo = M('GroupNotice')->field('message')->where($noticeMap)->order('time DESC')->limit(1)->find();
		$groupInfo['group_notice'] = !empty($noticeInfo) ? $noticeInfo['message'] : '';






		//获取群成员
		$groupMap['g.groupid'] = $group_id;
		$list = M('Groupmember')->alias('g')
								->field('g.user_id,g.username AS user_name,g.img AS user_portrait,g.is_manager AS member_role,g.phone,f.remark AS remark_name')
								->join("LEFT JOIN friends f ON f.right_id=g.user_id AND f.left_id='{$info['user_id']}'")
								->where($groupMap)->select();

		if(empty($list)){
			$result['errcode']= 1;
			$result['data']= '非法操作！';
			$this->print_log('',$result['data'],ACTION_NAME);         
	   		$this->ajaxReturn($result,"JSON");		
		}




		foreach ($list as $key => $value) {
			$list[$key]['user_portrait'] = C('DOMAIN_URL').'/Uploads/admin/image/user/'.$value['user_portrait'];
			if(empty($value['remark_name'])) $list[$key]['remark_name'] = '';


			//验证是否在群里面
			if($groupInfo['is_group_member'] != 'true'){
				if($value['phone'] == $u_Phone){
					$groupInfo['is_group_member'] = 'true';
				}else{
					$groupInfo['is_group_member'] = 'false';
				}
			}





		}


	


		$list[] = $groupInfo;
 
		$result['errcode']= 0;
		$result['data']= $list;
	           
	    $this->ajaxReturn($result,"JSON");		

    }


    //33.IM获取进群请求
    public function joinGroupList(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$salt = "action_joinGroupList";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();


		//获取好友请求列表,未处理
		$groupMap['r.status'] = 1;
		$groupMap['r.create_id'] = $info['user_id'];
		$Usergroup = D('Usergroup');
		$list = $Usergroup->getRequire($groupMap);
		

		if(empty($list)){
			$result['errcode']= 0;
			$result['data']= '没有该类信息';;
			$this->ajaxReturn($result,"JSON");
		}




	   
        $result['errcode']= 0;
		$result['data']= $list;
    
	           
	     $this->ajaxReturn($result,"JSON");		

    }


    //39.IM 群主踢人操作
    public function groupOwnerKick(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$targetId = I('post.targetId');  
		$groupId = I('post.groupId'); 
		$message = I('post.message','','trim'); 
		$salt = "action_groupOwnerKick";
		$encodestr = I('post.encodestr');




		
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！'); 
		$this->checkNull($targetId,'对方ID不能为空');   
		$this->checkNull($groupId,'群ID不能为空');  
		$password = md5(md5($u_Phone.$u_Session.$targetId.$groupId.$message.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		//验证u_session是否正确
		$this->checkSession();


		//验证群是否存在
		$groupname = M('Usergroup')->where('id='.$groupId)->getField('groupname');
		if(empty($groupname)){
			$result['errcode']= 1;
			$result['data']="该群不存在";
			$this->ajaxReturn($result,"JSON");		
		}




		//验证是否为管理员或群主
		$menberMap['phone'] = $u_Phone;
		$menberMap['groupid'] = $groupId;
		$menberMap['is_manager'] = array('in','2,3');

		$Groupmember = M('Groupmember');
		$memberInfo = $Groupmember->field('username')->where($menberMap)->find();
		if(!$memberInfo){
			$result['errcode']= 1;
			$result['data']="此人不是管理员";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证被踢方是否为在该群
		$existMap['user_id'] = $targetId;
		$existMap['groupid'] = $groupId;
		$targetInfo = $Groupmember->field('user_id,username,phone')->where($existMap)->find();
		if(empty($targetInfo)){
			$result['errcode']= 1;
			$result['data']="该用户不属于该群";
			$this->ajaxReturn($result,"JSON");	
		}




		//移出该群
		if(!$Groupmember->where($existMap)->delete()){
			$result['errcode']= 1;
			$result['data']="移出失败";
			$this->ajaxReturn($result,"JSON");	
		}



	    //向对方发送消息，7778
		//组装发送内容
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		if(!empty($message)) $newmessage = '('.$message.')'; 
		$contentArr['content'] = '['.$groupname.']您已被管理员移除该群';
		$contentArr['extra'] = 'asdsad';
		$contentJson = json_encode($contentArr);

		$pushContent = $newmessage;
		$pushData['pushData'] =  $newmessage;
	
	
		$pushData = json_encode($pushData);
		$idArr = array($targetInfo['user_id']);
	    $ret = $p->messageSystemPublish(7778,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);
	    $ret = json_decode($ret);



	    //同步融云服务器
	    $groupMap['m.user_id'] = $targetInfo['user_id'];
		$returnArr = $this->groupSync($groupMap);
	
		if($returnArr['code'] == 200){
			$result['errcode']= 0;
			$result['data']= 'success';
		}else{
			$result['errcode']= 1;
			$result['data']= $returnArr['code'];
		}


      	$this->ajaxReturn($result,"JSON");	


    }


	//40 IM 解散群
    public function dimissGroup(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$groupId = I('post.groupId');  
		$salt = "action_dimissGroup";
		$encodestr = I('post.encodestr');


		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($groupId,'群ID不能为空'); 

		$password = md5(md5($u_Phone.$u_Session.$groupId.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']= 1;			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		//验证u_session是否正确
		$this->checkSession();

		//验证是否为群主
		$Usergroup = M('Usergroup');
		$groupMap['id'] = $groupId;
		$groupMap['phone'] = $u_Phone;
		$groupInfo = $Usergroup->field('phone,groupname')->where($groupMap)->find();
		if(empty($groupInfo)){
			$result['errcode']= 1;
			$result['data']="该群不存在或用户不是群主";
			$this->ajaxReturn($result,"JSON");		
		}




		//获取群成员，非群主
		$Groupmember = M('Groupmember');
		$memberMap['phone'] = array('neq',$u_Phone);
		$memberMap['groupid'] = $groupId;
		$memberList = $Groupmember->field('user_id')->where($memberMap)->select();
		foreach ($memberList as $key => $value) {
			$idArr[] = $value['user_id'];
		}
			


		//删除群组表
		if(!$Usergroup->where('id='.$groupId)->delete()){
			$result['errcode']= 1;
			$result['data']="群组删除失败！";
			$this->ajaxReturn($result,"JSON");	
			
		}




		//删除群成员表
		if(!$Groupmember->where('groupid='.$groupId)->delete()){
			$result['errcode']= 1;
			$result['data']="群成员表删除失败！";
			$this->ajaxReturn($result,"JSON");	
		};

			
	
		//融云解散对接
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
	    $ret = $p->groupDismiss($groupInfo['user_id'],$groupId);
	    $ret = json_decode($ret);

	    if($ret->code != 200){
	    	$result['errcode']= 1;
			$result['data']= $ret->code;
			$this->ajaxReturn($result,"JSON");	
	    }



       
	    //群发消息7778
		//组装发送内容
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$contentArr['content'] = '['.$groupInfo['groupname'].']'.'该管理员已解散该群';
		$contentArr['extra'] = 'asdsad';
		$contentJson = json_encode($contentArr);

		$pushContent = '';
		$pushData['pushData'] =  '';
	
	
		$pushData = json_encode($pushData);
		

		//群里面有成员时就通知
		if(!empty($idArr)){
			$ret = $p->messageSystemPublish(7778,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);
	    	$ret = json_decode($ret);
	    	if($ret->code == 200){
				$result['errcode']= 0;
				$result['data']= 'success';
			}else{
				$result['errcode']= 1;
				$result['data']= $ret->code;
		    }


		//只有自己时不通知
		}else{
			$result['errcode']= 0;
			$result['data']= 'success';
		}
	 
 		$this->ajaxReturn($result,"JSON");	
	  
	  	
	
	           
	    	
		



    }




    //35.IM获取聊天室
    public function getChatRoomList(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$salt = "action_getChatRoomList";
		$encodestr = I('post.encodestr');

		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();


		//$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$info = M('Chatroom')->field('id AS chrmId,roomname AS name,icon,time')->find();
		$info['icon'] = $this->SERVER_URL.'Uploads/service/image/chatroom/'.$info['icon'];
	    if(!empty($info)){
	    	$result['errcode']= 0;
			$result['data']= $info;
	    }else{
	    	$result['errcode']= 1;
			$result['data']= '没有聊天室列表';
	    }

	           
	     $this->ajaxReturn($result,"JSON");		

    }

    //36.加入聊天室
    public function joinChatRoom(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$chatroom_id = I('post.chatroom_id');  
		$salt = "action_joinChatRoom";
		$encodestr = I('post.encodestr');


		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($chatroom_id,'聊天室ID不能为空'); 

		$password = md5(md5($u_Phone.$u_Session.$chatroom_id.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']= 1;			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username,img,phone')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();

		//验证聊天室是否存在
		$roomMap['id'] = $chatroom_id;
		$roomInfo = M('Chatroom')->where($roomMap)->find();
		if(empty($roomInfo)){
			$result['errcode']= 1;			
			$result['data']=  '聊天室不存在！';
			$this->ajaxReturn($result,"JSON");	
		}




		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$userIdArr = array($info['user_id']);
	    $ret = $p->chatroomJoin($userIdArr,$chatroom_id);
	    $ret = json_decode($ret);


   		if($ret->code == 200){
   			$result['errcode']= 0;
			$result['data']= 'success';
   		}else{
   			$result['errcode']= 1;
			$result['data']= $ret->code;
   		}
       
	    
	           
	     $this->ajaxReturn($result,"JSON");		



    }




    //37.获取聊天室成员
    public function getChatRoomUser(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session');
		$chatroom_id = I('post.chatroom_id');  
		$salt = "action_getChatRoomUser";
		$encodestr = I('post.encodestr');


		$map['phone'] = $u_Phone;
		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  
		$this->checkNull($chatroom_id,'聊天室ID不能为空'); 

		$password = md5(md5($u_Phone.$u_Session.$chatroom_id.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']= 1;			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		
		$User = M('user');
		$info = $User->field('user_id,username,img,phone')->where($map)->find();
		//验证手机是否存在
		if(!$info){
			$result['errcode']= 1;
			$result['data']="不存在该用户";
			$this->ajaxReturn($result,"JSON");		
		}


		//验证u_session是否正确
		$this->checkSession();

		//验证聊天室是否存在
		$roomMap['id'] = $chatroom_id;
		$roomInfo = M('Chatroom')->where($roomMap)->find();
		if(empty($roomInfo)){
			$result['errcode']= 1;			
			$result['data']=  '聊天室不存在！';
			$this->ajaxReturn($result,"JSON");	
		}



		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
	    $ret = $p->userChatroomQuery($chatroom_id);
	    $ret = json_decode($ret);


   		if($ret->code == 200){


   			//获取聊天室信息
            $roomInfo = M('Chatroom')->field('id AS chatroom_id,roomname AS chatroom_name,icon AS chatroom_icon')->where('id='.$chatroom_id)->find();
            $roomInfo['chatroom_icon'] = $this->SERVER_URL.'Uploads/service/image/chatroom/'.$roomInfo['chatroom_icon'];
   			
   			$count = count($ret->users);
   			if(empty($count)){
  				$result['errcode'] = 0;
				$result['data'] = $roomInfo;
	    		$this->ajaxReturn($result,"JSON");	
   			}


   			//获取成员详情
   			for ($i=0; $i < $count; $i++) { 
   				$user_id .= $ret->users[$i]->id.',';
   				$userArr[$ret->users[$i]->id] = $ret->users[$i]->time;
   			}
   			
            $userMap['u.user_id'] = array('in',substr($user_id, 0,-1));
            $userList = M('User')->alias('u')->field('u.user_id,u.username AS user_name,u.img AS user_portrait,u.phone,f.remark AS remark_name')
            					->join("LEFT JOIN friends f ON f.right_id=u.user_id AND f.left_id='{$info['user_id']}'")
            					->where($userMap)->select();

            foreach ($userList as $key => $value) {
            	$userList[$key]['user_portrait'] = C('DOMAIN_URL').'/Uploads/admin/image/user/'.$value['user_portrait'];
            	foreach ($userArr as $k => $v) {
            		if($k == $value['phone']){
            			$userList[$key]['time'] = $v;
            		}
            	}

            	if(empty($value['remark_name'])) $userList[$key]['remark_name'] = '';
            }

       
            $userList[] = $roomInfo;
  			$result['errcode'] = 0;
			$result['data'] =  $userList;
   		}else{
   			$result['errcode']= 1;
			$result['data']= $ret->code;
   		}
       
	    
	  
	    $this->ajaxReturn($result,"JSON");		



    }




	//41.退出群
    public function quitGroup(){
    	$u_Phone = I('post.u_Phone','','trim');
		$u_Session = I('post.u_Session'); 
		$group_id = I('post.group_id');
		$salt = "action_quitGroup";
		$encodestr = I('post.encodestr');

		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($u_Session,'用户登录不能为空！');  

		$password = md5(md5($u_Phone.$u_Session.$group_id.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']='1';			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}

		//验证u_session是否正确
		$this->checkSession();


		//验证是否属于该群
		$memberMap['phone'] = $u_Phone;
		$memberMap['groupid'] = $group_id;
		$Groupmember = M('Groupmember');
		$userInfo = $Groupmember->field('user_id,username')->where($memberMap)->find();
		if(empty($userInfo)){
			$result['errcode']= 1;
			$result['data']="非法操作！";
			$this->ajaxReturn($result,"JSON");
		}



		//删除群成员
		if(!$Groupmember->where($memberMap)->delete()){
			$result['errcode']= 1;
			$result['data']="操作繁忙";
			$this->ajaxReturn($result,"JSON");	
		}




		/*
			发送消息给管理员
		*/

		//获取管理员
		$managerMap['is_manager'] = array('in','2,3');
		$managerMap['groupid'] = $group_id;
		$managerList = $Groupmember->field('user_id')->where($managerMap)->select();
		if(empty($managerList)){
			$result['errcode']= 1;
			$result['data']="管理员不存在！";
			$this->ajaxReturn($result,"JSON");	
		}
		foreach ($managerList as $key => $value) {
			$idArr[] = $value['user_id'];
		}

		//获取群名称
		$groupname = M('Usergroup')->where('id='.$group_id)->getField('groupname');



		
	    //群发消息7778
		//组装发送内容
		$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
		$contentArr['content'] = '['.$groupname.']'.$userInfo['username'].'退出了该群';
		$contentArr['extra'] = 'asdsad';
		$contentJson = json_encode($contentArr);

		$pushContent = '';
		$pushData['pushData'] =  '';
	
	
		$pushData = json_encode($pushData);
		
	    $ret = $p->messageSystemPublish(7778,$idArr,"RC:TxtMsg",$contentJson,$pushContent,$pushData);
	    $ret = json_decode($ret);

	  	
		if($ret->code != 200){
			$result['errcode']= 1;
			$result['data']= $ret->code;
		}

	     
	    //同步融云服务器
	    $groupMap['m.user_id'] = $userInfo['user_id'];
		$returnArr = $this->groupSync($groupMap);


		if($returnArr['code'] == 200){
			$result['errcode']= 0;
			$result['data']= 'success';
		}else{
			$result['errcode']= 1;
			$result['data']= $returnArr['code'];
		}




	    $this->ajaxReturn($result,"JSON");		
		


    }



	//43.上报数据
    public function reportData(){
    	$data['usermac'] = I('post.usermac','','trim');
		$data['apmac'] = I('post.apmac'); 
		$data['ssid'] = I('post.ssid');
		$data['brand'] = I('post.brand');
		$data['strength'] = I('post.strength');
		$data['status'] = I('post.status');
		$data['remark'] = I('post.remark');
		$data['chain'] = I('post.chain');
		$data['longitude'] = I('post.longitude');
		$data['latitude'] = I('post.latitude');
		$data['position'] = I('post.position');
		$salt = "action_reportData";
		$encodestr = I('post.encodestr');

		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkNull($data['usermac'],'物理地址不能为空！');
		$this->checkNull($data['apmac'],'ap地址不能为空！');  
		$this->checkNull($data['brand'],'品牌不能为空！');  
		$this->checkNull($data['strength'],'热点强度不能为空！');   
		$this->checkNull($data['chain'],'信道不能为空！');  
		$this->checkNull($data['longitude'],'经度不能为空！');  
		$this->checkNull($data['latitude'],'纬度不能为空！');  
		$this->checkNull($data['position'],'地理位置不能为空！');  



		$password = md5(md5($data['usermac'].$data['apmac'].$data['ssid'].$data['brand'].$data['strength'].$data['status'].$data['remark'].$data['chain'].$data['longitude'].$data['latitude'].$data['position'].$salt));
		//验证效验码
		if ($password !=$encodestr){
			$this->errorReturn($password);					
		}

	
		//存在就更新，不存在新增
		$ReportData = M('ReportData');
		$map['usermac'] =  $data['usermac'];
		$map['apmac'] =  $data['apmac'];
		$info = $ReportData->where($map)->find();
		$data['addtime'] = time();

		//新增
		if(empty($info)){
			
			if(M('ReportData')->add($data)){
				$result['errcode']= 0;			
				$result['data']=  '上报成功';
			}else{
				$result['errcode']= 1;			
				$result['data']=  '操作繁忙';
			}
			$this->ajaxReturn($result,"JSON");	
		}else{
			//修改
			if(M('ReportData')->where($map)->save($data) !== false){
				$result['errcode']= 0;			
				$result['data']=  '上报成功';
			}else{
				$result['errcode']= 1;			
				$result['data']=  '操作繁忙';
			}
			$this->ajaxReturn($result,"JSON");	

		}

	
	

	
		


    }


    //44.取数据
    public function getData(){
    	$usermac = I('post.usermac','','trim');
		$salt = "action_getData";
		$encodestr = I('post.encodestr');

		$this->checkNull($encodestr,'校验码不能为空！');
		$this->checkNull($usermac,'物理地址不能为空！');



		$password = md5(md5($usermac.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$this->errorReturn('校验失败！');					
		}

		$map['usermac'] = $usermac;
		$list = M('ReportData')->where($map)->order('addtime DESC')->select();


		$result['errcode']= 0;	
		if(empty($list)){			
			$result['data']=  '';
			$this->ajaxReturn($result,"JSON");	
		}

		foreach ($list as $key => $value) {
			$list[$key]['status'] = $value['status'] == 1 ? '不正常' : '正常';
			$list[$key]['addtime'] = date("Y-m-d",$value['addtime']);
		}
		
	
	
		$result['data']= $list;
		$this->ajaxReturn($result,"JSON");		
		


    }




    //微信登录获取access_token
    public function getwechat_access_token(){
    	$code = I('post.code','','trim');
		$grant_type = I('post.grant_type'); 
		$salt = "action_getAccess_token";
		$encodestr = I('post.encodestr');



		$this->checkNull($code,'code不能为空！');  
		$this->checkNull($grant_type,'grant_type不能为空'); 

		$password = md5(md5($code.$grant_type.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$result['errcode']= 1;			
			$result['data']=  $password;
			$this->ajaxReturn($result,"JSON");					
		}


		//模拟发送到微信
		$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$this->AppID.'&secret='.$this->AppSecret.'&code='.$code.'&grant_type='.$grant_type;
		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_HEADER, 0);  
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
	    curl_setopt($ch, CURL_SSLVERSION_SSL, 2);  
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);  
	    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);  
        $resultData = curl_exec($ch);
        $response = json_decode($resultData);  
        if(curl_errno($ch)){
            print_r(curl_error($ch));
        }
        curl_close($ch);



        if(empty($response->unionid)){
        	$result['errcode']= 1;			
			$result['data']= '获取unionid失败';
			$this->ajaxReturn($result,"JSON");	
        }


        $map['wechat_unionid'] = $response->unionid;
        $userInfo = M('User')->field('phone,user_id,img,username,session,sex,email,ry_token,personal_sign')->where($map)->find();
        if(!empty($userInfo)){
        	//微信登录操作
        	$userInfo = $this->wechatLogin($userInfo);

        	//重整发送的数组
        	$userInfo = $this->remakeUserInfo($userInfo);


		   	$result['errcode']= 0;			
			$result['data']= $userInfo;
			$this->ajaxReturn($result,"JSON");
        }else{
        	$response->binded = 'false';

        }
       
       	$result['errcode']= 0;			
		$result['data']= $response;
		$this->ajaxReturn($result,"JSON");
	
	    
	           
	    
    }


    //微信登录(生成ry_token 和 session)
    private function wechatLogin($one = array()){
    
    	//获取token
    	$User = M('User');
		if(empty($one['ry_token'])){
			$p = new \Org\Util\ServerAPI(C('Ry_AppKey'),C('Ry_AppSecret'));
			$portraitUri = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$one['img'];
			$ret = $p->getToken($one['user_id'],$one['username'],$portraitUri);
			$ret = json_decode($ret);
    		//ry_token存入数据库
    		$map['user_id'] = $one['user_id'];
    		if(!$User->where($map)->setField('ry_token',$ret->token)){
    			$result['errcode']= 1;
				$result['data']= '服务器繁忙';
    		}

			$one['ry_token'] =  $ret->token;
		}

		$u_Session=md5(md5($one['phone'].time()));



		//前台生成session
		session('wifi_user',$one);


		
		//存储接口session
	 	$affect = $User->where('phone='.$one['phone'])->setField('session',$u_Session);
	 	if(empty($affect)){
	 		$this->errorReturn('session存取失败');	
	 	}

	 	
		//登录成功后修改验证码，防止下次可继续登录
		//if(!M('verification')->where('telephone='.$u_Phone)->setField('code','****')) $this->errorReturn('短信修改失败');	
	 	$one['u_Session'] =  $u_Session;
	 	unset($one['session']);


	 	return $one;
		
    }



    //微信unionid 绑定手机号
    public function unionidBindPhone(){
    	$u_Phone = I('post.u_Phone','','trim');
    	$code = I('post.code','','trim');
		$unionid = I('post.unionid','','trim'); 
		$userName = I('post.userName','','trim');
		$headimgurl = I('post.headimgurl','','trim');
		$gender = I('post.gender','','trim');
		$encodestr = I('post.encodestr','','trim');
		$salt = 'action_unionidBindPhone';


		$this->checkTel($u_Phone,'手机号码有误');
		$this->checkNull($code,'验证码不能为空');





		$password = md5(md5($u_Phone.$code.$unionid.$userName.$headimgurl.$gender.$salt));
		//验证效验码
		if ($password !=$encodestr){
			$this->errorReturn($password);				
		}



		//判断验证码是否正确
		$verifyCode = M('Verification')->where('telephone='.$u_Phone)->getField('code');
		if($code != $verifyCode){
			$this->errorReturn('验证码不正确');
		}


		//判断验证码是否失效
		// if($code == '****'){
		// 	$this->errorReturn('验证码已失效');
		// }

		$User = M('User');
		$map['phone'] = $u_Phone;
		$info = $User->field('phone,user_id,img,username,session,sex,email,ry_token,personal_sign')->where($map)->find();


		//验证是否已绑定微信wechat_unionid
		$bindMap['wechat_unionid'] = $unionid;
		$is_bind = $User->where($map)->where($bindMap)->getField('user_id');
		if(!empty($is_bind)){
			$this->errorReturn('该手机号已绑定微信号');
		}




		//未注册用户注册
		if(empty($info)){
			$data['phone'] = $u_Phone;
			$data['level'] = 1;
			$data['point'] = 0;
			$data['email'] = 0;
			$data['img'] = 'noface.jpg';
			$data['time'] = time();
			$data['username'] = $userName;
			$data['sex'] = empty($gender) ? 1 : $gender;
			$data['unionid'] = $unionid;
			$data['personal_sign'] = '主人很懒，什么都没留下';
			$cid = $User->add($data);
			if(empty($cid)) $this->errorReturn('绑定失败');
			$data['user_id'] = $cid;
			$userInfo = $data;

			
		}else{
			//已注册用户绑定unionid字段
			if($User->where($map)->setField('wechat_unionid',$unionid) === false){
				$this->errorReturn('绑定失败');
			}
			$userInfo = $info;
		}


		//微信登录操作
        $userInfo = $this->wechatLogin($userInfo);


        //重整发送的数组
        $userInfo = $this->remakeUserInfo($userInfo);
       


       	$result['errcode']= 0;			
		$result['data']= $userInfo;
		$this->ajaxReturn($result,"JSON");


    }

    //重整返回的用户数组
    private function remakeUserInfo($userInfo = array()){
    	$userInfo['u_portrait'] = $this->SERVER_URL.$this->UPLOAD_PATH.'user/'.$userInfo['img'];
        unset($userInfo['img']);

        $userInfo['u_phone'] = $userInfo['phone'];
        unset($userInfo['phone']);

        $userInfo['u_name'] = $userInfo['username'];
        unset($userInfo['username']);

        $userInfo['gender'] = $userInfo['sex'];
        unset($userInfo['sex']);

        $userInfo['email'] = empty($userInfo['email']) ? 'unbind' : $userInfo['email'];
        $userInfo['personal_sign'] = empty($userInfo['personal_sign']) ? '主人很懒，什么都没留下' : $userInfo['personal_sign'];
       	$userInfo['ry_token'] = empty($userInfo['ry_token']) ? '' : $userInfo['ry_token'];
        $userInfo['binded'] = 'true';
        return $userInfo;
       
    }


	//验证是否为空
	protected function checkNull($str,$msg){ 
		if (empty($str)){
			$result['errcode']='1';
			$result['data']=$msg;
			$this->ajaxReturn($result,"JSON");
		}
	}

	//验证手机号码
	protected function checkTel($str,$msg){ 
		if(!preg_match("/1[3458]{1}\d{9}$/",$str)){  
		    $result['errcode']='1';
			$result['data']=$msg;
			$this->ajaxReturn($result,"JSON"); 
		}
	}
	


	//验证邮箱
    public function checkEmail($email,$msg){
   		$pattern = "/^([0-9A-Za-z\\-_\\.]+)@([0-9a-z]+\\.[a-z]{2,3}(\\.[a-z]{2})?)$/i";
	    if (!preg_match($pattern,$email)){ 
				$result['errcode']='1';
				$result['data']=$msg;
				$this->ajaxReturn($result,"JSON");
			}
		
	}





    //验证u_session
	protected function checkSession(){
		$u_Phone = I('post.u_Phone');
    	$u_Session = I('post.u_Session');
		$session = M("user")->where('phone='.$u_Phone)->getField('session');
		if ($session != $u_Session){
			$result['errcode']='1';
			$result['data']="session_error";
			$this->ajaxReturn($result,"JSON");			
		}
	}


	protected function chkUser($user_id,$token){
		$IsUserExist = M('users')->where(array('id'=>$user_id,'session'=>$token))->find();
		//echo M('users')->getlastsql();
		if(!$IsUserExist){
			$result['errcode']='1';
			$result['data']='用户状态错误！';
			$this->ajaxReturn($result,"JSON");				
		}			
	}
	

	//错误输出
	private function errorReturn($msg = '操作繁忙'){
		$result['errcode']= 1;
		$result['data']= $msg;  
		if($this->IS_LOG){
			$this->print_log('',$msg,ACTION_NAME);
		}
  		$this->ajaxReturn($result,"JSON");	
	}


	protected function getRandChar($length){
	   $str = null;
	   $strPol = "0123456789";
	   $max = strlen($strPol)-1;
	   for($i=0;$i<$length;$i++){
			$str.=$strPol[rand(0,$max)];//rand($min,$max)生成介于min和max两个数之间的一个随机整数
	   }
	   return $str;
	}
  
	protected  function gencode($telephone){
		$code = $this->getRandChar(4);
		$chkcode = M('verification')->where("telephone='$telephone'")->fetchSql(false)->find();
		if($chkcode){
			M('verification')->where("telephone='$telephone'")->fetchSql(false)->save(array("verificationcode"=>$code));
		}else{
			$add['telephone']=$telephone;
			$add['verificationcode']=$code;
			M('verification')->add($add);			
		}
		return $code;
	}
	
	protected  function get_curl_json($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        $result = curl_exec($ch);
        if(curl_errno($ch)){
            print_r(curl_error($ch));
        }
        curl_close($ch);
        //return json_decode($result,TRUE);
    }
	
	protected function push($msg="hello",$regid,$type,$title){			
		$url =U('push/index','msg='.$msg."&regid=".$regid."&type=".$type."&title=".$title);
		//echo $url;
		$this->get_curl_json($_SERVER['HTTP_HOST'].$url);
	}
	
	
		
	/*
	//改变任务状态
	public function chgstatus(){
        $ = I('');
        $ = I('');
		
		$this->checkNull($,'！');
		$this->checkNull($,'！');


		$result['errcode']='1';
		$result['message']='登录失败，用户名密码不匹配！';
		$this->ajaxReturn($result,"JSON");	
    }
	*/
	

	


     //随机数
    public function randstr($length = 4,$type = 'str'){
    	if($type == 'str'){
			$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_ []{}<>~`+=,.;:/?|';  
    	}else{
			$chars = '0123456789';  
    	}

    	for($i = 0;$i < $length; $i++){
    		$rand .= $chars[ mt_rand(0,strlen($chars)-1) ];
    	}
    	return $rand;
    }



	 /** 
	* @desc 根据两点间的经纬度计算距离 以米为单位
	* @param float $lat 纬度值 
	* @param float $lng 经度值 
	*/
	private function getDistance($lat1, $lng1, $lat2, $lng2) { 
	    $earthRadius = 6367000; //approximate radius of earth in meters 
	     
	    /* 
	    Convert these degrees to radians 
	    to work with the formula 
	    */
	     
	    $lat1 = ($lat1 * pi() ) / 180; 
	    $lng1 = ($lng1 * pi() ) / 180; 
	     
	    $lat2 = ($lat2 * pi() ) / 180; 
	    $lng2 = ($lng2 * pi() ) / 180; 
	     
	    /* 
	    Using the 
	    Haversine formula 
	     
	    http://en.wikipedia.org/wiki/Haversine_formula 
	     
	    calculate the distance 
	    */
	     
	    $calcLongitude = $lng2 - $lng1; 
	    $calcLatitude = $lat2 - $lat1; 
	    $stepOne = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2); 
	    $stepTwo = 2 * asin(min(1, sqrt($stepOne))); 
	    $calculatedDistance = $earthRadius * $stepTwo; 
	     
	    return round($calculatedDistance); 
	} 


	//前台页面获取session
	public function getSession(){
		if(IS_AJAX){
			$phone = I('post.phone');
			$map['phone'] = $phone;
			$session = M('User')->where($map)->getField('session');
			if(empty($session)){
				$result['errcode']= 1;
				$result['data']= 'session为空!';    
			}else{
				$result['errcode']= 0;
				$result['data']= $session;    
			}
				$this->ajaxReturn($result,"JSON");		

		}else{
			$result['errcode']= 1;
			$result['data']= '非法操作!';    
	     	$this->ajaxReturn($result,"JSON");		
		
		}
	}




	//写入日志
	private function print_log($fileName,$content,$action){
		if($this->IS_LOG){
			$post_data = I('post');
			$all_data = "【".date('Y-m-d H:i:s',time())."】\n";
			foreach ($_POST as $key => $value) {
				$post_data .=  "{$key} : {$value}\n";
			}

			$all_data = $all_data."对方IP：".get_client_ip()."\n显示内容：\"".$content ."\"\n模块: ".MODULE_NAME."\n控制器: ".CONTROLLER_NAME."\n方法：".$action."\n参数：\n".$post_data."\n";

			if(empty($fileName))  $fileName = date("Y-m-d",time()).'_'.MODULE_NAME;
			//$filePath = './';
			$filePath = './App/Runtime/Logs/Service/';
			$fileName = $filePath.$fileName;
			file_put_contents($fileName, $all_data,FILE_APPEND);
		}
	}

 
	
}
