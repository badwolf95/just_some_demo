<?php
/**
 * 公共模型，封装模型的公共方法
 */
namespace Home\Model;
use Think\Model;

class CommonModel extends Model {

	private $_db = '';

	public function __construct($_db){
		$this->_db = M($_db);
	}
	//数据读取
	public function readData($where,$order=array()){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->order($order)->select();
			return $res;
		}else{
			throw("where参数有误");
		}
	}
	//更新数据
	public function updateData($where,$data){

		if($where && is_array($where)){
			if($data && is_array($data)){
				$res = $this->_db->where($where)->save($data);	
				return $res;
			}else{
				throw("data数组非法");
			}
		}else{
			throw("where参数有误");
		}
	}
	//删除数据
	public function deleteData($where){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->delete();
			return $res;
		}else{
			throw("where参数有误");
		}
	}
}