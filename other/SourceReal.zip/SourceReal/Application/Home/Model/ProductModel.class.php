<?php
namespace Home\Model;
use Think\Model;

class ProductModel extends CommonModel {

	private $_db = '';

	public function __construct(){
		parent::__construct('product');
		$this->_db = M('product');
	}
	public function readData($where,$order){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->order($order)->select();
			return $res;
		}else{
			throw("where参数有误");
		}
	}
}