<?php
namespace Home\Controller;
use Think\Controller;

class CommonController extends Controller {

	public function __construct(){
		//分级导航栏和单页
    	$navs = D('Navbar');
		$navs = $navs->readNavbar(array('in','1'),array('in','1,2'));
		$this->assign('navs_fir',$navs[0]);
		$this->assign('navs_sec',$navs[1]);
		$this->assign('navs_3th',$navs[2]);
		//网站配置信息
		$website = D('website');
		$where['id'] = array('gt','0');
		$res = $website->readData($where);
		$this->assign("website",$res[0]);
		//产品文章
		$product = D('Product');
		$where['product_id'] = array('gt','0');
		$order = array('parent_id'=>'asc','listorder'=>'asc','product_id'=>'asc');
		$products = $product->readData($where,$order);
		$this->assign('products',$products);
		//左侧联系我们
		$contact = M('contact_sm');
		$content = $contact->select();
		$content[0]['content'] = htmlspecialchars_decode($content[0]['content']);
		$this->assign('contact',$content[0]);
		//服务板块
		$serviceObj = M('service');
		$order = array('listorder'=>'asc','id'=>'asc');
		$service = $serviceObj->order($order)->select();
		$this->assign('services',$service);
	}
}