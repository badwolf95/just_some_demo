<?php
namespace Home\Controller;
use Think\Controller;

class IndexController extends Controller {

    public function index(){

		//网站配置信息
		$website = D('website');
		$where['id'] = array('gt','0');
		$web = $website->readData($where);
		$this->assign("website",$web[0]);
		//网站是否可以访问
		$open = $web[0]['available'];
		if(!$open){
			$this->display('Other/close');
		}else{

		
			//分级导航栏和单页
	    	$navs = D('Navbar');
			$navs = $navs->readNavbar(array('in','1'),array('in','1,2'));
			$this->assign('navs_fir',$navs[0]);
			$this->assign('navs_sec',$navs[1]);
			$this->assign('navs_3th',$navs[2]);
			//产品文章
			$product = D('Product');
			$where['product_id'] = array('gt','0');
			$where['status'] = '1';
			$order = array('parent_id'=>'asc','listorder'=>'asc','product_id'=>'asc');
			$products = $product->readData($where,$order);
			$this->assign('products',$products);
			//左侧联系我们
			$contact = M('contact_sm');
			$content = $contact->select();
			$content[0]['content'] = htmlspecialchars_decode($content[0]['content']);
			$this->assign('contact',$content[0]);
			//服务板块
			$serviceObj = M('service');
			$where['status'] = '1';
			$order = array('listorder'=>'asc','id'=>'asc');
			$service = $serviceObj->where($where)->order($order)->select();
			$this->assign('services',$service);
			//welcome板块->about us
			$paper = M('paper');
			$aboutus = $paper->find(23);
			$aboutus['content'] = htmlspecialchars_decode($aboutus['content']);
			$aboutus['content'] = preg_replace("/<img.*?>/si",'',$aboutus['content']);
			$aboutus['content'] = substr($aboutus['content'],0,290);
			$this->assign('aboutus',$aboutus);
			//首页板块->lighting solution
			$lighting = M('paper');
			$light = $lighting->find(24);
			$light['content'] = htmlspecialchars_decode($light['content']);
			$light['content'] = preg_replace("/<img.*?>/si",'',$light['content']);
			$light['content'] = substr($light['content'],0,520);
			$this->assign('light',$light);
			//轮播小图
			$album = M('banner');
			$where['type'] = 2;
			$where['status'] = 1;
			$order = array('listorder'=>'asc','id'=>'asc');
			$albums = $album->where($where)->order($order)->select();
			$this->assign('albums',$albums);
			//轮播大图
			$banner = M('banner');
			$where['type'] = 1;
			$where['status'] = 1;
			$order = array('listorder'=>'asc','id'=>'asc');
			$banners = $banner->where($where)->order($order)->select();
			$this->assign('banners',$banners);


	        $this->display();
	    }
    }
}