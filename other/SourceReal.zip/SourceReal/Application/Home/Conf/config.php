<?php
return array(
	//'配置项'=>'配置值'
	'DB_TYPE'		=>	'mysql',
	'DB_HOST'		=>	'localhost',
	'DB_USER'		=>	'root',
	'DB_PWD'		=>	'',
	'DB_NAME'		=>	'sourcereal',
	'DB_CHARSET'	=>	'UTF8',
	'DB_PORT'		=>	'3306',
	'DB_PREFIX'		=>	'sr_',

);