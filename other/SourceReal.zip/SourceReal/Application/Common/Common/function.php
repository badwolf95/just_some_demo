<?php
/*
function show($status,$message,$data=array()){

	$arr = array(
		'status'	=>	$status,
		'message'	=>	$message,
		'data'		=>	$data,
	);
	exit($arr);
}*/