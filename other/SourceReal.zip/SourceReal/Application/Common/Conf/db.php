<?php 
return array(

	// 'DB_TYPE'		=>	'mysql',
	// 'DB_HOST'		=>	'localhost',
	// 'DB_USER'		=>	'root',
	// 'DB_PWD'		=>	'',
	// 'DB_NAME'		=>	'sourcereal',
	// 'DB_CHARSET'	=>	'UTF-8',
	// 'DB_PORT'		=>	'3306',
	// 'DB_PREFIX'		=>	'sr_',


);