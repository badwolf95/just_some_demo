<?php
return array(
	//'配置项'=>'配置值'
	// 'URL_CASE_INSENSITIVE'	=>	true,
	// 'LOAD_EXT_CONFIG'		=>	'db',
	// 'MD5_PREFIX'			=>	'SourceReal',
);