<?php

namespace Common\Model;
use 	Think\Model;

class CommonModel extends Model {

	$this->_db	=	'';

	public function __construct(){

		$this->_db	=	M();
	}

	public function readData($where){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->select();
			return $res;
		}else{
			throw("where参数非法");
		}
	}	


}