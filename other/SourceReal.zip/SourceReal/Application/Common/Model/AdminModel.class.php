<?php

namespace Common\Model;
use Think\Model;

class AdminModel extends Model {

	private $_db	= '';

	public function __construct(){

		$this->_db	=	M('admin');
	}

	public function readData($where){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->select();
			return $res;
		}else{
			throw("where参数非法");
		}
	}	
}