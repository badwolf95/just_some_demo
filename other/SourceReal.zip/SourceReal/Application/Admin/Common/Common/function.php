<?php 

//生成json数组
function show($status,$message,$data=array()){

	$arr = array(
		'status'	=>	$status,
		'message'	=>	$message,
		'data'		=>	$data,
	);
	exit(json_encode($arr));
}

//将时间戳转换成可读时间
function getTime($time){

	if(0 == $time){
		return "无";
	}else{
		return date("Y-m-d H:i:s",$time);
	}
}

//kindeditor需要的特殊返回数组
function showKind($status,$data){

	header("Content-Type:Application/json;charset=utf-8");
	if(0 == $status){
		$res = array(
			'error' => 0,
			'url'	=> $data,
		);
	}else{
		$res = array(
			'error'	=>	1,
			'message' => $data,
		);
	}
	exit(json_encode($res));
}