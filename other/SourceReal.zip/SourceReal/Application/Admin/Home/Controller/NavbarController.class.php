<?php 

namespace Home\Controller;
use Think\Controller;

class NavbarController extends CommonController {


	public function index(){
		$navs = D('Navbar');
		$navs = $navs->readNavbar(array('in','1,0'),array('in','1,2'));
		$this->assign('navs_fir',$navs[0]);
		$this->assign('navs_sec',$navs[1]);
		$this->assign('navs_3th',$navs[2]);
		$this->display();
	}

	public function add(){

		$navbar = M('navbar');
		$paper = M('paper');
		$data = array();
		if(IS_POST){
			$data['type'] = I('post.type');
			$data['navname'] = I('post.navname');
			$data['parent_id'] = I('parent_id');
			$data['status'] = I('status');
			$data['listorder'] = I('listorder');
			if(!$data['navname']){
				return show(0,'导航名不能为空');
			}
			$id = I('post.nav_id');
			if($id){
				$mes = "修改成功";
				$err = "修改失败";
				$mes2 = "修改单页成功";
				$err2 = "修改单页失败";
			}else{
				$mes = "添加成功";
				$err = "添加失败";
				$mes2 = "添加单页成功";
				$err2 = "添加单页失败";
			}
			//类型为1，属于导航
			if(1 == $data['type']){
				if($navbar->create($data)){
					if($id){
						$data['nav_id'] = $id;
						$res = $navbar->save($data);
						$where['nav_id'] = $id;
						$type['type'] = 1;
						$paper->where($where)->save($type);
					}else{
						$res = $navbar->add($data);
					}
					if($res){
						return show(1,$mes);
					}else{
						return show(0,$err);
					}
				}else{
					return show(0,$navbar->getError());
				}

			//类型为2，属于单页
			}elseif(2 == $data['type']){
				if($navbar->create($data)){
					$navbar->parent_id = '0';	
					if($id){
						$data['nav_id'] = $id;
						$res = $navbar->save($data);
						$where['nav_id'] = $id;
						$type['type'] = 2;
						$paper->where($where)->save($type);
						if($res){ $res = $id;}
					}else{
						$res = $navbar->add($data);
					}
					if($nav_id = $res){
						$paperdata = array();
						$paperdata['nav_id'] = $nav_id;
						$paperdata['type'] = '2';
						if($id){
							$where['nav_id'] = $nav_id;
							$paper = D("Paper")->readData($where);
							$paperdata['paper_id'] = $paper['paper_id'];
							$paperdata['update_time'] = time();
							$res = $paper->save($paperdata);
						}else{
							$paperdata['create_time'] = time();
							$res = $paper->add($paperdata);
						}
						if($res){
							return show(1,$mes2);
						}else{
							return show(0,$err2);
						}
					}else{
						return show(1,'修改成功');
					}
				}else{
					return show(0,$navbar->getError());
				}

			//类型为3，属于文章
			}else{
				return show(0,'分类值非法');
			}
		}else{
			$navs = D('Navbar');
			$navs = $navs->readNavbar();
			$this->assign('navs_fir',$navs[0]);
			$this->assign('navs_sec',$navs[1]);
			$this->assign('navs_3th',$navs[2]);
			// dump($navs[0]);
			// dump($navs[1]);
			// dump($navs[2]);
			if($id = I('get.id')){
				$where['nav_id'] = $id; 
				$nav = D('Navbar')->readData($where);
				if(!$nav){
					$this->display();
				}else{
					$this->assign('nav',$nav[0]);
					$this->display('Navbar/edit');
				}

			}else{
				$this->display();
			}
		}

	}

	public function edit(){

		$this->display();
	}

}