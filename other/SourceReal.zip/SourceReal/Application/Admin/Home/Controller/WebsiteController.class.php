<?php 

namespace Home\Controller;
use Think\Controller;

class WebsiteController extends Controller {


	public function index(){

		$website = D('website');
		$where['id'] = array('gt','0');
		$res = $website->readData($where);
		$this->assign("website",$res[0]);
		$this->display();
	}

	public function add(){

		$where['id'] = array('gt','0');
		$res = D("Website")->readData($where);
		$website = M("Website");
		if($website->create()){
			if(!$res){
				if($website->add()){
					return show(1,'添加成功');
				}else{
					return show(0,'添加失败');
				}
			}else{
				if($website->save()){
					return show(1,'修改成功');
				}else{
					return show(0,'修改失败');
				}
			}
		}else{
			show(0,$website->getError());
		}
		
	}

}