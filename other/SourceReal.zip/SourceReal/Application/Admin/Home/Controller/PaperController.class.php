<?php

namespace Home\Controller;
use Think\Controller;

class PaperController extends CommonController {

	public function index(){

		$where['paper_id'] = array('gt','0');
		$where['type'] = 2;
		$papers = D("Paper")->readData($where);
		$nav = D("Navbar");
		$navname = array();
		foreach($papers as $paper){
			$where['nav_id'] = $paper['nav_id'];
			$res = $nav->readData($where);
			$navname[$paper['nav_id']] = $res[0]['navname'];
			$status[$paper['nav_id']] = $res[0]['status'];
		}
		$contact = M('contact_sm');
		$contact_content = $contact->select();
		// $contact_content[0]['content'] = htmlspecialchars_decode($contact_content[0]['content']);
		$this->assign('contact_content',$contact_content[0]);
		$this->assign('navname',$navname);
		$this->assign('papers',$papers);
		$this->assign('status',$status);
		$this->display();
	}

	public function edit(){

		if(IS_POST){
			$paper = M("Paper");
			if($paper->create()){
				$paper->update_time = time();
				$res = $paper->save();
				if($res){
					return show(1,'修改成功');
				}else{
					return show(0,'修改失败');
				}
			}else{
				return show(0,$paper->getError());
			}
			
		}else{
			$id = I('get.id');
			$where['nav_id'] = $id;
			$paper = D('Paper')->readData($where);
			$this->assign('paper',$paper[0]);
			$this->display();
		}
	}

	public function editContact(){

		$contact = M('contact_sm');
		if(IS_POST){
			if(!I('post.id')){
				if($contact->create()){
					if($contact->add()){
						return show(1,'添加成功');
					}else{
						return show(0,'添加失败');
					}
				}else{
					return show(0,$contact->getError());
				}
			}else{
				if($contact->create()){
					$contact->update_time = time();
					if($contact->save()){
						return show(1,'修改成功');
					}else{
						return show(0,'修改失败');
					}
				}else{
					return show(0,$contact->getError());
				}
			}
		}else{
			$content = $contact->select();
			// $content[0]['content'] = htmlspecialchars_decode($content[0]['content']);
			$this->assign('contact',$content[0]);
			$this->display();
		}
	}

}