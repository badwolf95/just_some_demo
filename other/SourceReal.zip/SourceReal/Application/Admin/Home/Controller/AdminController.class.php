<?php 
namespace Home\Controller;
use Think\Controller;

class AdminController extends CommonController {


    public function __construct(){
        parent::__construct();
    }

	public function index(){
        $admin = D('Admin');
        $where['id'] = array('gt','0');
        $data  = $admin->readData($where);
        $this->assign('admins',$data);
        $this->display();
	}

	public function add(){
        //有ID为修改按钮动作
        if(I('get.id')){
                $id = I('get.id');
                $where['admin_id'] = $id;
                $data = D("Admin")->readData($where);
                $this->assign('admin',$data[0]);
                $this->display('Admin/edit');
        }else{
            //否则为添加/修改的提交
            if(IS_POST){
                //此处改为M方法，动态验证才行
                $admin = M('Admin');
                $rule =  array(
                            array('username','require','用户名不能为空',1),
                            array('password','require','密码不能为空',1),
                            array('email','email','邮箱格式错误',2),
                            array('re_password','password','两次输入密码不一致',1,'confirm'),
                            array('status','number','状态有误'),
                            array('username','','用户名已存在',0,'unique',3),
                );
                if($admin->validate($rule)->create()){
                    $admin->username = addslashes($admin->username);
                    $admin->password = md5(C("MD5_PREFIX").$admin->password);
                    //有id为修改
                    if(I('post.admin_id')){
                        $admin->update_time = time();
                        if($admin->save()){
                            return show(1,'修改成功');
                        }else{
                            return show(0,'修改失败');
                        }
                    }else{
                        $admin->create_time = time();
                        if($admin->add()){
                            return show(1,'添加成功');
                        }else{
                            return show(0,'数据入库失败');
                        }
                    }
                }else{
                    $message = $admin->getError();
                    if($message){
                        return show(0,$message);
                    }else{
                        return show(0,'程序有误');
                    }
                }
            }else{
    	      $this->display();
            }
        }     
	}
}