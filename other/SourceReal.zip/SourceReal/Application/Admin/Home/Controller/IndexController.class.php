<?php
namespace Home\Controller;
use Think\Controller;

class IndexController extends CommonController {


    public function index(){
    	$this->display();
    }
    public function edit(){

    	$this->display();
    }
}