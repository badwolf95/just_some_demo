<?php
namespace Home\Controller;
use Think\Controller;

class BannerController extends CommonController {

	public function index(){

		$banner = M('banner');
		$where['type'] = 1;
		$order = array('listorder'=>'asc','id'=>'asc');
		$banners = $banner->where($where)->order($order)->select();
		$this->assign('banners',$banners);
		$this->display();
	}

	public function add(){

		$banner = D('banner');
		if(IS_POST){
			$banner->add();
		}else{
			$this->display();
		}
	}

	public function edit(){

		$banner = D('banner');
		if(IS_POST){
			return $banner->save();
		}else{

			$id = I('get.id');
			if(!$id){
				return false;
			}
			$banner = $banner->find($id);
			$this->assign('banner',$banner);
			$this->display();
		}
	}


}