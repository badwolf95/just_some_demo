<?php
namespace Home\Controller;
use Think\Controller;

class AlbumController extends CommonController {

	public function index(){

		$album = M('banner');
		$where['type'] = 2;
		$order = array('listorder' => 'asc','id' => 'asc');
		$albums = $album->where($where)->order($order)->select();
		$this->assign('albums',$albums);
		$this->display();
	}

	public function add(){

		$album = D('banner');
		if(IS_POST){
			$album->add();
		}else{
			$this->display();
		}
	}

	public function edit(){

		$album = D('banner');
		if(IS_POST){
			$album->save();
		}else{
			$id = I('get.id');
			$album = $album->find($id);
			$this->assign('album',$album);
			$this->display();
		}
	}
}