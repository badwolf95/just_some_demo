<?php
namespace Home\Controller;
use Think\Controller;

class ImageController extends Controller {

	//kindeditor需要的特殊返回规范
	public function kindupload(){

		$res = D('UploadImage')->upload('image');
		if($res){
			return showKind(0,$res);
		}else{
			return showKind(1,'上传失败');
		}
		
	}
	//input框上传文件
	public function fileUpload(){

		$res = D('UploadImage')->upload('file');
		if($res){
			return show(1,'上传成功',$res);
		}else{
			return show(0,'上传失败');
		}
	}

	public function noallow(){
		return showKind(1,'这个小窗口不允许有图片');
	}

}