<?php

namespace Home\Controller;
use Think\Controller;

class FacilityController extends CommonController {

	public function index(){

		$facility = D('Facility');
		$where['facility_id'] = array('gt','0');
		$order = array('parent_id'=>'asc','listorder'=>'asc','facility_id'=>'asc');
		$facilitys = $facility->readData($where,$order);
		$navbar = M('Navbar');
		$navs = $navbar->select();
		// dump($navs);
		// dump($products);
		$this->assign('navbar',$navs);
		$this->assign('facilitys',$facilitys);
		$this->display();
	}
	public function add(){

		if(IS_POST){
			// dump($_POST);
			$facility = M('facility');
			$rule = array(
				array('resume','require','简介不能为空'),
				array('resume','','该简介已存在',1,'unique'),
				array('parent_id','number','所属栏目不能为空'),
				array('thumb','require','请上传简介图片'),

			);
			if($facility->validate($rule)->create()){
				$facility->create_time = time();
				if($facility->add()){
					return show(1,'简介添加成功');
				}else{
					return show(0,'简介添加失败');
				}
			}else{
				return show(0,$facility->getError());
			}
		}else{

			$navs = D('Navbar');
			$navs = $navs->readNavbar();
			$this->assign('navs_fir',$navs[0]);
			$this->assign('navs_sec',$navs[1]);
			$this->assign('navs_3th',$navs[2]);
			$this->display();
		}		
	}

	public function edit(){

		if(IS_POST){
			$facility = M('facility');
			$rule = array(
				array('resume','require','简介不能为空'),
				array('thumb','require','请上传图片'),
				array('parent_id','require','请选择相应栏目'),
			);
			if($facility->validate($rule)->create()){
				$facility->update_time = time();
				if($facility->save()){
					return show(1,'性能测试修改成功');
				}else{
					return show(0,'性能测试修改失败');
				}
			}else{
				return show(0,$facility->getError());
			}
		}else{
			$id = I('get.id');
			$where['facility_id'] = $id;
			$facility = M('facility')->where($where)->find();
			$navs = D('Navbar');
			$navs = $navs->readNavbar();
			$this->assign('navs_fir',$navs[0]);
			$this->assign('navs_sec',$navs[1]);
			$this->assign('navs_3th',$navs[2]);
			$this->assign('facility',$facility);
			$this->display();
		}
	}

	
}