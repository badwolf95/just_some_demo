<?php
/**
 * 公共控制器，封装一些公共的操作
 */
namespace Home\Controller;
use Think\Controller;

class CommonController extends Controller {

	public function __construct(){

		parent::__construct();
		$this->_init();
	}
    //判断是否已经登陆，未登录则跳转到登录界面
	public function _init(){

		$res = $this->isLogin();
		if(false == $res){
			redirect('/admin.php?c=login&a=index');
		}
	}
    //获取登陆用户的session信息
	public function getLoginUser(){
		return $this->adminUser = session('adminUser');
	}
    //判断是否已经登陆
	public function isLogin(){

		$res = $this->getLoginUser();
		if($res && is_array($res)){
			return true;
		}else{
			return false;
		}
	}
    //删除
	public function deleteMany(){

		$id = I('post.id');
        if(!$id){
            return show(0,'请先选择');
        }
		$ids = array();
		if(!is_array($id)){
			$ids[] = $id;
		}else{
			$ids = $id;
		}
        $id_name = I('post.id_name');
        $table = I('post.table');
        if($_POST['table2'] != 'null'){
        	$table2 = I('post.table2');
        }
        $error = array();
        foreach($ids as $id){
            $where[$id_name] = $id;
            $pro = M($table)->where($where)->find();
            if($pro['thumb']){
            	unlink($pro['thumb']);
            }
            $res = D($table)->deleteData($where);
            if($table2){
            	$res2 = D($table2)->deleteData($where);
            }
            if(!$res){
                $error[] = $id;
            }
        }
        if(!$error){
            return show(1,'删除成功了');
        }else{
            $err = implode(',',$error);
            return show(0,'id号为'.$err.'的删除失败');
        }
	}
    //改变单个状态
	public function changeStatus(){

		$id_name = I('post.id_name');
		$table = I('post.table');
		$status = I('post.status');
        $id = I('post.id');
        $where[$id_name] = $id;
        if($status == 1){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        try{
            $res = D($table)->updateData($where,$data);
            if($res){
                $data['id'] = $id;
                return show(1,'状态修改成功',$data);
            }else{
                return show(0,'状态修改失败');
            }
        }catch(Exception $e){
            return show(0,$e->getMessage());
        }
	}
    //批量“可用”
	public function makePosible(){
        return $this->makeStatus(1);
    }
    //批量“不可用”
    public function makeImposible(){
        return $this->makeStatus(0);
    }
    //批量“可用不可用”封装
    public function makeStatus($type){

        $ids = I('post.id');
        if(!$ids){
            return show(0,'请先选择');
        }
        $id_name = I('post.id_name');
        $table = I('post.table');
        $error = array();
        foreach($ids as $id){
             $where[$id_name] = $id;
            $data['status'] = $type;
            $res = D($table)->updateData($where,$data);
            if(!$res){
                $error[] = $id;
            }
        }
        if($error){
            $err = implode(',',$error);
            $mes = "ID为：".$err."的状态不变";
            exit(show(1,$mes));
        }else{
            exit(show(1,"状态全部改变"));
        }
    }
    //更新排序
    public function listorder(){

        $data = I('post.listorder');
        // dump($_POST);
        $table = I('post.table');
        $id_name = I('post.id_name');
        $error = array();
        $facility = D($table);
        foreach($data as $k=>$v){
            $where[$id_name] = intval($k);
            $data['listorder'] = intval($v);
            $res = $facility->updateData($where,$data);
            if(!$res){
                $error[] = $k;
            }
        }
        return show(1,'更新成功');
    }
}