<?php

namespace Home\Controller;
use Think\Controller;

class ProductController extends CommonController {

	public function index(){

		$product = D('Product');
		$where['product_id'] = array('gt','0');
		$order = array('parent_id'=>'asc','listorder'=>'asc','product_id'=>'asc');
		$products = $product->readData($where,$order);
		$navbar = M('Navbar');
		$navs = $navbar->select();
		// dump($navs);
		// dump($products);
		$this->assign('navbar',$navs);
		$this->assign('products',$products);
		$this->display();
	}

	public function add(){

		if(IS_POST){
			// dump($_POST);
			$product = M('product');
			$rule = array(
				array('title','require','文章名不能为空'),
				array('title','','文章名已存在',1,'unique'),
				array('parent_id','number','所属栏目不能为空'),
				array('thumb','require','请上传文章封面'),

			);
			if($product->validate($rule)->create()){
				$product->create_time = time();
				if($product->add()){
					return show(1,'文章添加成功');
				}else{
					return show(0,'文章添加失败');
				}
			}else{
				return show(0,$product->getError());
			}
		}else{

			$navs = D('Navbar');
			$navs = $navs->readNavbar();
			$this->assign('navs_fir',$navs[0]);
			$this->assign('navs_sec',$navs[1]);
			$this->assign('navs_3th',$navs[2]);
			$this->display();
		}		
	}

	public function edit(){

		if(IS_POST){
			// dump($_POST);
			$product = M('product');
			if($product->create()){
				$product->update_time = time();
				if($product->save()){
					return show(1,'文章修改成功');
				}else{
					return show(0,'文章修改失败');
				}
			}else{
				return show(0,$product->getError());
			}
		}else{
			$id = I('get.id');
			$where['product_id'] = $id;
			$product = M('product')->where($where)->find();
			$navs = D('Navbar');
			$navs = $navs->readNavbar();
			$this->assign('navs_fir',$navs[0]);
			$this->assign('navs_sec',$navs[1]);
			$this->assign('navs_3th',$navs[2]);
			$this->assign('product',$product);
			$this->display();
		}

	}


}