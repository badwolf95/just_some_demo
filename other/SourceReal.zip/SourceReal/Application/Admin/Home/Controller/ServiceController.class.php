<?php
namespace Home\Controller;
use Think\Controller;

class ServiceController extends CommonController {



	public function index(){

		$serviceObj = M('service');
		$order = array('listorder'=>'asc','id'=>'asc');
		$service = $serviceObj->order($order)->select();
		$this->assign('services',$service);
		$this->display();
	}

	public function add(){

		$service = M('service');
		if(IS_POST){
			$rule = array(
				array('title','require','简介不能为空'),
				array('url','require','超链接不能为空'),
				array('thumb','require','链接图片不能为空'),
			);
			if($service->validate($rule)->create()){
				$service->create_time = time();
				if($service->add()){
					return show(1,'提交成功');
				}else{
					return show(0,'提交失败');
				}
			}else{
				return show(0,$service->getError());
			}

		}else{
			$this->display();
		}
	}

	public function edit(){

		$service = M('service');
		if(IS_POST){
			// dump($_POST);
			if($service->create()){
				$service->update_time = time();
				if($service->save()){
					return show(1,'修改成功');
				}else{
					return show(0,'修改失败');
				}
			}else{
				return show(0,$service->getError());
			}
		}else{
			$id = I('get.id');
			$svc = $service->find($id);
			$this->assign('service',$svc);
			$this->display();
		}
	}

}