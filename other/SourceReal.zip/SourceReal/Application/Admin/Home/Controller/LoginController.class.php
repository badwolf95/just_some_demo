<?php 
namespace Home\Controller;
use Think\Controller;
 
class LoginController extends Controller {

	 public function index(){

    	if($_POST['username']){
    		$username = I('post.username');
    		$password = I('post.password');
    		if(!$username){
    			return show(0,'用户名不能为空');
    		}elseif(!$password){
    			return show(0,'密码不能为空');
    		}else{
    			$username = addslashes($username);
    			$password = md5(C('MD5_PREFIX').$password);
    			$where = array(
    				'username'	=>	array('eq',$username),
    				'password'	=>	array('eq',$password),
    			);
                // $admin = new \Home\Model\CommonModel('admin');
                $admin = D("admin");
    			$res = $admin->readData($where);
    			if(count($res)){
                    if($res[0]['status'] == 1){
                        session('adminUser',$res[0]);
                        return show(1,'登陆成功');
                    }else{
                        return show(0,'该账号已被禁用');
                    }
                }else{
                    return show(0,'用户名或密码错误');
                }
    		}
    	}else{
            $res = session('adminUser');
            if(isset($res) && $res){
                $this->display('Index/index');
            }else{
    		  $this->display();
            }
    	}
    }

    public function logout(){

        session('adminUser',null);
        $this->display('Login/index');
    }
}