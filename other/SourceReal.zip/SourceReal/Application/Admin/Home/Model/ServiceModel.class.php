<?php
namespace Home\Model;
use Think\Model;
 
class ServiceModel extends CommonModel {

	private $_db = '';

	public function __construct(){
		parent::__construct('service');
		$this->_db = M('service');
	}
}