<?php
namespace Home\Model;
use Think\Model;

class PaperModel extends CommonModel {

	private $_db = '';

	public function __construct(){
		parent::__construct('paper');
		$this->_db = M('paper');
	}
}