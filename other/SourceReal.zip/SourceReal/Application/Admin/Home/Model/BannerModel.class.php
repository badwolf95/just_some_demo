<?php
namespace Home\Model;
use Think\Model;

class BannerModel extends CommonModel {

	private $_db = '';

	public function __construct(){
		parent::__construct('banner');
		$this->_db = M('banner');
	}

	


}