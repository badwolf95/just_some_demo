<?php
namespace Home\Model;
use Think\Model;

class NavbarModel extends CommonModel {

	private $_db  = '';

	public function __construct(){
		parent::__construct('navbar');
		$this->_db = M('navbar');
	}

	//手动递归
	public function readNavbar($status='1',$type='1'){

		$where['parent_id'] = '0'; 
		$where['status'] = $status;
		$where['type'] = $type;
		$nav_fir = $this->_db->where($where)->order('listorder asc,nav_id asc')->select();
		//第二层
		if($nav_fir){
			$nav_sec = array();
			foreach($nav_fir as $nav){
				$where['parent_id'] = $nav['nav_id']; 
				$where['status'] = $status;
				$where['type'] = $type;
				$nav_data = $this->_db->where($where)->order('listorder asc,nav_id asc')->select();
				if($nav_data){
					$nav_sec[$nav['nav_id']] = $nav_data;
				}
			}
			//第三层
			if($nav_sec){
				$nav_3th = array();
				foreach($nav_sec as $nn){
					foreach($nn as $n){

						$where['parent_id'] = $n['nav_id']; 
						$where['status'] = $status;
						$where['type'] = $type;
						$nav_data2 = $this->_db->where($where)->order('listorder asc,nav_id asc')->select();
						if($nav_data2){
							$nav_3th[$n['nav_id']] = $nav_data2;
						}
					}
				}
			}
			$navbars = array();
			$navbars[] = $nav_fir;
			$navbars[] = $nav_sec;
			$navbars[] = $nav_3th;
			return $navbars;
		}else{
			return '';
		}
	}
}