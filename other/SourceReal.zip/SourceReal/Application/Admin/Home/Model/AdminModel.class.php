<?php
namespace Home\Model;
use Think\Model;

class AdminModel extends CommonModel {

	private 	$_db	= '';
	
	public function __construct(){
		parent::__construct('admin');
		$this->_db = M('admin');
	}
}