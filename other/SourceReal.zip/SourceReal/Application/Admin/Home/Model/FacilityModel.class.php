<?php
namespace Home\Model;
use Think\Model;
 
class FacilityModel extends CommonModel {

	private $_db = '';

	public function __construct(){
		parent::__construct('facility');
		$this->_db = M('facility');
	}
}