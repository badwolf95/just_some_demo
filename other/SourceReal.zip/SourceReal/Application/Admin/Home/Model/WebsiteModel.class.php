<?php
namespace Home\Model;
use Think\Model;

class WebsiteModel extends CommonModel {

	private $_db = '';

	public function __construct(){
		parent::__construct('website');
		$this->_db = M("website");
	}
}