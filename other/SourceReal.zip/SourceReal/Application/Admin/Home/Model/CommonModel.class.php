<?php
/**
 * 公共模型，封装模型的公共方法
 */
namespace Home\Model;
use Think\Model;

class CommonModel extends Model {

	private $_db = '';

	public function __construct($_db){
		$this->_db = M($_db);
	}
	//数据读取
	public function readData($where,$order=array()){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->order($order)->select();
			return $res;
		}else{
			throw("where参数有误");
		}
	}
	//更新数据
	public function updateData($where,$data){

		if($where && is_array($where)){
			if($data && is_array($data)){
				$res = $this->_db->where($where)->save($data);	
				return $res;
			}else{
				throw("data数组非法");
			}
		}else{
			throw("where参数有误");
		}
	}
	//删除数据
	public function deleteData($where){

		if($where && is_array($where)){
			$res = $this->_db->where($where)->delete();
			return $res;
		}else{
			throw("where参数有误");
		}
	}
	//添加
	public function add(){

		if($this->_db->create()){
			$this->_db->create_time = time();
			if($this->_db->add()){
				return show(1,'添加成功');
			}else{
				return show(0,'添加失败');
			}
		}else{
			return show(0,$this->_db->getError());
		}
	}
	//修改
	public function save(){

		if($this->_db->create()){
			if($this->_db->save()){
				return show(1,'修改成功');
			}else{
				return show(0,'修改失败');
			}
		}else{
			return show(0,$this->_db->getError());
		}
	}
	//查找
	public function find($id){

		if($id){
			return $this->_db->find($id);
		}else{
			return false;
		}
	}
}