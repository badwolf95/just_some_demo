/*
SQLyog Ultimate v11.27 (64 bit)
MySQL - 5.6.17 : Database - sourcereal
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sourcereal` /*!40100 DEFAULT CHARACTER SET utf8 */;

/*Table structure for table `sr_admin` */

DROP TABLE IF EXISTS `sr_admin`;

CREATE TABLE `sr_admin` (
  `admin_id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `type` int(1) DEFAULT '1' COMMENT '权限管理',
  `status` int(1) NOT NULL,
  `create_time` int(10) NOT NULL,
  `lastlogin_time` int(10) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='管理员表';

/*Data for the table `sr_admin` */

insert  into `sr_admin`(`admin_id`,`username`,`password`,`email`,`type`,`status`,`create_time`,`lastlogin_time`) values (1,'admin','a1c129bcbe722458e2ffd2855abd6173','',1,1,1469778924,1469778924),(32,'admin2','a1c129bcbe722458e2ffd2855abd6173','',1,1,1469864338,0);

/*Table structure for table `sr_banner` */

DROP TABLE IF EXISTS `sr_banner`;

CREATE TABLE `sr_banner` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `thumb` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `create_time` int(10) NOT NULL,
  `listorder` mediumint(4) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `type` int(1) DEFAULT '1',
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='首页大轮播图';

/*Data for the table `sr_banner` */

insert  into `sr_banner`(`id`,`thumb`,`url`,`create_time`,`listorder`,`status`,`type`,`cn`) values (17,'/upload/2016/08/03/57a15b2d26aa3.jpg','',1470192431,3,1,1,0),(18,'/upload/2016/08/03/57a15b65988a6.png','',1470192487,0,1,2,0),(19,'/upload/2016/08/03/57a15c013173a.png','',1470192645,0,1,2,0),(20,'/upload/2016/08/03/57a15c132d5c5.png','',1470192660,0,1,2,0),(21,'/upload/2016/08/03/57a15c297e4eb.png','',1470192682,2,1,2,0),(22,'/upload/2016/08/03/57a15c330914c.png','',1470192692,0,1,2,0),(23,'/upload/2016/08/03/57a15c3b921e4.png','',1470192700,0,1,2,0),(24,'/upload/2016/08/03/57a15f1a1b511.png','',1470193435,4,1,1,0),(25,'/upload/2016/08/03/57a15f2519596.jpg','',1470193446,3,1,1,0),(26,'/upload/2016/08/03/57a15f3316625.png','',1470193460,2,1,1,0),(27,'/upload/2016/08/03/57a1686f47bb3.jpg','http://www.baidu.com',1470195824,1,1,1,0);

/*Table structure for table `sr_contact_sm` */

DROP TABLE IF EXISTS `sr_contact_sm`;

CREATE TABLE `sr_contact_sm` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `update_time` int(10) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='首页联系我们简介';

/*Data for the table `sr_contact_sm` */

insert  into `sr_contact_sm`(`id`,`content`,`update_time`,`cn`) values (1,'&lt;p&gt;\r\n	Xiamen Source Real Industrial Co., Ltd.\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Tel:0086 1526 0183 378\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Email:&lt;a href=&quot;http://michelle@source-real.com&quot; target=&quot;_blank&quot;&gt;michelle@source-real.com&lt;/a&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Skype:&lt;a href=&quot;http://michelle@source-real.com&quot; target=&quot;_blank&quot;&gt;michelle@source-real.com&amp;nbsp;&lt;/a&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Website:&lt;a href=&quot;http://www.source-real.com/&quot; target=&quot;_blank&quot;&gt;www.source-real.com&amp;nbsp;&lt;/a&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;a href=&quot;http://http://sourcereal.com/public/home/content/contact-us.html&quot; target=&quot;_blank&quot;&gt;[Global Office information......]&lt;/a&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;',1470218660,0);

/*Table structure for table `sr_facility` */

DROP TABLE IF EXISTS `sr_facility`;

CREATE TABLE `sr_facility` (
  `facility_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(6) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `resume` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  `listorder` mediumint(4) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) DEFAULT '0',
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`facility_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='性能测试图片表';

/*Data for the table `sr_facility` */

insert  into `sr_facility`(`facility_id`,`parent_id`,`thumb`,`resume`,`status`,`listorder`,`create_time`,`update_time`,`cn`) values (3,68,'/upload/2016/08/02/57a01b0b6e315.png','Integrating Sphere',1,0,1470110477,0,0),(4,68,'/upload/2016/08/02/57a01b262fe32.png','Light Distribution Chamber',1,0,1470110504,0,0),(5,68,'/upload/2016/08/02/57a01b378069e.png','Color Spectrum',1,0,1470110520,0,0),(6,68,'/upload/2016/08/02/57a01b47e929c.png','Temperature Rise Tester',1,0,1470110537,0,0),(7,68,'/upload/2016/08/02/57a01b578fb63.png','Leakage Current /Pressure Tester',1,0,1470110553,0,0),(8,68,'/upload/2016/08/02/57a01b691a5d7.png','Salt Spray Tester',1,0,1470110570,0,0),(9,68,'/upload/2016/08/02/57a01b7830287.png','Thermal Shock Chamber',1,0,1470110585,0,0),(10,69,'/upload/2016/08/02/57a01b9b7fdfe.jpg','Apprearance inspection',1,0,1470110620,0,0),(11,69,'/upload/2016/08/02/57a01bacb37a5.jpg','Aging line',1,0,1470110638,0,0);

/*Table structure for table `sr_log` */

DROP TABLE IF EXISTS `sr_log`;

CREATE TABLE `sr_log` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `action` varchar(40) NOT NULL,
  `ip` varchar(128) NOT NULL,
  `ac_time` int(10) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='后台操作日志';

/*Data for the table `sr_log` */

/*Table structure for table `sr_navbar` */

DROP TABLE IF EXISTS `sr_navbar`;

CREATE TABLE `sr_navbar` (
  `nav_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `navname` varchar(30) NOT NULL,
  `parent_id` mediumint(6) NOT NULL,
  `listorder` mediumint(4) NOT NULL,
  `status` int(1) NOT NULL,
  `type` int(1) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`nav_id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8 COMMENT='导航栏';

/*Data for the table `sr_navbar` */

insert  into `sr_navbar`(`nav_id`,`navname`,`parent_id`,`listorder`,`status`,`type`,`cn`) values (58,'Home',0,0,1,1,0),(59,'About us',0,0,1,2,0),(60,'Products',0,0,1,1,0),(61,'Capabilities',0,0,1,1,0),(62,'Lighting Solutions',0,0,1,2,0),(63,'Contact Us',0,0,1,2,0),(64,'Troffer with Prismatic Cover',60,0,1,1,0),(65,'Troffer with Opal Cover',60,0,1,1,0),(66,'Troffer with Center Len',60,0,1,1,0),(67,'Replacement Troffer Kit',60,0,1,1,0),(68,'Testing facilities',61,0,1,1,0),(69,'Assembly shop',61,0,1,1,0);

/*Table structure for table `sr_paper` */

DROP TABLE IF EXISTS `sr_paper`;

CREATE TABLE `sr_paper` (
  `paper_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `nav_id` mediumint(6) NOT NULL,
  `content` text,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  `type` int(1) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`paper_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='单页导航';

/*Data for the table `sr_paper` */

insert  into `sr_paper`(`paper_id`,`nav_id`,`content`,`create_time`,`update_time`,`type`,`cn`) values (23,59,'&lt;p&gt;\r\n	&lt;img src=&quot;/upload/2016/08/04/57a2c2ef9c397.jpg&quot; alt=&quot;&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	Xiamen Source Real Industrial Co.,Ltd. is a professional lighting fixture factory located in Xiamen, China. We started our specific lighting fixtures with providing customers products tailor-made for their projects. With rich experience and knowledge to the US market, we are now focusing on what we are very confident in -- troffers with best cost-effective solutions. We always spend intensive time in design, innovation in easy installation and trying to save cost and time for customers, and help customers to win larger market share.\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	Our company have strong advantage in our R&amp;amp;D team and their ability to provide specific lighting solutions according to customers’ project requirements. We have our own machining equipment for the metal base of troffers, from material-income to surface painting, to make sure of precise match in size, and best quality in use. The LED chips and drivers we use are also patented and UL listed, to make sure of safe use long life .\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;',1470108579,1470284529,2,0),(24,62,'&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	&amp;nbsp;&lt;img src=&quot;/upload/2016/08/02/57a0160a19420.jpg&quot; alt=&quot;&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	As a professional LED lighting company, we have a professional R &amp;amp; D design team. Continuous product innovation and integrated production procedures provide users with safe, stable and forward-looking lighting products.\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	The presence of light: gives courage to the survival of mankind. The introduce of natural light is kind of superior enhancement to quality of human life in the future.&amp;nbsp;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	We are built with senior professional lighting designers, to provide comprehensive lighting solutions, such as Star Hotel Lighting, Club Lighting, Home Lighting, Office Lighting, Public Lighting, and Intelligent Lighting Systems. &quot;Light&quot; is closer and closer to human life. Energy saving, environmental protection, safety and your satisfaction in “use of light” is our aim!\r\n&lt;/p&gt;',1470108650,1470109196,2,0),(25,63,'&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;span style=&quot;font-size:small;&quot;&gt;&lt;strong&gt;Xiamen Source Real Industrial Co.,Ltd.&amp;nbsp;&lt;br /&gt;\r\n&lt;/strong&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;img src=&quot;/upload/2016/08/02/57a0162bb5567.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p style=&quot;font-family:Verdana, Arial, Helvetica, sans-serif;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;strong&gt;&lt;br /&gt;\r\nXiamen Source Real Industrial Co.,Ltd.&lt;br /&gt;\r\n&lt;/strong&gt;Add: F8 G Unit 03 Building B Xiamen International Shipping Center,&amp;nbsp;&lt;br /&gt;\r\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;No. 97 Xiang Yu Road, 361000 Xiamen, China&lt;br /&gt;\r\nTel: 0086 1526 0183 378\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	Email:&amp;nbsp;&lt;a href=&quot;mailto:michelle@source-real.com&quot;&gt;michelle@source-real.com&lt;/a&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;',1470108669,1470109279,2,0);

/*Table structure for table `sr_product` */

DROP TABLE IF EXISTS `sr_product`;

CREATE TABLE `sr_product` (
  `product_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(6) NOT NULL,
  `title` varchar(50) NOT NULL COMMENT '产品文章标题',
  `thumb` varchar(100) NOT NULL,
  `feature` text,
  `content` text,
  `status` int(1) NOT NULL,
  `listorder` mediumint(4) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  `type` int(1) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='产品文章表';

/*Data for the table `sr_product` */

insert  into `sr_product`(`product_id`,`parent_id`,`title`,`thumb`,`feature`,`content`,`status`,`listorder`,`create_time`,`update_time`,`type`,`cn`) values (14,64,' With 3 lighting bars','/upload/2016/08/02/57a0181cceaea.jpg','&lt;ul&gt;\r\n	&lt;li&gt;\r\n		1.Rugged steel sheet, slim openable integrated structure of 55mm height.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.Prismatic cover with 3 light bars, anti-glare design.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.High reflective NT(Nano Technology).\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		4.High quality built-in driver.\r\n	&lt;/li&gt;\r\n&lt;/ul&gt;','&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span&gt;&lt;img width=&quot;758&quot; height=&quot;180&quot; style=&quot;width:613px;height:149px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/02/57a01853001f2.png&quot; /&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;903&quot; height=&quot;199&quot; style=&quot;width:616px;height:110px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a3236b139f3.png&quot; /&gt;\r\n&lt;/p&gt;',1,1,1470109785,1470309236,3,0),(15,65,'Troffer with Opal Cover','/upload/2016/08/02/57a019124bfe2.png','&lt;ul&gt;\r\n	&lt;li&gt;\r\n		1.Rugged steel sheet, slim openable integrated structure of 55mm height.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.Prismatic cover with 3 light bars, anti-glare design.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.High reflective NT(Nano Technology).\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		4.High quality built-in driver.\r\n	&lt;/li&gt;\r\n&lt;/ul&gt;','&lt;p style=&quot;color:#000000;text-indent:0px;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;img width=&quot;760&quot; height=&quot;181&quot; style=&quot;width:599px;height:152px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a323c545cb5.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;color:#000000;text-indent:0px;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;img width=&quot;758&quot; height=&quot;179&quot; style=&quot;width:601px;height:139px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a323b01efaf.png&quot; /&gt;&amp;nbsp;\r\n&lt;/p&gt;',1,0,1470110003,1470309324,3,0),(16,66,'Arc sky','/upload/2016/08/02/57a019494a470.jpg','&lt;ul&gt;\r\n	&lt;li&gt;\r\n		1.Rugged steel sheet, slim openable integrated structure of 55mm height.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.Prismatic cover with 3 light bars, anti-glare design.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.High reflective NT(Nano Technology).\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		4.High quality built-in driver.\r\n	&lt;/li&gt;\r\n&lt;/ul&gt;','&lt;p style=&quot;color:#000000;text-indent:0px;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;color:#000000;text-indent:0px;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;img width=&quot;760&quot; height=&quot;180&quot; style=&quot;width:598px;height:155px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/02/57a019658ef75.png&quot; /&gt;.&lt;img width=&quot;905&quot; height=&quot;200&quot; style=&quot;width:601px;height:154px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a3238635e53.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470110056,1470309272,3,0),(17,66,' Dual arc','/upload/2016/08/02/57a01a501ba9f.jpg','&lt;ul&gt;\r\n	&lt;li&gt;\r\n		1.Rugged steel sheet, slim openable integrated structure of 55mm height.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.Prismatic cover with 3 light bars, anti-glare design.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.High reflective NT(Nano Technology).\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		4.High quality built-in driver.\r\n	&lt;/li&gt;\r\n&lt;/ul&gt;','&lt;div id=&quot;pb-left-column&quot; style=&quot;margin:0px;padding:0px;color:#000000;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;div style=&quot;margin:0px;padding:0px;&quot;&gt;\r\n		&lt;p&gt;\r\n			&lt;br /&gt;\r\n		&lt;/p&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;759&quot; height=&quot;181&quot; style=&quot;width:606px;height:144px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/02/57a01a6e5b5f9.png&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;904&quot; height=&quot;199&quot; style=&quot;width:604px;height:171px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a323e62fcc7.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470110319,1470309357,3,0),(18,67,'Replacement Troffer Kit','/upload/2016/08/02/57a01a93194ff.png','&lt;ul&gt;\r\n	&lt;li&gt;\r\n		1.Rugged steel sheet, slim openable integrated structure of 55mm height.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.Prismatic cover with 3 light bars, anti-glare design.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.High reflective NT(Nano Technology).\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		4.High quality built-in driver.\r\n	&lt;/li&gt;\r\n&lt;/ul&gt;','&lt;div id=&quot;pb-left-column&quot; style=&quot;margin:0px;padding:0px;color:#000000;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;div style=&quot;margin:0px;padding:0px;&quot;&gt;\r\n		&lt;p&gt;\r\n			&lt;br /&gt;\r\n		&lt;/p&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;760&quot; height=&quot;181&quot; style=&quot;width:601px;height:167px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/02/57a01aae92569.png&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;904&quot; height=&quot;199&quot; style=&quot;width:600px;height:128px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a32401349e4.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470110386,1470309383,3,0),(19,64,'With 2 lighting bars','/upload/2016/08/04/57a324f1c769f.jpg','&lt;ul style=&quot;color:#000000;text-indent:0px;background-color:#FFFFFF;&quot;&gt;\r\n	&lt;li&gt;\r\n		1.Rugged steel sheet, slim openable integrated structure of 55mm height.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		2.Prismatic cover with 2 light bars , anti-glare design.\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		3.High reflective NT(Nano Technology).\r\n	&lt;/li&gt;\r\n	&lt;li&gt;\r\n		4.High quality built-in driver.\r\n	&lt;/li&gt;\r\n&lt;/ul&gt;','&lt;p&gt;\r\n	&lt;img width=&quot;759&quot; height=&quot;181&quot; style=&quot;width:598px;height:156px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a324fc9c450.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;904&quot; height=&quot;199&quot; style=&quot;width:597px;height:103px;&quot; alt=&quot;&quot; src=&quot;/upload/2016/08/04/57a32511bc6ae.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470309683,0,3,0);

/*Table structure for table `sr_service` */

DROP TABLE IF EXISTS `sr_service`;

CREATE TABLE `sr_service` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL DEFAULT '0',
  `listorder` mediumint(4) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='首页服务窗口';

/*Data for the table `sr_service` */

insert  into `sr_service`(`id`,`title`,`thumb`,`url`,`create_time`,`update_time`,`listorder`,`status`,`cn`) values (7,'skype','/upload/2016/08/02/57a016d501bdb.png','skype:michelle@source-real.com?chat',1470109410,1470141808,0,1,0),(8,'微信','/upload/2016/08/02/57a016fc0b2a7.png','#',1470109438,0,0,1,0),(9,'客服','/upload/2016/08/02/57a01735d2974.png','#',1470109495,0,0,1,0);

/*Table structure for table `sr_website` */

DROP TABLE IF EXISTS `sr_website`;

CREATE TABLE `sr_website` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `webname` varchar(100) DEFAULT NULL,
  `copyright` varchar(150) DEFAULT NULL,
  `available` int(1) NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='网站信息表';

/*Data for the table `sr_website` */

insert  into `sr_website`(`id`,`webname`,`copyright`,`available`,`reason`,`cn`) values (1,'Xiamen Source Real Industrial Co., Ltd.','Copyright © 2015-2016 source-real All right reserved',1,'网站目前建设中......................',0),(2,'这里是中文网站名','Copyright © 2015-2016 source-real All right reserved',1,'在此填写关闭说明',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
