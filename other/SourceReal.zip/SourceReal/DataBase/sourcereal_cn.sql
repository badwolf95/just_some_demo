/*
SQLyog Ultimate v11.27 (64 bit)
MySQL - 5.6.17 : Database - sourcereal_cn
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sourcereal_cn` /*!40100 DEFAULT CHARACTER SET utf8 */;

/*Table structure for table `sr_admin` */

DROP TABLE IF EXISTS `sr_admin`;

CREATE TABLE `sr_admin` (
  `admin_id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `type` int(1) DEFAULT '1' COMMENT '权限管理',
  `status` int(1) NOT NULL,
  `create_time` int(10) NOT NULL,
  `lastlogin_time` int(10) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员表';

/*Data for the table `sr_admin` */

insert  into `sr_admin`(`admin_id`,`username`,`password`,`email`,`type`,`status`,`create_time`,`lastlogin_time`) values (1,'admin','a1c129bcbe722458e2ffd2855abd6173','',1,1,1470278881,0);

/*Table structure for table `sr_banner` */

DROP TABLE IF EXISTS `sr_banner`;

CREATE TABLE `sr_banner` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `thumb` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `create_time` int(10) NOT NULL,
  `listorder` mediumint(4) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `type` int(1) DEFAULT '1',
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='首页大轮播图';

/*Data for the table `sr_banner` */

insert  into `sr_banner`(`id`,`thumb`,`url`,`create_time`,`listorder`,`status`,`type`,`cn`) values (1,'/cn/upload/2016/08/04/57a2c03e4bd4e.jpg','http://',1470283839,0,1,1,0),(2,'/cn/upload/2016/08/04/57a2c04b0cd74.png','http://',1470283852,0,1,1,0),(3,'/cn/upload/2016/08/04/57a2c0641235d.png','http://',1470283877,0,1,1,0),(4,'/cn/upload/2016/08/04/57a2c06fd3080.jpg','http://',1470283889,0,1,1,0),(5,'/cn/upload/2016/08/04/57a2c081cfe9e.png','',1470283906,0,1,2,0),(6,'/cn/upload/2016/08/04/57a2c089094ae.png','',1470283913,0,1,2,0),(7,'/cn/upload/2016/08/04/57a2c0903db6a.png','',1470283921,0,1,2,0),(8,'/cn/upload/2016/08/04/57a2c0975117f.png','',1470283928,0,1,2,0),(9,'/cn/upload/2016/08/04/57a2c09f29aa8.png','',1470283936,0,1,2,0),(10,'/cn/upload/2016/08/04/57a2c0acf297e.jpg','',1470283949,0,1,2,0);

/*Table structure for table `sr_contact_sm` */

DROP TABLE IF EXISTS `sr_contact_sm`;

CREATE TABLE `sr_contact_sm` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `update_time` int(10) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='首页联系我们简介';

/*Data for the table `sr_contact_sm` */

insert  into `sr_contact_sm`(`id`,`content`,`update_time`,`cn`) values (1,'&lt;p&gt;\r\n	&lt;span style=&quot;font-size:16px;&quot;&gt;厦门市源实实业有限公司&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;电话：1526 0183 378 0086&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;电子邮件：&lt;/span&gt;&lt;a href=&quot;http://michelle@source-real.com/&quot; target=&quot;_blank&quot;&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;michelle@source-real.com&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;Skype：&lt;/span&gt;&lt;a href=&quot;http://michelle@source-real.com/&quot; target=&quot;_blank&quot;&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;michelle@source-real.com&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;网站：&lt;/span&gt;&lt;a href=&quot;http://www.source-real.com/&quot; target=&quot;_blank&quot;&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;www.source-real.com&lt;/span&gt;&lt;/a&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;&lt;a href=&quot;http://http/sourcereal.com/public/home/content/contact-us.html&quot; target=&quot;_blank&quot;&gt;[全球办公信息]&lt;/a&gt;&lt;/span&gt;\r\n&lt;/p&gt;',1470314393,0);

/*Table structure for table `sr_facility` */

DROP TABLE IF EXISTS `sr_facility`;

CREATE TABLE `sr_facility` (
  `facility_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(6) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `resume` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  `listorder` mediumint(4) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) DEFAULT '0',
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`facility_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='性能测试图片表';

/*Data for the table `sr_facility` */

insert  into `sr_facility`(`facility_id`,`parent_id`,`thumb`,`resume`,`status`,`listorder`,`create_time`,`update_time`,`cn`) values (1,9,'/cn/upload/2016/08/04/57a2e030246cf.png','积分球',1,1,1470292017,1470312496,0),(2,9,'/cn/upload/2016/08/04/57a2e039609d0.png','热冲击试验箱',1,7,1470292031,1470312958,0),(3,9,'/cn/upload/2016/08/04/57a2e05e33f2e.png','泄漏电流/压力测试仪',1,5,1470292063,1470312969,0),(4,9,'/cn/upload/2016/08/04/57a2e073b26e6.png','彩色光谱',1,3,1470292084,1470312979,0),(5,9,'/cn/upload/2016/08/04/57a2e07f7201d.png','温升测试仪',1,4,1470292096,1470312993,0),(6,9,'/cn/upload/2016/08/04/57a330f029ff3.png','配光室',1,2,1470312695,0,0),(7,9,'/cn/upload/2016/08/04/57a331e7eddeb.png','盐雾试验机',1,6,1470312937,0,0),(8,10,'/cn/upload/2016/08/04/57a3323a817a9.jpg','外观检查',1,8,1470313019,0,0),(9,10,'/cn/upload/2016/08/04/57a3326199bc7.jpg','老化线',1,9,1470313058,0,0);

/*Table structure for table `sr_log` */

DROP TABLE IF EXISTS `sr_log`;

CREATE TABLE `sr_log` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `action` varchar(40) NOT NULL,
  `ip` varchar(128) NOT NULL,
  `ac_time` int(10) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='后台操作日志';

/*Data for the table `sr_log` */

/*Table structure for table `sr_navbar` */

DROP TABLE IF EXISTS `sr_navbar`;

CREATE TABLE `sr_navbar` (
  `nav_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `navname` varchar(30) NOT NULL,
  `parent_id` mediumint(6) NOT NULL,
  `listorder` mediumint(4) NOT NULL,
  `status` int(1) NOT NULL,
  `type` int(1) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`nav_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='导航栏';

/*Data for the table `sr_navbar` */

insert  into `sr_navbar`(`nav_id`,`navname`,`parent_id`,`listorder`,`status`,`type`,`cn`) values (1,' 首      页 ',0,0,1,1,0),(2,'性 能 ',0,3,1,1,0),(3,' 产 品',0,2,1,1,0),(4,'关 于 我 们',0,1,1,2,0),(5,'棱柱盖槽',3,0,1,1,0),(6,'蛋白石盖槽',3,0,1,1,0),(7,'联 系 我 们',0,5,1,2,0),(8,'产 品 策 略',0,4,1,2,0),(9,'测试设施',2,0,1,1,0),(10,'装配车间',2,0,1,1,0),(11,'槽与中心',3,0,1,1,0),(12,'替代槽盒',3,0,1,1,0);

/*Table structure for table `sr_paper` */

DROP TABLE IF EXISTS `sr_paper`;

CREATE TABLE `sr_paper` (
  `paper_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `nav_id` mediumint(6) NOT NULL,
  `content` text,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  `type` int(1) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`paper_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='单页导航';

/*Data for the table `sr_paper` */

insert  into `sr_paper`(`paper_id`,`nav_id`,`content`,`create_time`,`update_time`,`type`,`cn`) values (1,4,'&lt;p align=&quot;center&quot;&gt;\r\n	&lt;span&gt;&lt;img width=&quot;657&quot; height=&quot;445&quot; style=&quot;width:620px;height:429px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a2bdd4b7700.jpg&quot; /&gt;&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;厦门源实实业有限公司是一家专业照明灯具厂，位于厦门省中国市。我们开始了我们的特定照明装置，为客户提供量身定制的项目，他们的项目。具有丰富的经验和知识，美国市场，我们现在关注的是我们非常有信心，最具成本效益的解决方案troffers。我们总是在设计上花费大量的时间，在简单的安装创新，并试图节省成本和时间，为客户，并帮助客户赢得更大的市场份额。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt; 我们的公司在我们的研发团队有很强的优势，他们的能力，根据客户的项目要求提供特定的照明解决方案。为troffers金属基地，我们有自己的加工设备，从物质收入的表面涂装，确保尺寸精确匹配，并用最好的质量。LED芯片和驱动我们也申请了专利，UL认证，以确保安全使用寿命长。&lt;/span&gt;&lt;/span&gt; \r\n&lt;/p&gt;',1470279074,1470313688,2,0),(2,7,'&lt;p&gt;\r\n	&lt;img alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a2bfa39cd75.jpg&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span&gt;&lt;br /&gt;\r\n&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;厦门市源实实业有限公司&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;地址：F8 G单元03楼B厦门国际航运中心，&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;厦门省中国市361000号湘渝路97号&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;电话：1526 0183 378 0086&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;电子邮件：&lt;/span&gt;&lt;a href=&quot;mailto:michelle@source-real.com&quot;&gt;&lt;span style=&quot;font-size:16px;&quot;&gt;michelle@source-real.com&lt;/span&gt;&lt;/a&gt;&lt;/span&gt;\r\n&lt;/p&gt;',1470279322,1470311345,2,0),(3,8,'&lt;p align=&quot;center&quot;&gt;\r\n	&lt;img width=&quot;628&quot; height=&quot;473&quot; style=&quot;width:609px;height:465px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a2bfbec07a8.jpg&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span style=&quot;font-size:16px;&quot;&gt;&amp;nbsp;&amp;nbsp; 作为一家专业的LED照明灯具公司，我们拥有一个专业的研发设计团队。不断的产品创新和集成的生产程序为用户提供安全、稳定和前瞻性的照明产品。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;光的存在：给人类生存的勇气。自然光的引入是对未来人类生活质量的一种卓越的提升。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;我们与高级专业照明设计师，提供全面的照明解决方案，如星级酒店照明，俱乐部照明，家居照明，办公照明，公共照明，智能照明系统。“光”离人类的生活越来越近。节能、环保、安全和您对“光的使用”的满意度是我们的目标！&lt;/span&gt;\r\n&lt;/p&gt;',1470279345,1470311275,2,0);

/*Table structure for table `sr_product` */

DROP TABLE IF EXISTS `sr_product`;

CREATE TABLE `sr_product` (
  `product_id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(6) NOT NULL,
  `title` varchar(50) NOT NULL COMMENT '产品文章标题',
  `thumb` varchar(100) NOT NULL,
  `feature` text,
  `content` text,
  `status` int(1) NOT NULL,
  `listorder` mediumint(4) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  `type` int(1) NOT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='产品文章表';

/*Data for the table `sr_product` */

insert  into `sr_product`(`product_id`,`parent_id`,`title`,`thumb`,`feature`,`content`,`status`,`listorder`,`create_time`,`update_time`,`type`,`cn`) values (3,5,'有2个照明棒','/cn/upload/2016/08/04/57a32c34b8344.jpg','&lt;span style=&quot;font-size:16px;&quot;&gt;1。坚固的钢片，苗条的可集成结构高度55mm。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;2、带有2个光杆的棱柱盖，防眩光设计。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;3、高反射性的新台币（纳米技术）。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;4、高质量的内置驱动。&lt;/span&gt;','&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;760&quot; height=&quot;181&quot; style=&quot;width:589px;height:166px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32c700caa4.png&quot; /&gt;&lt;img width=&quot;904&quot; height=&quot;197&quot; style=&quot;width:589px;height:178px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32c7dd91f1.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;',1,0,1470311562,0,3,0),(4,5,'有3个照明棒 ','/cn/upload/2016/08/04/57a32db173e99.jpg','&lt;span style=&quot;font-size:16px;&quot;&gt;1。坚固的钢片，苗条的可集成结构高度55mm。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;2、带有2个光杆的棱柱盖，防眩光设计。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;3、高反射性的新台币（纳米技术）。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;4、高质量的内置驱动。&lt;/span&gt;','&lt;p&gt;\r\n	&lt;img width=&quot;757&quot; height=&quot;180&quot; style=&quot;width:588px;height:159px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32dc7c0906.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;904&quot; height=&quot;199&quot; style=&quot;width:589px;height:172px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32dd5670cf.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470311898,0,3,0),(5,6,'蛋白石盖槽','/cn/upload/2016/08/04/57a32e418619b.png','&lt;span style=&quot;font-size:16px;&quot;&gt;1。坚固的钢片，苗条的可集成结构高度55mm。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;2、带有2个光杆的棱柱盖，防眩光设计。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;3、高反射性的新台币（纳米技术）。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;4、高质量的内置驱动。&lt;/span&gt;','&lt;p&gt;\r\n	&lt;img width=&quot;762&quot; height=&quot;181&quot; style=&quot;width:607px;height:135px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32e4d6fc7c.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;905&quot; height=&quot;195&quot; style=&quot;width:609px;height:181px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32e5b14792.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470312031,0,3,0),(6,11,'弧形天空','/cn/upload/2016/08/04/57a32e9aa4eb1.jpg','&lt;span style=&quot;font-size:16px;&quot;&gt;1。坚固的钢片，苗条的可集成结构高度55mm。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;2、带有2个光杆的棱柱盖，防眩光设计。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;3、高反射性的新台币（纳米技术）。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;4、高质量的内置驱动。&lt;/span&gt;','&lt;p&gt;\r\n	&lt;img width=&quot;760&quot; height=&quot;182&quot; style=&quot;width:604px;height:149px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32eaa53345.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;904&quot; height=&quot;199&quot; style=&quot;width:599px;height:184px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32eb60c4c8.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470312126,0,3,0),(7,11,'双弧','/cn/upload/2016/08/04/57a32eef3d5a5.jpg','&lt;span style=&quot;font-size:16px;&quot;&gt;1。坚固的钢片，苗条的可集成结构高度55mm。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;2、带有2个光杆的棱柱盖，防眩光设计。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;3、高反射性的新台币（纳米技术）。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;4、高质量的内置驱动。&lt;/span&gt;','&lt;p&gt;\r\n	&lt;img width=&quot;759&quot; height=&quot;181&quot; style=&quot;width:610px;height:157px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32efc148a6.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;904&quot; height=&quot;199&quot; style=&quot;width:612px;height:189px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32f07c7ac8.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470312204,0,3,0),(8,12,'替代槽盒','/cn/upload/2016/08/04/57a32f3108148.png','&lt;span style=&quot;font-size:16px;&quot;&gt;1。坚固的钢片，苗条的可集成结构高度55mm。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;2、带有2个光杆的棱柱盖，防眩光设计。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;3、高反射性的新台币（纳米技术）。&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-size:16px;&quot;&gt;4、高质量的内置驱动。&lt;/span&gt;','&lt;p&gt;\r\n	&lt;img width=&quot;759&quot; height=&quot;181&quot; style=&quot;width:595px;height:164px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32f405cf8c.png&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img width=&quot;903&quot; height=&quot;199&quot; style=&quot;width:597px;height:176px;&quot; alt=&quot;&quot; src=&quot;/cn/upload/2016/08/04/57a32f4d0e194.png&quot; /&gt;\r\n&lt;/p&gt;',1,0,1470312274,0,3,0);

/*Table structure for table `sr_service` */

DROP TABLE IF EXISTS `sr_service`;

CREATE TABLE `sr_service` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL DEFAULT '0',
  `listorder` mediumint(4) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='首页服务窗口';

/*Data for the table `sr_service` */

insert  into `sr_service`(`id`,`title`,`thumb`,`url`,`create_time`,`update_time`,`listorder`,`status`,`cn`) values (1,'123','/cn/upload/2016/08/04/57a2c00589090.png','123',1470283782,0,0,1,0),(2,'12312','/cn/upload/2016/08/04/57a2c019f21f2.png','123123',1470283803,0,0,1,0),(3,'321321','/cn/upload/2016/08/04/57a2c0271707a.png','1233',1470283816,0,0,1,0);

/*Table structure for table `sr_website` */

DROP TABLE IF EXISTS `sr_website`;

CREATE TABLE `sr_website` (
  `id` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `webname` varchar(100) DEFAULT NULL,
  `copyright` varchar(150) DEFAULT NULL,
  `available` int(1) NOT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `cn` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='网站信息表';

/*Data for the table `sr_website` */

insert  into `sr_website`(`id`,`webname`,`copyright`,`available`,`reason`,`cn`) values (1,'厦门市源实实业有限公司','Copyright © 2015-2016 source-real All right reserved',1,'暂时关闭咯',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
