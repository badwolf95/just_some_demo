<?php
namespace Home\Controller;
use Think\Controller;

class NavbarController extends Controller {

	public function gotoUrl(){

		//加载头部信息
		//分级导航栏和单页
    	$navs = D('Navbar');
		$navs = $navs->readNavbar(array('in','1'),array('in','1,2'));
		$this->assign('navs_fir',$navs[0]);
		$this->assign('navs_sec',$navs[1]);
		$this->assign('navs_3th',$navs[2]);
		//网站配置信息
		$website = D('website');
		$where['id'] = array('gt','0');
		$res = $website->readData($where);
		$this->assign("website",$res[0]);
		//产品文章
		$product = D('Product');
		$where['product_id'] = array('gt','0');
		$where['status'] = '1';
		$order = array('parent_id'=>'asc','listorder'=>'asc','product_id'=>'asc');
		$products = $product->readData($where,$order);
		$this->assign('products',$products);
		//左侧联系我们
		$contact = M('contact_sm');
		$content = $contact->select();
		$content[0]['content'] = htmlspecialchars_decode($content[0]['content']);
		$this->assign('contact',$content[0]);
		//服务板块
		$serviceObj = M('service');
		$order = array('listorder'=>'asc','id'=>'asc');
		$service = $serviceObj->order($order)->select();
		$this->assign('services',$service);



		//这里才是主要内容
		$type = I('get.type');
		$id = I('get.id');
		if(1 == $type){

			if(1 == $id){
				$this->redirect("Index/index");
			}elseif(3 == $id){
				$productObj = M('product');
				$where['status'] = 1;
				$order = array('listorder'=>'asc');
				$products = $productObj->where($where)->order($order)->select();
				$this->assign('products',$products);
				$this->display("Product/index");
			}elseif(2 == $id){
				$facility = M('facility');
				$where['status'] = 1;
				$order = array('listorder'=>'asc');
				$facilities = $facility->where($where)->order($order)->select();
				$this->assign('facilities',$facilities);
				$this->display("Facility/index");
			}else{
				$productObj = M('product');
				$where['status'] = 1;
				$where['parent_id'] = $id;
				$order = array('listorder'=>'asc');
				$products = $productObj->where($where)->order($order)->select();
				if($products){
					$navbarObj = M('navbar');
					$navbar = $navbarObj->find($id);
					$this->assign('navbar_part',$navbar);
					$this->assign('products_part',$products);
					$this->display("Product/second");
				}else{
					foreach($navs[1][2] as $navs_sec_name){
						if($navs_sec_name['nav_id'] == $id){
							$this->assign('facility_parent_navname',$navs_sec_name['navname']);
						}
					}
					$facility = M('facility');
					$where['status'] = 1;
					$where['parent_id'] = $id;
					$order = array('listorder'=>'asc');
					$facilities = $facility->where($where)->order($order)->select();
					if($facilities){
						$this->assign('facilities_part',$facilities);
						$this->display("Facility/second");
					}else{
						$this->display("Other/404");
					}
				}
			}
		}elseif(2 == $type){

			$paperObj = M('paper');
			$where['nav_id'] = $id;
			$paper = $paperObj->where($where)->find();
			$paper['content'] = htmlspecialchars_decode($paper['content']);
			if($paper){
				$this->assign('paper',$paper);
				$this->display('Paper/index');
			}else{
				$this->display("Other/404");
			}
		}else{

			$productObj = M('product');
			$where['product_id'] = $id;
			$where['status'] = 1;
			$product = $productObj->where($where)->find();
			$product['feature'] = htmlspecialchars_decode($product['feature']);
			$product['content'] = htmlspecialchars_decode($product['content']);
			$navbarObj = M('navbar');
			$navbar = $navbarObj->find($product['parent_id']);
			if($product && $navbar){
				$this->assign('navbar_part_detail',$navbar);
				$this->assign('product_one',$product);
				$this->display('Product/detail');
			}else{
				$this->display('Other/404');
			}
		}
	}
}