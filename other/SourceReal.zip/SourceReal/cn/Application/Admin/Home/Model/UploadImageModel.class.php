<?php
namespace Home\Model;
use Think\Model;

class UploadImageModel extends Model {

	private $_upload = '';
	const UPLOAD = "upload";

	public function __construct(){

		$this->_upload = new \Think\Upload();
		$this->_upload->rootPath = './'.self::UPLOAD.'/';
		$this->_upload->subName = date(Y).'/'.date(m).'/'.date(d);
	}

	public function upload($type="image"){

		$res = $this->_upload->upload();
		// dump($this->_upload->getError());
		if($res){	
			if("file" == $type){
				$src = '/cn/'.self::UPLOAD.'/'.$res['file']['savepath'].$res['file']['savename'];
			}else{
				$src = '/cn/'.self::UPLOAD.'/'.$res['imgFile']['savepath'].$res['imgFile']['savename'];
			}
			return $src;
		}else{
			return $this->_upload->getError();
		}

	}





}