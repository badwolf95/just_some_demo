<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Bootstrap Core CSS -->
	<link href="/cn/Public/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
	<link href="/cn/Public/css/style.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
	<link href="/cn/Public/css/lines.css" rel='stylesheet' type='text/css' />
	<link href="/cn/Public/css/font-awesome.css" rel="stylesheet">
	<!-- jQuery -->
	<script src="/cn/Public/js/jquery.min.js"></script>
	<!----webfonts--->
	<link href='http://fonts.useso.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
	<!---//webfonts--->
	<!-- Nav CSS -->
	<link href="/cn/Public/css/custom.css" rel="stylesheet">
	<!-- Metis Menu Plugin JavaScript -->
	<script src="/cn/Public/js/metisMenu.min.js"></script>
	<script src="/cn/Public/js/custom.js"></script>
	<!-- Graph JavaScript -->
	<script src="/cn/Public/js/d3.v3.js"></script>
	<!-- <script src="/cn/Public/js/rickshaw.js"></script>
-->
<!----Calender -------->
<link rel="stylesheet" href="/cn/Public/css/clndr.css" type="text/css" />
<script src="/cn/Public/js/underscore-min.js" type="text/javascript"></script>
<script src= "/cn/Public/js/moment-2.2.1.js" type="text/javascript"></script>
<script src="/cn/Public/js/clndr.js" type="text/javascript"></script>
<script src="/cn/Public/js/site.js" type="text/javascript"></script>
<!----End Calender -------->

<!-- layer   -->
<script src="/cn/Public/js/layer/layer.js" type="text/javascript"></script>


</head>

<body>
	<div id="wrapper">
		<!-- Navigation -->
		<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.html">SourceReal</a>
			</div>

			<ul class="nav navbar-nav navbar-right">

				<li class="dropdown">
					<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown">
						<i class="fa fa-comments"></i></a>
					<ul class="dropdown-menu">

						<li class="dropdown-menu-header text-center"> <strong>选择语言</strong>
						</li>
						<li class="m_2">
							<a href="/admin.php"> <i class="fa fa-comments"></i>
								管理——英文——内容
							</a>
						</li>
						<li class="m_2">
							<a href="/cn/admin.php"> <i class="fa fa-comments"></i>
								管理——中文——内容
							</a>
						</li>

						<li class="divider"></li>
						<li class="m_2">
							<a href="/cn/cn/admin.php?c=login&a=logout">
								<i class="fa fa-lock"></i>
								退出
							</a>
						</li>
					</ul>
					<li class="m_2"><a href="#" style="color:white;">中文</a></li>
				</li>
			</ul>
			<form class="navbar-form navbar-right">
				<input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}"></form>

			<!-- 	左侧导航栏    -->
			<div class="navbar-default sidebar" role="navigation">
				<div class="sidebar-nav navbar-collapse">
					<ul class="nav" id="side-menu">
						<li>
							<a href="/cn/index.php" target="_blank">
								<i class="fa fa-dashboard fa-fw nav_icon"></i>
								前台首页
							</a>
						</li>
						<li>
							<a href="/cn/admin.php">
								<i class="fa fa-check-square-o nav_icon"></i>
								后台首页
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa fa-laptop nav_icon"></i>
								网站系统管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/cn/admin.php?c=admin">管理员管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=website">网站信息配置</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>
						<li>
							<a href="#">
								<i class="fa fa-indent nav_icon"></i>
								栏目内容管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/cn/admin.php?c=navbar">导航栏管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=paper">一级单页管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=product">产品介绍管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=facility">测试性能图片</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=banner">首页轮播大图</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=album">首页轮播小图</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=service">服务链接管理</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>

					</ul>
				</div>
				<!-- /.sidebar-collapse -->
			</div>
			<!-- /.navbar-static-side -->
		</nav>

		<div id="page-wrapper">
			<div class="graphs">
				<br/>

<!-- 要记得引入各种插件 -->
<script src="/cn/Public/js/kindeditor/kindeditor-all.js"></script>
<script src="/cn/Public/js/party/jquery.uploadify.js"></script>
<link rel="stylesheet" href="/cn/Public/css/party/uploadify.css">



<script type="text/javascript">
var SCOPE = {
	'save_url' 	: 	'/cn/admin.php?c=banner&a=add',
	'cancle_url'	: 	'/cn/admin.php?c=banner',
	'ajax_upload_swf'	:	'/cn/Public/js/party/uploadify.swf',
	'ajax_upload_image_url'	:	'/cn/admin.php?c=image&a=fileUpload',
	'jump_url'	: 	'/cn/admin.php?c=banner',
};
</script>
<div class="xs">
	<h3>新增首页轮播大图</h3>

	<div class="tab-content">
		<div class="tab-pane active" id="horizontal-form">
			<form class="form-horizontal" id="form_submit">

			
			
			<div class="form-group">
				<label class="col-md-2 control-label">链接地址（url）</label>
				<div class="col-md-8">
					<div class="input-group">
						<span class="input-group-addon"> <i class="fa">&&</i>
						</span>
						<input type="text" class="form-control1" id="exampleInputPassword1" placeholder="请输入链接地址（url），请以 http:// 开头，否则无法跳转跳转" name="url" value="http://"></div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-md-2 control-label" for="exampleInputFile">轮播展示图片</label>

				<div class="col-md-8">
					<div class="input-group">
						<input id="file_upload"  type="file" multiple="true" >

						<img style="display: none" id="upload_org_code_img" src="" width="680" height="250">
						<input id="file_upload_image" name="thumb" type="hidden" multiple="true" value="">
						<p class="help-block">Example block-level help text here.</p>

					</div>
				</div>
			</div>

			<div class="form-group">
				<label for="radio" class="col-sm-2 control-label">状态</label>
				<div class="col-sm-8">

					<div class="radio-inline">
						<label>
							<input type="radio" name="status" value="1" checked="">显示</label>
					</div>
					<div class="radio-inline">
						<label>
							<input type="radio"  name="status" value="0">隐藏</label>
					</div>

					<p class="help-block">Your help text!</p>
				</div>
			</div>
			<!-- <div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">内容:</label>
				<div class="col-sm-5">
					<p class="help-block">拖动右下角可改变编辑框大小</p>
					<textarea class="input js-editor" id="editor_sourcereal" name="content" rows="20" ></textarea>
				</div>
			</div> -->
			<div class="panel-footer">
				<div class="row">
					<div class="col-sm-8 col-sm-offset-2">
						<button type="button"class="btn-success btn" id="my_save_button">提交</button>
						<button type="button"class="btn-default btn" id="cancle_button">取消</button>
						<button type="reset"class="btn-inverse btn">重置</button>
					</div>
				</div>
			</div>
		</form>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br></div>
</div>
</div>
 <script>
//   // 6.2
//   KindEditor.ready(function(K) {
//     window.editor = K.create('#editor_sourcereal',{
//       uploadJson : '/cn/admin.php?c=image&a=kindupload',
//       afterBlur : function(){this.sync();}, //
//     });
//   });
</script>

       	     </div>
	     </div>
	     <!-- /#page-wrapper -->	     
	     <!-- /#wrapper -->	     
	     <script type="text/javascript" src="/cn/Public/js/admin/common.js"></script>

	     <!-- Bootstrap Core JavaScript -->	     
	     <script src="/cn/Public/js/bootstrap.min.js"></script>
	     </body>
	     </html>