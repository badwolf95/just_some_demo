<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Bootstrap Core CSS -->
	<link href="/Public/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
	<link href="/Public/css/style.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
	<link href="/Public/css/lines.css" rel='stylesheet' type='text/css' />
	<link href="/Public/css/font-awesome.css" rel="stylesheet">
	<!-- jQuery -->
	<script src="/Public/js/jquery.min.js"></script>
	<!----webfonts--->
	<link href='http://fonts.useso.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
	<!---//webfonts--->
	<!-- Nav CSS -->
	<link href="/Public/css/custom.css" rel="stylesheet">
	<!-- Metis Menu Plugin JavaScript -->
	<script src="/Public/js/metisMenu.min.js"></script>
	<script src="/Public/js/custom.js"></script>
	<!-- Graph JavaScript -->
	<script src="/Public/js/d3.v3.js"></script>
	<!-- <script src="/Public/js/rickshaw.js"></script>
-->
<!----Calender -------->
<link rel="stylesheet" href="/Public/css/clndr.css" type="text/css" />
<script src="/Public/js/underscore-min.js" type="text/javascript"></script>
<script src= "/Public/js/moment-2.2.1.js" type="text/javascript"></script>
<script src="/Public/js/clndr.js" type="text/javascript"></script>
<script src="/Public/js/site.js" type="text/javascript"></script>
<!----End Calender -------->

<!-- layer   -->
<script src="/Public/js/layer/layer.js" type="text/javascript"></script>


</head>

<body>
	<div id="wrapper">
		<!-- Navigation -->
		<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.html">SourceReal</a>
			</div>

			<ul class="nav navbar-nav navbar-right">

				<li class="dropdown">
					<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown">
						<img src="/Public/images/1.png"></a>
					<ul class="dropdown-menu">

						<li class="dropdown-menu-header text-center"> <strong>选择语言</strong>
						</li>
						<li class="m_2">
							<a href="#"> <i class="fa fa-comments"></i>
								英 语
							</a>
						</li>
						<li class="m_2">
							<a href="#"> <i class="fa fa-comments"></i>
								中 文
							</a>
						</li>

						<li class="dropdown-menu-header text-center"> <strong>切换身份</strong>
						</li>
						<li class="m_2">
							<a href="#">
								<i class="fa fa-user"></i>
								超级管理员
							</a>
						</li>
						<li class="m_2">
							<a href="#">
								<i class="fa fa-tasks"></i>
								普通管理员
							</a>
						</li>
						<li class="divider"></li>
						<li class="m_2">
							<a href="/admin.php?c=login&a=logout">
								<i class="fa fa-lock"></i>
								退出
							</a>
						</li>
					</ul>
				</li>
			</ul>
			<form class="navbar-form navbar-right">
				<input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}"></form>

			<!-- 	左侧导航栏    -->
			<div class="navbar-default sidebar" role="navigation">
				<div class="sidebar-nav navbar-collapse">
					<ul class="nav" id="side-menu">
						<li>
							<a href="/index.php">
								<i class="fa fa-dashboard fa-fw nav_icon"></i>
								前台首页
							</a>
						</li>
						<li>
							<a href="/admin.php">
								<i class="fa fa-check-square-o nav_icon"></i>
								后台首页
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa fa-laptop nav_icon"></i>
								网站系统管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/admin.php?c=admin">管理员管理</a>
								</li>
								<li>
									<a href="/admin.php?c=website">网站信息配置</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>
						<li>
							<a href="#">
								<i class="fa fa-indent nav_icon"></i>
								栏目内容管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/admin.php?c=navbar">导航栏管理</a>
								</li>
								<li>
									<a href="/admin.php?c=paper">一级单页管理</a>
								</li>
								<li>
									<a href="/admin.php?c=product">产品介绍管理</a>
								</li>
								<li>
									<a href="/admin.php?c=facility">测试性能图片</a>
								</li>
								<li>
									<a href="/admin.php?c=service">服务链接管理</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>

					</ul>
				</div>
				<!-- /.sidebar-collapse -->
			</div>
			<!-- /.navbar-static-side -->
		</nav>

		<div id="page-wrapper">
			<div class="graphs">
				<br/>
<script type="text/javascript">
	var SCOPE = {
		'save_url'	: '/admin.php?c=admin&a=add',
		'jump_url'	: '/admin.php?c=admin',
	};
</script>
<div class="xs">
	<h3>编辑管理员</h3>

	<div class="tab-content">
		<div class="tab-pane active" id="horizontal-form">
			<form class="form-horizontal" id="form_submit">
				<input type="hidden" name="admin_id" value="<?php echo ($admin["admin_id"]); ?>">
				<div class="form-group">
					<label class="col-md-2 control-label">管理员</label>
					<div class="col-md-8">
						<div class="input-group">
							<span class="input-group-addon"> <i class="fa fa-user"></i>
							</span>
							<input type="text" class="form-control1" id="exampleInputPassword1" placeholder="请输入管理员账号" name="username" value="<?php echo ($admin["username"]); ?>"></div>
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-2 control-label">密码</label>
					<div class="col-md-8">
						<div class="input-group">
							<span class="input-group-addon"> <i class="fa fa-key"></i>
							</span>
							<input type="password" class="form-control1" id="exampleInputPassword1" placeholder="请输入管理员密码" name="password" value=""></div>
					</div>
				</div>

				<div class="form-group">
					<label class="col-md-2 control-label">确认密码</label>
					<div class="col-md-8">
						<div class="input-group">
							<span class="input-group-addon">
								<i class="fa fa-key"></i>
							</span>
							<input type="password" class="form-control1" id="exampleInputPassword1" name="re_password" placeholder="请确认管理员密码"></div>
					</div>
				</div>
				<div class="form-group">
					<label class="col-md-2 control-label">通信邮箱</label>
					<div class="col-md-8">
						<div class="input-group">
							<span class="input-group-addon">
								<i class="fa fa-envelope-o"></i>
							</span>
							<input type="email" class="form-control1" id="exampleInputPassword1" placeholder="请确认管理员通信邮箱" name="email" value="<?php echo ($admin["email"]); ?>"></div>
					</div>
				</div>
				<!-- <div class="form-group">
					<label for="radio" class="col-sm-2 control-label">管理权限</label>
					<div class="col-sm-8">
				
						<div class="radio-inline">
							<label>
								<input type="radio" checked="">超级管理员</label>
						</div>
						<div class="radio-inline">
							<label>
								<input type="radio" checked="">普通管理员</label>
						</div>
				
						<p class="help-block">Your help text!</p>
					</div>
				</div> -->
				<div class="form-group">
					<label for="radio" class="col-sm-2 control-label">状态</label>
					<div class="col-sm-8">

						<div class="radio-inline">
							<label>
								<input type="radio" name="status" value="1" <?php if($admin["status"] == 1): ?>checked="checked"<?php endif; ?>>可用</label>
						</div>
						<div class="radio-inline">
							<label>
								<input type="radio" <input name="status"value="0" type="radio" <?php if($admin["status"] != 1): ?>checked="checked"<?php endif; ?>>禁用</label>
						</div>

						<p class="help-block">Your help text!</p>
					</div>
				</div>

				<div class="panel-footer">
					<div class="row">
						<div class="col-sm-8 col-sm-offset-2">
							<button class="btn-success btn" type="button" id="my_save_button">提交</button>
							<button class="btn-default btn" type="button" id="cancle_button">取消</button>
							<button class="btn-inverse btn" type="reset">重置</button>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
</div>


       	     </div>
	     </div>
	     <!-- /#page-wrapper -->	     
	     <!-- /#wrapper -->	     
	     <script type="text/javascript" src="/Public/js/admin/common.js"></script>

	     <!-- Bootstrap Core JavaScript -->	     
	     <script src="/Public/js/bootstrap.min.js"></script>
	     </body>
	     </html>