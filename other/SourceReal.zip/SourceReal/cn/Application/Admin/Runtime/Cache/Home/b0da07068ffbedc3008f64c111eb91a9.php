<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE HTML>
<html>
<head>
	<title>中文后台</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Bootstrap Core CSS -->
	<link href="/cn/Public/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
	<link href="/cn/Public/css/style.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
	<link href="/cn/Public/css/lines.css" rel='stylesheet' type='text/css' />
	<link href="/cn/Public/css/font-awesome.css" rel="stylesheet">
	<!-- jQuery -->
	<script src="/cn/Public/js/jquery.min.js"></script>
	<!----webfonts--->
	<link href='http://fonts.useso.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
	<!---//webfonts--->
	<!-- Nav CSS -->
	<link href="/cn/Public/css/custom.css" rel="stylesheet">
	<!-- Metis Menu Plugin JavaScript -->
	<script src="/cn/Public/js/metisMenu.min.js"></script>
	<script src="/cn/Public/js/custom.js"></script>
	<!-- Graph JavaScript -->
	<script src="/cn/Public/js/d3.v3.js"></script>
	<!-- <script src="/cn/Public/js/rickshaw.js"></script>
-->
<!----Calender -------->
<link rel="stylesheet" href="/cn/Public/css/clndr.css" type="text/css" />
<script src="/cn/Public/js/underscore-min.js" type="text/javascript"></script>
<script src= "/cn/Public/js/moment-2.2.1.js" type="text/javascript"></script>
<script src="/cn/Public/js/clndr.js" type="text/javascript"></script>
<script src="/cn/Public/js/site.js" type="text/javascript"></script>
<!----End Calender -------->

<!-- layer   -->
<script src="/cn/Public/js/layer/layer.js" type="text/javascript"></script>


</head>

<body>
	<div id="wrapper">
		<!-- Navigation -->
		<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.html">SourceReal</a>
			</div>

			<ul class="nav navbar-nav navbar-right">

				<li class="dropdown">
					<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"style="color:white;">
						<i class="fa fa-comments"></i>中文</a>
					<ul class="dropdown-menu">

						<li class="dropdown-menu-header text-center"> <strong>选择语言</strong>
						</li>
						<li class="m_2">
							<a href="/admin.php"> <i class="fa fa-comments"></i>
								管理——英文——内容
							</a>
						</li>
						<li class="m_2">
							<a href="/cn/admin.php"> <i class="fa fa-comments"></i>
								管理——中文——内容
							</a>
						</li>

						<li class="divider"></li>
						<li class="m_2">
							<a href="/cn/cn/admin.php?c=login&a=logout">
								<i class="fa fa-lock"></i>
								退出
							</a>
						</li>
					</ul>
				</li>
			</ul>
			<!-- <form class="navbar-form navbar-right">
				<input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}"></form> -->

			<!-- 	左侧导航栏    -->
			<div class="navbar-default sidebar" role="navigation">
				<div class="sidebar-nav navbar-collapse">
					<ul class="nav" id="side-menu">
						<li>
							<a href="/cn/index.php" target="_blank">
								<i class="fa fa-dashboard fa-fw nav_icon"></i>
								前台首页
							</a>
						</li>
						<li>
							<a href="/cn/admin.php">
								<i class="fa fa-check-square-o nav_icon"></i>
								后台首页
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa fa-laptop nav_icon"></i>
								网站系统管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/cn/admin.php?c=admin">管理员管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=website">网站信息配置</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>
						<li>
							<a href="#">
								<i class="fa fa-indent nav_icon"></i>
								栏目内容管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/cn/admin.php?c=navbar">导航栏管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=paper">一级单页管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=product">产品介绍管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=facility">测试性能图片</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=banner">首页轮播大图</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=album">首页轮播小图</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=service">服务链接管理</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>

					</ul>
				</div>
				<!-- /.sidebar-collapse -->
			</div>
			<!-- /.navbar-static-side -->
		</nav>

		<div id="page-wrapper">
			<div class="graphs">
				<br/>

<div class="col_3">
    快捷通道：
    <button type="button" class="btn btn_5 btn-lg btn-default" id="product" >产品介绍管理</button>
    <button type="button" class="btn btn_5 btn-lg btn-primary" id="facility">性能测试图片</button>
    <button type="button" class="btn btn_5 btn-lg btn-info" id="banner">首页轮播大图</button>
    <button type="button" class="btn btn_5 btn-lg btn-warning warning_11" id="album">首页轮播小图</button>
    <button type="button" class="btn btn_5 btn-lg btn-danger" id="logout">退出</button>
</div>
<script type="text/javascript">
$(function(){
    $("#product").click(function(){
        location.href = '/cn/admin.php?c=product';
    });
     $("#facility").click(function(){
        location.href = '/cn/admin.php?c=facility';
    });
      $("#banner").click(function(){
        location.href = '/cn/admin.php?c=banner';
    });
       
       $("#logout").click(function(){
        location.href = '/cn/admin.php?c=login&a=logout';
    });
});
    
</script>
<br/>
<div class="col_1">
    <div class="col-md-7 span_7">
        <div class="cal1 cal_2">
            <div class="clndr">
                <div class="clndr-controls">
                    <div class="clndr-control-button">
                        <p class="clndr-previous-button">previous</p>
                    </div>
                    <div class="month">July 2015</div>
                    <div class="clndr-control-button rightalign">
                        <p class="clndr-next-button">next</p>
                    </div>
                </div>
                <table class="clndr-table" border="0" cellspacing="0" cellpadding="0">
                    <thead>
                        <tr class="header-days">
                            <td class="header-day">S</td>
                            <td class="header-day">M</td>
                            <td class="header-day">T</td>
                            <td class="header-day">W</td>
                            <td class="header-day">T</td>
                            <td class="header-day">F</td>
                            <td class="header-day">S</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="day adjacent-month last-month calendar-day-2015-06-28">
                                <div class="day-contents">28</div>
                            </td>
                            <td class="day adjacent-month last-month calendar-day-2015-06-29">
                                <div class="day-contents">29</div>
                            </td>
                            <td class="day adjacent-month last-month calendar-day-2015-06-30">
                                <div class="day-contents">30</div>
                            </td>
                            <td class="day calendar-day-2015-07-01">
                                <div class="day-contents">1</div>
                            </td>
                            <td class="day calendar-day-2015-07-02">
                                <div class="day-contents">2</div>
                            </td>
                            <td class="day calendar-day-2015-07-03">
                                <div class="day-contents">3</div>
                            </td>
                            <td class="day calendar-day-2015-07-04">
                                <div class="day-contents">4</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="day calendar-day-2015-07-05">
                                <div class="day-contents">5</div>
                            </td>
                            <td class="day calendar-day-2015-07-06">
                                <div class="day-contents">6</div>
                            </td>
                            <td class="day calendar-day-2015-07-07">
                                <div class="day-contents">7</div>
                            </td>
                            <td class="day calendar-day-2015-07-08">
                                <div class="day-contents">8</div>
                            </td>
                            <td class="day calendar-day-2015-07-09">
                                <div class="day-contents">9</div>
                            </td>
                            <td class="day calendar-day-2015-07-10">
                                <div class="day-contents">10</div>
                            </td>
                            <td class="day calendar-day-2015-07-11">
                                <div class="day-contents">11</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="day calendar-day-2015-07-12">
                                <div class="day-contents">12</div>
                            </td>
                            <td class="day calendar-day-2015-07-13">
                                <div class="day-contents">13</div>
                            </td>
                            <td class="day calendar-day-2015-07-14">
                                <div class="day-contents">14</div>
                            </td>
                            <td class="day calendar-day-2015-07-15">
                                <div class="day-contents">15</div>
                            </td>
                            <td class="day calendar-day-2015-07-16">
                                <div class="day-contents">16</div>
                            </td>
                            <td class="day calendar-day-2015-07-17">
                                <div class="day-contents">17</div>
                            </td>
                            <td class="day calendar-day-2015-07-18">
                                <div class="day-contents">18</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="day calendar-day-2015-07-19">
                                <div class="day-contents">19</div>
                            </td>
                            <td class="day calendar-day-2015-07-20">
                                <div class="day-contents">20</div>
                            </td>
                            <td class="day calendar-day-2015-07-21">
                                <div class="day-contents">21</div>
                            </td>
                            <td class="day calendar-day-2015-07-22">
                                <div class="day-contents">22</div>
                            </td>
                            <td class="day calendar-day-2015-07-23">
                                <div class="day-contents">23</div>
                            </td>
                            <td class="day calendar-day-2015-07-24">
                                <div class="day-contents">24</div>
                            </td>
                            <td class="day calendar-day-2015-07-25">
                                <div class="day-contents">25</div>
                            </td>
                        </tr>
                        <tr>
                            <td class="day calendar-day-2015-07-26">
                                <div class="day-contents">26</div>
                            </td>
                            <td class="day calendar-day-2015-07-27">
                                <div class="day-contents">27</div>
                            </td>
                            <td class="day calendar-day-2015-07-28">
                                <div class="day-contents">28</div>
                            </td>
                            <td class="day calendar-day-2015-07-29">
                                <div class="day-contents">29</div>
                            </td>
                            <td class="day calendar-day-2015-07-30">
                                <div class="day-contents">30</div>
                            </td>
                            <td class="day calendar-day-2015-07-31">
                                <div class="day-contents">31</div>
                            </td>
                            <td class="day adjacent-month next-month calendar-day-2015-08-01">
                                <div class="day-contents">1</div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- <div class="col-md-5 span_7">
        <div class="grid_3 grid_5">
            <h3>系统操作日志</h3>
            <div class="but_list">
                <div class="well">
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration
                </div>
                <div class="well">
                    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here
                </div>
                <div class="well">
                    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here
                </div>
                <div class="well">
                    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here
                </div>
                <div class="well">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic
                </div>
            </div>
        </div>
    </div> -->
</div>
<div class="clearfix"></div>

</div>


       	     </div>
	     </div>
	     <!-- /#page-wrapper -->	     
	     <!-- /#wrapper -->	     
	     <script type="text/javascript" src="/cn/Public/js/admin/common.js"></script>

	     <!-- Bootstrap Core JavaScript -->	     
	     <script src="/cn/Public/js/bootstrap.min.js"></script>
	     </body>
	     </html>