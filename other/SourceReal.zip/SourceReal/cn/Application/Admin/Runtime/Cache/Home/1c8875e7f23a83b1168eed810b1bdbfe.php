<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
  <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
  <!-- Bootstrap Core CSS -->
  <link href="/cn/Public/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
  <!-- Custom CSS -->
  <link href="/cn/Public/css/style.css" rel='stylesheet' type='text/css' />
  <link href="/cn/Public/css/font-awesome.css" rel="stylesheet">
  <!-- jQuery -->
  <script src="/cn/Public/js/jquery.min.js"></script>
  <!----webfonts--->
  <link href='http://fonts.useso.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
  <!---//webfonts--->
  <!-- Bootstrap Core JavaScript -->
  <script src="/cn/Public/js/bootstrap.min.js"></script>
  <!-- layer   -->
  <script src="/cn/Public/js/layer/layer.js" type="text/javascript"></script>

</head>
<body id="login">

  <div class="login-logo">
    <a href="/index.php" target="_blank">
      sourcereal
    </a>
  </div>
  <h2 class="form-heading">login</h2>
  <div class="app-cam">
    <form action="" method="post">
      <input type="text" name="username" id="username" class="text" placeholder="账号" >
      <input type="password" name="password" id="password" placeholder="密码" >
      <div class="submit">
        <input type="button" id="admin_login" value="登 录"></div>

    </form>
  </div>
  <div class="copy_layout login">
   
  </div>
  <script>
   $(function(){

    $("#admin_login").click(function(){
      var username = $("#username").val();
      var password = $("#password").val();
      var url      = '/cn/admin.php?c=login&a=index';
      var jump_url = '/cn/admin.php?c=index';
      if(!username){
        layer.msg("用户名不能为空");
      }else if(!password){
        layer.msg("密码不能为空");
      }
      data = {};
      data['username'] = username;
      data['password'] = password;
      $.post(url,data,function(res){
        if(1 == res.status){
          layer.msg(res.message);
          window.location.href = jump_url;
        }else{
          layer.msg(res.message);
        }
      },"JSON");

    });
   });
  //  layer.msg('关闭后想做些什么', function(){
  // //do something
  // }); 
   </script>
</body>
</html>