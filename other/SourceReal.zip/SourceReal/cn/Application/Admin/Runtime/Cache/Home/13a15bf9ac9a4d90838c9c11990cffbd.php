<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>中文后台</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Bootstrap Core CSS -->
	<link href="/cn/Public/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
	<link href="/cn/Public/css/style.css" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
	<link href="/cn/Public/css/lines.css" rel='stylesheet' type='text/css' />
	<link href="/cn/Public/css/font-awesome.css" rel="stylesheet">
	<!-- jQuery -->
	<script src="/cn/Public/js/jquery.min.js"></script>
	<!----webfonts--->
	<link href='http://fonts.useso.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
	<!---//webfonts--->
	<!-- Nav CSS -->
	<link href="/cn/Public/css/custom.css" rel="stylesheet">
	<!-- Metis Menu Plugin JavaScript -->
	<script src="/cn/Public/js/metisMenu.min.js"></script>
	<script src="/cn/Public/js/custom.js"></script>
	<!-- Graph JavaScript -->
	<script src="/cn/Public/js/d3.v3.js"></script>
	<!-- <script src="/cn/Public/js/rickshaw.js"></script>
-->
<!----Calender -------->
<link rel="stylesheet" href="/cn/Public/css/clndr.css" type="text/css" />
<script src="/cn/Public/js/underscore-min.js" type="text/javascript"></script>
<script src= "/cn/Public/js/moment-2.2.1.js" type="text/javascript"></script>
<script src="/cn/Public/js/clndr.js" type="text/javascript"></script>
<script src="/cn/Public/js/site.js" type="text/javascript"></script>
<!----End Calender -------->

<!-- layer   -->
<script src="/cn/Public/js/layer/layer.js" type="text/javascript"></script>


</head>

<body>
	<div id="wrapper">
		<!-- Navigation -->
		<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.html">SourceReal</a>
			</div>

			<ul class="nav navbar-nav navbar-right">

				<li class="dropdown">
					<a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"style="color:white;">
						<i class="fa fa-comments"></i>中文</a>
					<ul class="dropdown-menu">

						<li class="dropdown-menu-header text-center"> <strong>选择语言</strong>
						</li>
						<li class="m_2">
							<a href="/admin.php"> <i class="fa fa-comments"></i>
								管理——英文——内容
							</a>
						</li>
						<li class="m_2">
							<a href="/cn/admin.php"> <i class="fa fa-comments"></i>
								管理——中文——内容
							</a>
						</li>

						<li class="divider"></li>
						<li class="m_2">
							<a href="/cn/cn/admin.php?c=login&a=logout">
								<i class="fa fa-lock"></i>
								退出
							</a>
						</li>
					</ul>
				</li>
			</ul>
			<!-- <form class="navbar-form navbar-right">
				<input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}"></form> -->

			<!-- 	左侧导航栏    -->
			<div class="navbar-default sidebar" role="navigation">
				<div class="sidebar-nav navbar-collapse">
					<ul class="nav" id="side-menu">
						<li>
							<a href="/cn/index.php" target="_blank">
								<i class="fa fa-dashboard fa-fw nav_icon"></i>
								前台首页
							</a>
						</li>
						<li>
							<a href="/cn/admin.php">
								<i class="fa fa-check-square-o nav_icon"></i>
								后台首页
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa fa-laptop nav_icon"></i>
								网站系统管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/cn/admin.php?c=admin">管理员管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=website">网站信息配置</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>
						<li>
							<a href="#">
								<i class="fa fa-indent nav_icon"></i>
								栏目内容管理
								<span class="fa arrow"></span>
							</a>
							<ul class="nav nav-second-level">
								<li>
									<a href="/cn/admin.php?c=navbar">导航栏管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=paper">一级单页管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=product">产品介绍管理</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=facility">测试性能图片</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=banner">首页轮播大图</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=album">首页轮播小图</a>
								</li>
								<li>
									<a href="/cn/admin.php?c=service">服务链接管理</a>
								</li>
							</ul>
							<!-- /.nav-second-level -->
						</li>

					</ul>
				</div>
				<!-- /.sidebar-collapse -->
			</div>
			<!-- /.navbar-static-side -->
		</nav>

		<div id="page-wrapper">
			<div class="graphs">
				<br/>

<script type="text/javascript"> 

var SCOPE = {
	'id' : 'id',
	'table' : 'Banner',
	'add_url' : '/cn/admin.php?c=album&a=add',
	'edit_url' : '/cn/admin.php?c=album&a=edit',
	'delete_url' : "/cn/admin.php?c=album&a=deleteMany",
	'status_url' : '/cn/admin.php?c=album&a=changeStatus',
	'make_url'	: '/cn/admin.php?c=album&a=makePosible',
	'make_im_url': '/cn/admin.php?c=album&a=makeImposible',
	'listorder_url' : '/cn/admin.php?c=album&a=listorder',
	'jump_url' : '/cn/admin.php?c=album',
}


</script>

<p>
	<button type="button" class="btn btn-sm btn-warning warning_33" id="add_button">新增轮播小图</button>
	<span style="margin-left:100px;">批操作：</span>
	<button type="button" class="btn btn-sm btn-success warning_3" id="update_listorder">更新排序</button>
	<button type="button" class="btn btn-sm btn-primary" id="make_posible">可 用</button>
	<button type="button" class="btn btn-sm btn-default" id="make_imposible">禁 用</button>
	<button type="button" class="btn btn-sm btn-danger" id="del_many_button">删 除</button> 
</p>
<br>
<div class="bs-example4" data-example-id="contextual-table">
	<table class="table">
		<thead>
			<tr>
				<th>
					<input type="checkbox" id="check_all">全选</th>
				<th>排序</th>
				<th>ID</th>
				<th>轮播图片</th>
				<th>链接地址</th>
				<th>创建时间</th>
				<th>状态</th>
				<th>操作</th>
			</tr>
		</thead>
		<tbody>
		<?php if(is_array($albums)): $i = 0; $__LIST__ = $albums;if( count($__LIST__)==0 ) : echo "暂时没有轮播小图，请先添加..........." ;else: foreach($__LIST__ as $key=>$album): $mod = ($i % 2 );++$i;?><tr <?php if($album['parent_id']%2 == 0): ?>class="danger"<?php endif; ?>>
				<th scope="row"><input type="checkbox" name="<?php echo ($album["id"]); ?>"></th>
				<th><input type="text" style="width:30px;text-align:center"  value="<?php echo ($album["listorder"]); ?>" name="<?php echo ($album["id"]); ?>" class="listorder_input" ></th>
				<td><?php echo ($album["id"]); ?></td>
				<td><img src="<?php echo ($album["thumb"]); ?>" alt="" width="124px" height="78px"></td>
				<td><a href="<?php echo ($album["url"]); ?>" title="<?php echo ($album["url"]); ?>"><?php echo (substr($album["url"],0,12)); ?></a></td>
				<td><?php echo (getTime($album["create_time"])); ?></td>
				<td>
					<?php if($album['status'] == 1): ?><button type="button" class="btn btn-sm btn-primary change_status" name="status" value="<?php echo ($album["status"]); ?>" id="change_status<?php echo ($album["id"]); ?>" attr-id="<?php echo ($album["id"]); ?>">可 用</button>
					<?php else: ?>
					<button type="button" class="btn btn-sm btn-default change_status" name="status"  value="<?php echo ($album["status"]); ?>" id="change_status<?php echo ($album["id"]); ?>" attr-id="<?php echo ($album["id"]); ?>">禁 用</button><?php endif; ?>
				</td>
				<td>
					<p>
						<!-- <button type="button" class="btn btn-sm btn-success warning_3">Success</button>
					-->
					<button type="button" class="btn btn-sm btn-info" id="edit_button" attr-id="<?php echo ($album["id"]); ?>">修 改</button>
					<button type="button" class="btn btn-sm btn-danger" id="delete_button" attr-id="<?php echo ($album["id"]); ?>">删 除</button>
					<!-- <button type="button" class="btn btn-sm btn-link">Link</button>
				-->
			</p>
		</td>
	</tr><?php endforeach; endif; else: echo "暂时没有轮播小图，请先添加..........." ;endif; ?>


</tbody>
</table>
</div>


       	     </div>
	     </div>
	     <!-- /#page-wrapper -->	     
	     <!-- /#wrapper -->	     
	     <script type="text/javascript" src="/cn/Public/js/admin/common.js"></script>

	     <!-- Bootstrap Core JavaScript -->	     
	     <script src="/cn/Public/js/bootstrap.min.js"></script>
	     </body>
	     </html>