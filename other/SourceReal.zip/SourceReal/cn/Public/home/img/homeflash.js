

  var banner = {};
  var url = {};
  var i = 0;
  $(".banner_big").each(function(){
    banner[i] = this.value;
    url[i] = this.name;
    i++;
  });



 var counts = 4;
 img1 = new Image();
 img1.src = banner[0];
 img2 = new Image();
 img2.src = banner[1];
 img3 = new Image();
 img3.src = banner[2];
 img4 = new Image();
 img4.src = banner[3];


 var smallImg = new Array();
 //小图
 smallImg[0] = banner[0];
 smallImg[1] = banner[1];
 smallImg[2] = banner[2];
 smallImg[3] = banner[3];

 //链接地址
 url1 = new Image();
 url1.src = url[0];
 url2 = new Image();
 url2.src = url[1];
 url3 = new Image();
 url3.src = url[2];
 url4 = new Image();
 url4.src = url[3];
 //alt值
 alt1 = new Image();
 alt1.alt = url[0];
 alt2 = new Image();
 alt2.alt = url[1];
 alt3 = new Image();
 alt3.alt = url[2]; 
 alt4 = new Image();
 alt4.alt = url[3];

 var nn = 1;
 var key = 0;
 function change_img() {
  if (key == 0) {
   key = 1;
  } else if (document.all) {
   document.getElementById("pic").filters[0].Apply();
   document.getElementById("pic").filters[0].Play(duration = 2);
  }
  eval('document.getElementById("pic").src=img' + nn + '.src');
  eval('document.getElementById("url").href=url' + nn + '.src');
  eval('document.getElementById("pic").alt=alt' + nn + '.alt');
  if (nn == 1) {
   document.getElementById("url").target = "_blank";
   document.getElementById("url").style.cursor = "pointer";
  } else {
   document.getElementById("url").target = "_blank"
   document.getElementById("url").style.cursor = "pointer"
  }
  for ( var i = 1; i <= counts; i++) {
   document.getElementById("xxjdjj" + i).className = 'axx';
  }
  document.getElementById("xxjdjj" + nn).className = 'bxx';
  nn++;
  if (nn > counts) {
   nn = 1;
  }
  tt = setTimeout('change_img()', 5000);
 }
 function changeimg(n) {
  nn = n;
  window.clearInterval(tt);
  change_img();
 }
 function ImageShow() {
  document.write('<div class="picshow_main">');
  document.write('<div><a id="url"><img id="pic" class="imgbig" /></a></div>');
  document.write('<div class="picshow_change">');
  for ( var i = 0; i < counts; i++) {
   document.write('<a href="javascript:changeimg(' + (i + 1)
     + ');" id="xxjdjj' + (i + 1)
     + '" class="axx" target="_self"><img src="' + smallImg[i]
     + '"></a>');
  }
  document.write('</div></div>');
  change_img();
 }
 //图片滚动展示 End
 ImageShow();

