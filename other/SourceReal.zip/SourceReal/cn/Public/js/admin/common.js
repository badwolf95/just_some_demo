//	“添加”按钮
$("#add_button").click(function(){
	var url = SCOPE.add_url;
	window.location.href = url;
});

//	“编辑”按钮
$(".table #edit_button").click(function(){
	var id = $(this).attr('attr-id');
	var url = SCOPE.edit_url+"&id="+id;
	window.location.href = url;
});

//	“保存”按钮
$("#my_save_button").click(function(){
	var url = SCOPE.save_url;
	var jump_url = SCOPE.jump_url;
	var res = $("#form_submit").serializeArray();
	var data = {};
	$(res).each(function(){
		data[this.name] = this.value;
	});
	$.post(url,data,function(res){
		if(res.message){
			layer.msg(res.message);
			if(res.status){
				window.location.href = jump_url;
			}
		}else{
			layer.msg('程序有误');
		}
	},"json");
});

//	“取消”按钮
$("#cancle_button").click(function(){
	var jump_url = SCOPE.jump_url;
	window.location.href = jump_url;
});

//	“状态”按钮
$(".table .change_status").click(function(){
	var id_name = SCOPE.id;
	var table = SCOPE.table;
	var data = {};
	var url = SCOPE.status_url;
	var id = $(this).attr('attr-id');
	data['status'] = $(this).val();
	data['id'] = id;
	data['id_name'] = id_name;
	data['table'] = table;
	$.post(url,data,function(res){
		if(res.message){
			if(res.status==1){
				var id = res.data.id;
				var status = "#change_status" + id;
				console.log(id);
				console.log(status);
				if(res.data.status == 1){
					$(status).attr('value',1);
					$(status).addClass("btn-primary");
					$(status).removeClass("btn-default");
					$(status).html("可用");
					layer.msg("已改为可用");

				}else{
					$(status).attr('value',0);
					$(status).addClass("btn-default");
					$(status).removeClass("btn-primary");
					$(status).html('禁用');
					layer.msg('已改为禁用');

				}
			}
		}else{
			layer.msg("程序有误 ");
		}
	},"json");

});

// 	“删除”按钮
$(".table #delete_button").click(function(){
	var id_name = SCOPE.id;
	var table = SCOPE.table;
	var table2 = SCOPE.table2;
	var id = $(this).attr('attr-id');
	var url = SCOPE.delete_url;
	var jump_url = SCOPE.jump_url;
	var data = {};
	data['id'] = id;
	data['table'] = table;
	data['table2'] = table2;
	data['id_name'] = id_name;
	layer.confirm('你确定要删除么',{icon:3,title:'提示'},function(index){
		
		$.post(url,data,function(res){
			if(res.message){
				layer.msg(res.message);
				if(res.status){
					window.location.href = jump_url;
				}
			}else{
				layer.msg('系统出错');
			}
		},"JSON");
		
		layer.close(index);
	});
});

//全选、全不选、同时设置相应的value值
$("#check_all").click(function(){
	
	if(this.checked){
		$("input[type='checkbox']").prop("checked",true);
		$("input[type='checkbox']").attr('value',1);
	}else{
		$("input[type='checkbox']").prop("checked",false);
		$("input[type='checkbox']").attr('value',0);

	}
});

//点击状态按钮时改变value值
$("input[type='checkbox']").click(function(){
	var value = $(this).attr('value');
	if(1 != value || this.checked){
		$(this).attr('value',1);
	}else{
		$(this).attr('value',0);
	}
});

//批处理	“删除”
$("#del_many_button").click(function(){
	var id_name = SCOPE.id;
	var table = SCOPE.table;
	var table2 = SCOPE.table2;
	var url = SCOPE.delete_url;
	var jump_url = SCOPE.jump_url;
	var dataObj = $("input[type='checkbox']");
	var ids = {};
	var i=0;
	$(dataObj).each(function(){
		if(this.value == 1){
			if(this.name){
				ids[i] = this.name;
				i++;
			}
		}
	});
	var data = {};
	data['id']	= ids;
	data['table'] = table;
	data['table2'] = table2;
	data['id_name'] = id_name;

	layer.confirm('你确定要删除这些么',{icon:3,title:'提示'},function(index){

		$.post(url,data,function(res){
			if(res.message){
				layer.msg(res.message);
				if(res.status){
					window.location.href = jump_url;
				}
			}else{
				layer.msg("程序有误");
			}
		},"json");
		layer.close(index);
	});

});

//批量 “可用”
$("#make_posible").click(function(){
	var SCOPE1 = SCOPE;
	statusChange(SCOPE1,1,"批量改变状态为不可用？");
});

//批量 “不可用”
$("#make_imposible").click(function(){
	var SCOPE2 = SCOPE;
	statusChange(SCOPE2,2,"批量改变状态为不可用？");
});
//批量改变状态函数
function statusChange(SCOPE,type,mes){

	var id_name = SCOPE.id;
	var table = SCOPE.table; 
	var dataObj = $("input[type='checkbox']");
	var jump_url = SCOPE.jump_url;
	if(1 == type){
		var url = SCOPE.make_url;
	}else{
		var url = SCOPE.make_im_url;
	}
	var ids = {};
	var i=0;
	$(dataObj).each(function(){
		if(this.value == 1){
			if(this.name){
				ids[i] = this.name;
				i++;
			}
		}
	});
	var data = {};
	data['id']	= ids;
	data['table'] = table;
	data['id_name'] = id_name;

	layer.confirm(mes,{icon:3,title:'提示'},function(index){

		$.post(url,data,function(res){
			if(res.message){
				layer.msg(res.message);
				if(res.status){
					window.location.href = jump_url;
				}
			}else{
				layer.msg("程序有误");
			}
		},"json");
		layer.close(index);
	});
}

//批量  更新排序
$("#update_listorder").click(function(){
	var id_name = SCOPE.id;
	var table = SCOPE.table;
	var listorderObj = $(".listorder_input");
	var listorder = {};
	var url = SCOPE.listorder_url;
	var jump_url = SCOPE.jump_url;
	$(listorderObj).each(function(){
		listorder[this.name] = this.value;
	});
	var data = {};
	data['id_name']  = id_name;
	data['table'] = table;
	data['listorder'] = listorder;

	// console.log(listorder);
	$.post(url,data,function(res){
		if(res.message){
			layer.msg(res.message);
			if(res.status){
				window.location.href = jump_url;
			}
		}else{
			return show(0,'更新排序程序有bug');
		}
	},"JSON");
});

//图片上传
$(function(){
	$('#file_upload').uploadify({
        'swf'      : SCOPE.ajax_upload_swf,
        'uploader' : SCOPE.ajax_upload_image_url,
        'buttonText': '上传图片',
        'fileTypeDesc': 'Image Files',
        'fileObjName' : 'file',
        //允许上传的文件后缀
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'onUploadSuccess' : function(file,data,response) {
            // response true ,false
            if(response) {
                var obj = JSON.parse(data); //由JSON字符串转换为JSON对象

                console.log(data);
                $('#' + file.id).find('.data').html(' 上传完毕');

                $("#upload_org_code_img").attr("src",obj.data);
                $("#file_upload_image").attr('value',obj.data);
                $("#upload_org_code_img").show();
            }else{
                alert('上传失败');
            }
        },
    });
});