
<nav>
    <a href="<?php e_page("home","index"); ?>" class="<?=0==$r['current']?'select':'';?>">网站首页</a>
    <a href="<?php e_page("article","list","menu_id=34"); ?>" class="<?=34==$r['current']?'select':'';?>">通知公告</a>
    <a href="<?php e_page("article","list","menu_id=24"); ?>" class="<?=24==$r['current']?'select':'';?>">规章制度</a>
    <a href="<?php e_page("article","list","menu_id=59"); ?>" class="<?=59==$r['current']?'select':'';?>">违纪通报</a>


    <a href="<?php e_page("article","list","menu_id=19"); ?>" class="<?=19==$r['current']?'select':'';?>">学生党建</a>
    <a href="<?php e_page("article","list","menu_id=37"); ?>" class="<?=37==$r['current']?'select':'';?>">团学组织</a>
</nav>