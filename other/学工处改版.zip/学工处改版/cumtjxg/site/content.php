<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width,user-scalable=0,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <!-- <meta name="viewport" content="target-densitydpi=320,width=640,user-scalable=no,maximum=scale=1.5"> -->
    <base href="<?php echo $system['siteRoot'];?>" />
    <title><?=$r['article']['title']?> - 计算机学生工作处 - 中国矿业大学</title>
    <link rel="stylesheet" href="plugin/awesome/font-awesome.min.css"/>
    <link rel="stylesheet" href="plugin/reset.css"/>
    <link rel="stylesheet" href="style/index.css"/>
    <!--<link rel="stylesheet" href="style/article.css"/>-->
    <link rel="stylesheet" href="style/news-article.css"/>
    <link rel="stylesheet" href="style/media.css"/>
    <script src="plugin/jquery-1.11.2.min.js"></script>
    <script src="script/index.js"></script>
    <script src="script/article.js"></script>
    <!--<script src="script/banner.js"></script>-->
</head>
<!--[if lte IE 8]>
<script>
    {
        alert("您正在使用 Internet Explorer 8以下低版本的IE浏览器,在本页面的显示效果可能有差异。建议您升级到Internet Explorer 8以上或者使用Firefox/Chrome/Safari/Opera浏览器" +
        "。若您正在使用360浏览器，请调整到极速模式查看本页。");
        window.open("http://blog.likyh.com/post/1d697107_81f42db");
    }
</script>
<![endif]-->
<body>
<div class="container">
    <div class="main-container">
        <?php import_tpl("fragment/header.php");?>
        <div class="wrapper">
            <?php import_part("custom.home","nav",array("current"=>0)); ?>
        </div>
        <div class="content">
            <div class="article-box">
                <div class="news-option">
                    <?php import_part("custom.home","subNav",array("menu_id"=>$r['currentMenuId'])); ?>
                    <h3>本版热门</h3>
                    <?php import_part("custom.article","newsQuick",array("menu_id"=>$r['currentMenuId'])); ?>
                </div>
                <div class="article-part">
                    <div class="article-part-title">
                        <h3><?php import_part("custom.home","titleNav",array("menu_id"=>$r['currentMenuId'])); ?></h3>
                    </div>
                    <div class="part-content">
                        <h2><?=$r['article']['title']?></h2>
                        <p class="article-info">
                            <span class="author">
                                作者: <?=$r['article']['author_name']?>
                            </span>
                            <span class="author">
                                审核人: <?=$r['article']['auditor']['nickname']?>
                            </span>
<!--                            <a href="javascript:">--><?//=$r['article']['auditor']['real_name']?><!--</a>-->
                            <span class="send-time"><i class="fa fa-clock-o"></i><?=date("Y/m/d",strtotime($r['article']['publish_time']))?></span>
                            <span class="read-times">
                                <i class="fa fa-eye"></i>阅读 <span class="read-times-num"><?=$r['article']['read_times']+1?></span>
                            </span>
                            <span class="praise">
                                <i class="fa fa-thumbs-o-up"></i>赞 <span class="praise-num"><?=$r['article']['praise']?></span>
                            </span>
                        </p>
                        <div class="article-content">
                            <article><?=$r['article']['content']?></article>
                        </div>
                        <a class="support" href="<?php e_page("article","praise","id=".$r['article']['id']);?>">
                            <span class="support-times">+<?=$r['article']['praise']?></span>
                        </a>

                        <a class="send-receipt" href="javasript:"></a>
                    </div>
                </div>

                <?php import_part("custom.article","hot"); ?>
            </div>
        </div>
    </div>
    <?php import_tpl("fragment/footer.php");?>
</div>
<div class="receipt-wrapper">
    <div class="receipt">
        <h3>发送回执(你发送的信息将发送给<a href="javascript:" class="author"><?=$r['article']['user']['nickname']?></a>)
            <a href="javasript:" class="close"><i class="fa fa-times"></i></a></h3>
        <form action="<?php e_page("article","receipt","id=".$r['article']['id']);?>" method="post">
            <input class="receipt-title" name="title" type="text" placeholder="请输入回执标题">
            <textarea class="receipt-content" name="content" placeholder="请输入回执内容"></textarea>
            <p class="no-login-note">*您尚未登录，请您注意在留言中留下您的联系方式，以便作者联系您。</p>
            <input class="send-confirm" type="submit" value="">
        </form>
    </div>
</div>
</body>
</html>