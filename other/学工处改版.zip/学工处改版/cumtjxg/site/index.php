<?php 

$link = mysqli_connect('localhost','root','','cumtjxg') or die("数据库连接失败");
mysqli_set_charset($link,"UTF8");
/* 数据库配置
   'username'=>"likyh",
    'password'=>"csxg",
    'dbname'=>"jsjxg",
 */


// 根据原来的结构，需要逐个读取，通过相应的Menu的id来读取名称
function getMenuName($id,$link){
    $sql = "SELECT name FROM likyh_menu where id=$id;";
    $res = mysqli_fetch_all(mysqli_query($link,$sql));
    print_r($res[0][0]);
}
// getMenuName(19,$link);
?>




<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width,user-scalable=0,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <base href="<?php echo $system['siteRoot'];?>" />
    <title>首页 - 计算机学院学生工作办公室 - 中国矿业大学</title>
    <link rel="stylesheet" href="plugin/awesome/font-awesome.min.css"/>
    <link rel="stylesheet" href="plugin/reset.css"/>
    <link rel="stylesheet" href="style/index.css"/>
    <link rel="stylesheet" href="style/media.css"/>
    <script src="plugin/jquery-1.11.2.min.js"></script>
    <script src="script/index.js"></script>
    <!--<script src="script/banner.js"></script>-->
</head>
<!--[if lte IE 8]>
<script>
    {
        alert("您正在使用 Internet Explorer 8以下低版本的IE浏览器,在本页面的显示效果可能有差异。建议您升级到Internet Explorer 8以上或者使用Firefox/Chrome/Safari/Opera浏览器" +
        "。若您正在使用360浏览器，请调整到极速模式查看本页。");
        window.open("http://blog.likyh.com/post/1d697107_81f42db");
    }
</script>
<![endif]-->
<script>
    
</script>
<body>
<div class="container">
    <div class="main-container">
        <?php import_tpl("fragment/header.php");?>
        <div class="wrapper">
            <?php import_part("custom.home","nav",array("current"=>0)); ?>
        </div>

        <div class="news">
            <div class="banner">
                <?php $i=0;foreach($r['picture_info'] as $v){
                    if($v['enable']=='true'&&$i<5){
                       $i++;?>
                    <div class="banner-pic">
                        <a href="<?=$v['url']?:"javascript:"?>">
                            <img src="<?=$v['pic_url']?>" alt=""/>
                            <p class="pic-note"><?=$v['title']?></p>
                        </a>
                    </div>
                <?php } }?>
            </div>
            <ul class="newsCol">
                <li class="news-col current"><a href="<?php e_page("article","list","menu_id=10"); ?>"><!-- 工作动态 --><?php getMenuName(10,$link); ?>&nbsp;More</a></li>
                <li class="news-col"><a href="<?php e_page("article","list","menu_id=11"); ?>"><!-- 科技竞赛 --><?php getMenuName(11,$link); ?>&nbsp;More</a></li>
                <li class="news-col"><a href="<?php e_page("article","list","menu_id=12"); ?>"><!-- 就业指导 --><?php getMenuName(12,$link); ?>&nbsp;More</a></li>
            </ul>

            <div class="office">
                <ul class="office-ul dep-ul">
                    <?php import_part("custom.home","office",array("menu_id"=>10)); ?>
                </ul>
                <ul class="office-ul innovation-ul">
                    <?php import_part("custom.home","office",array("menu_id"=>11)); ?>
                </ul>
                <ul class="office-ul guidance-ul">
                    <?php import_part("custom.home","office",array("menu_id"=>12)); ?>
                </ul>
            </div>
        </div>
        <div class="activity">
            <div class="part">
                <a href="http://www.lanqiao.org/lanqiao/blue_bridge.htm"><img src="style/image/2.png" alt=""></a>
                <a href="http://219.219.62.224/"><img src="style/image/1.png" alt=""></a>
                <a href="http://www.lanqiao.org/"><img src="style/image/5.png" alt=""></a>
            </div>
            <div class="part">
                <a href="http://online.cumt.edu.cn:8080/jsjwhj/"><img src="style/image/3.png" alt=""></a>
                <a href="http://www.rcccaa.org/"><img src="style/image/4.png" alt=""></a>
                <a href="http://www.smartcar.au.tsinghua.edu.cn/"><img src="style/image/6.png" alt=""></a>
            </div>
        </div>
        <div class="other">
            <div class="space">
                <h2><!-- 创客空间 --><?php getMenuName(13,$link); ?></h2>
                <div class="space-img">
                    <a href="<?php e_page("article","list","menu_id=14"); ?>">
                        <div class="pImg"><img class="activity" src="style/image/activity.png" alt=""></div><span><!-- 科技社团 --><?php getMenuName(14,$link); ?></span>
                    </a>
                    <a href="<?php e_page("article","list","menu_id=32"); ?>">
                        <div class="pImg"><img class="share" src="style/image/share.png" alt=""></div><span><!-- 开源程序 --><?php getMenuName(32,$link); ?></span>
                    </a>
                    <a href="<?php e_page("article","list","menu_id=33"); ?>">
                        <div class="pImg"><img class="project" src="style/image/project.png" alt=""></div><span><!-- 在研项目 --><?php getMenuName(33,$link); ?></span>
                    </a>
                </div>
                <div class="space-tab greek-tab">
                    <h3 class="current"><a href="<?php e_page("article","list","menu_id=15"); ?>"><!-- 创客新闻 --><?php getMenuName(15,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=16"); ?>"><!-- 大众创业 --><?php getMenuName(16,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=17"); ?>"><!-- 万众创新 --><?php getMenuName(17,$link); ?></a></h3>
                </div>
                <div class="makerNews">
                    <ul class="common-ul maker-news">
                        <?php import_part("custom.home","space",array("menu_id"=>15)); ?>
                    </ul>
                    <ul class="common-ul club">
                        <?php import_part("custom.home","space",array("menu_id"=>16)); ?>
                    </ul>
                    <ul class="common-ul invest">
                        <?php import_part("custom.home","space",array("menu_id"=>17)); ?>
                    </ul>
                </div>
            </div>
            <div class="plantform">
                <h2><!-- 学风建设 --><?php getMenuName(29,$link); ?></h2>
                <div class="plantform-img">
                    <a href="<?php e_page("article","list","menu_id=41"); ?>">
                        <div class="pImg"><img class="QQ" src="style/image/abroad.png" alt=""></div><span><!-- 出国留学 --><?php getMenuName(41,$link); ?></span>
                    </a>
                    <a href="<?php e_page("article","list","menu_id=55"); ?>">
                        <div class="pImg"><img class="weibo" src="style/image/cet.png" alt=""></div><span><!-- CET4 --><?php getMenuName(55,$link); ?>/6</span>
                    </a>
                    <a href="<?php e_page("article","list","menu_id=56"); ?>">
                        <div class="pImg"><img class="weixin" src="style/image/xuefeng3.jpg" alt=""></div><span><!-- 课程竞赛 --><?php getMenuName(56,$link); ?></span>
                    </a>
                </div>
                <div class="space-tab build-tab">
                    <h3 class="current"><a href="<?php e_page("article","list","menu_id=47"); ?>"><?php //echo $r['name1']?><?php getMenuName(47,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=48"); ?>"><?php //echo $r['name2']?><?php getMenuName(48,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=49"); ?>"><?php //echo $r['name3']?><?php getMenuName(49,$link); ?></a></h3>
                </div>
                <div class="buildNews">
                    <ul class="common-ul plantform-news">
                        <?php import_part("custom.home","departNews",array("menu_id"=>47)); ?>
                    </ul>
                    <ul class="common-ul plantform-news" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>48)); ?>
                    </ul>
                    <ul class="common-ul plantform-news" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>49)); ?>
                    </ul>
                </div>
            </div>
            <div class="classNews">
                <h2><!-- 班级建设 --><?php getMenuName(46,$link); ?></h2>
                <div class="space-tab class-tab">
                    <h3 class="current"><a href="<?php e_page("article","list","menu_id=51"); ?>"><!-- 图灵计划 --><?php getMenuName(51,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=22"); ?>"><!-- 班级风采 --><?php getMenuName(22,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=57"); ?>"><!-- 三走一线 --><?php getMenuName(57,$link); ?></a></h3>
                </div>
                <div class="classDailyNews">
                    <ul class="common-ul">
                        <?php import_part("custom.home","departNews",array("menu_id"=>51)); ?>
                    </ul>
                    <ul class="common-ul" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>22)); ?>
                    </ul>
                    <ul class="common-ul" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>57)); ?>
                    </ul>
                </div>
            </div>
            <div class="departNews">
                <h2><!-- 学生党建 --><?php getMenuName(19,$link); ?></h2>
                <ul class="common-ul">
                    <?php import_part("custom.home","departNews",array("menu_id"=>19)); ?>
                </ul>
            </div>
            <div class="management">
                <h2><!-- 日常管理 --><?php getMenuName(2,$link); ?></h2>
                <div class="space-tab manage-tab">
                    <h3 class="current"><a href="<?php e_page("article","list","menu_id=4"); ?>"><!-- 心理健康 --><?php getMenuName(4,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=52"); ?>"><!-- 资助育人 --><?php getMenuName(52,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=58"); ?>"><!-- 演讲口才 --><?php getMenuName(58,$link); ?></a></h3>
                </div>
                <div class="managementNews">
                    <ul class="common-ul">
                        <?php import_part("custom.home","departNews",array("menu_id"=>4)); ?>
                    </ul>
                    <ul class="common-ul" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>52)); ?>
                    </ul>
                    <ul class="common-ul" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>58)); ?>
                    </ul>
                </div>
            </div>
            <div class="communistNews">
                <h2><!-- 团学组织 --><?php getMenuName(37,$link); ?></h2>
                <div class="space-tab youth-tab">
                    <h3 class="current"><a href="<?php e_page("article","list","menu_id=38"); ?>"><!-- 支教历程 --><?php getMenuName(38,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=39"); ?>"><!-- 志愿服务 --><?php getMenuName(39,$link); ?></a></h3>
                    <h3><a href="<?php e_page("article","list","menu_id=50"); ?>"><!-- 研究生会 --><?php getMenuName(50,$link); ?></a></h3>
                </div>
                <div class="youthNews">
                    <ul class="common-ul">
                        <?php import_part("custom.home","departNews",array("menu_id"=>38)); ?>
                    </ul>
                    <ul class="common-ul" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>39)); ?>
                    </ul>
                    <ul class="common-ul" style="display:none;">
                        <?php import_part("custom.home","departNews",array("menu_id"=>50)); ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php import_tpl("fragment/footer.php");?>
    </div>
</div>
</body>
</html>