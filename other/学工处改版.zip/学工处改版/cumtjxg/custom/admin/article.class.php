<?php
class article extends adminBase{
    function __construct() {
        parent::__construct();
        $this->cms->setPageTitle("文章管理");
        $this->cms->setControlFile("admin/tpl/article/article-nav.json");
        $userInfo = $this->user->getLoginInfo();
    }

    function getMenuMap(){
        $menu = MenuModule::init('likyh_menu');
        // 生成菜单二维数组
        $menuTree = $menu->getMenuTree();
        $menuMap = array();
        foreach($menuTree as $subTree) {
            $menuMap[$subTree['name']] = array();
            foreach($subTree['children'] as $item) {
                $menuMap[$subTree['name']][$item['id']] = $item['name'];
            }
        }
        return $menuMap;
    }

    function indexTask($page,$menu_id){
        $article = ArticleMode::init('likyh_article');
        $admin = UserModule::init();
        $menu = MenuModule::init('likyh_menu');
        $url=WebRouter::init()->getQuestion("page=#page#");
        $page=new Page($page,$url);
        $r['user_info'] = $this->user->getLoginInfo();
        if(($r['user_info']['type']=='admin')){
            $condition = array();
        }else{
            $condition['owner'] = $r['user_info']['id'];
        }
        if(isset($menu_id)&&!empty($menu_id)){
            $condition['menu_id'] = $menu_id;
        }
        $r['menu_id']=$menu_id;
        list($r['article_info'],$article_total) = $article->getList(array("LA","LM"),$condition,array("create_time"=>"desc","auth_time"=>"desc"),
            $page->getPageSize(),$page->getOffset());
        $page->setTotal($article_total);
        $r['page']=$page->getWidget(4,"all");
        foreach($r['article_info'] as &$v){
            list($r[$v['id']]['menu_info'],$menu_total) = $menu->getAncestor($v['menu_id']);
            $r[$v['id']]['menu_type']=null;
            foreach($r[$v['id']]['menu_info'] as $s) {
                $r[$v['id']]['menu_type'] = $r[$v['id']]['menu_type'] . $s['name'] . "/";
            }
            $r['owner_info']=$admin->getDetail($v['owner']);
            $v['owner']=$r['owner_info']['nickname'];
            $r['auditor_info']=$admin->getDetail($v['auditor']);

            $v['auditor']=$r['auditor_info']['nickname'];
        }
        $r['menuMap']=$this->getMenuMap();
        $this->cms->tableScene($r,"admin/tpl/article/article-table.php");
    }

    function addTask(){
        $r['menuMap']=$this->getMenuMap();
        $this->cms->formScene($r,"admin/tpl/article/article-add.php");
    }

    function addSubmitTask($data){
        $article=ArticleModule::init();
        $userInfo=$this->user->getLoginInfo();
        $up=Uploader::init();
        list($state,$info)=$up->upImage("pic_url",null,array("width"=>172,"height"=>112,"set"=>"thumb"));
        if(isset($info['url'])&&!empty($info['url'])){
            $data['pic_url']=$info['url'];
        }else{
            $data['pic_url']="style/image/default.jpg";
        }
        $data['owner']=$userInfo['id'];
        $dm=$article->update($data);
        if($dm->judgeState()){
            $url=WebRouter::init()->getAction("table");
            View::displayAsTips($url,$dm->getTitle());
        }else{
            View::displayDataMessage($dm);
        }

    }

    function addUrlTask(){
        $r['menuMap']=$this->getMenuMap();
        $this->cms->formScene($r,"admin/tpl/article/article-addurl.php");
    }

    function addUrlSubmitTask($data){
        $article=ArticleMode::init('likyh_article');
        $userInfo=$this->user->getLoginInfo();
        $up=Uploader::init();
        list($state,$info)=$up->upImage("pic_url",null,array("width"=>172,"height"=>112,"set"=>"thumb"));
        if(isset($info['url'])&&!empty($info['url'])){
            $data['pic_url']=$info['url'];
        }else{
            $data['pic_url']="style/image/default.jpg";
        }
        $data['owner']=$userInfo['id'];
        $dm=$article->update($data);
        if($dm->judgeState()){
            $url=WebRouter::init()->getAction("table");
            View::displayAsTips($url,$dm->getTitle());
        }else{
            View::displayDataMessage($dm);
        }
    }

    function modifyTask($id){
        $article = ArticleMode::init('likyh_article');
        $r['article_info']=$article->getDetail($id);

        //获得菜单选项信息
        $menu = MenuModule::init('likyh_menu');
        list($r['menu_info'],$menu_total) = $menu->getAncestor($r['article_info']['menu_id']);
        $r['menu_type'] = null;
        foreach($r['menu_info'] as $v){
            $r['currentType'] = $v['name'];
        }
        $r['menuMap']=$this->getMenuMap();
        if(isset($r['article_info']['article_url'])&&!empty($r['article_info']['article_url'])){
            $this->cms->formScene($r,"admin/tpl/article/article-modifyUrl.php");
        }else{
            $this->cms->formScene($r,"admin/tpl/article/article-modify.php");
        }
    }

    function modifySubmitTask($data){
        $article = ArticleMode::init();
        $userInfo=$this->user->getLoginInfo();
        $up=Uploader::init();
        list($state,$info)=$up->upImage("pic_url",null,array("width"=>172,"height"=>112,"set"=>"thumb"));
        if(isset($info)&&!empty($info['url'])){
            $data['pic_url']=$info['url'];
        }
        unset($data['owner']);
        $dm=$article->update($data);
        if($dm->judgeState()){
            $url=WebRouter::init()->getAction("table");
            View::displayAsTips($url,$dm->getTitle());
        }else{
            View::displayDataMessage($dm);
        }
    }
//
    function changeEnableTask($id,$enable){
        $articleMode=ArticleMode::init();
        $result['article']=$articleMode->getDetail($id);
        if(empty($result['article']))
            return new Intent(404,"不存在该文章");
        $data['id']=$id;
        if($enable==1){
            $data['auth_time']=date("Y-m-d H:i:s",time());
        }else{
            $data['auth_time']="";
        }
        $userInfo = $this->user->getLoginInfo();
        $data['auditor'] = $userInfo['id'];
        $data['enable']=$enable;
        $dm=$articleMode->update($data);
        View::displayDataMessage($dm);
        return null;
    }

    function deleteTask($id){
        $article = ArticleMode::init();
        $result = $article->delete($id);
        View::displayDataMessage($result);
    }

}