<?php
// 包含系统函数
require_once 'system/lang.system.php';
require_once 'system/base.system.php';

// 包含系统接口
require_once 'system/interface.system.php';
