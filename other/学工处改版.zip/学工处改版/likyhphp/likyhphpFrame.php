<?php
// 运行框架核心内容

/** @var AppInfo */
$globalAppInfo=new AppInfo();

$intent=new Intent(200,null,WebRouter::init(),'web',null);
$result=startIntent($intent);
