<?php
class aa extends Activity {
    /** @var CmsView */
    protected $cms;
    protected function __construct() {
        $this->cms=CmsView::init("文章管理");
        $this->cms->setPageTitle("文章管理");
        $this->cms->setUserName("可爱的依然");
        $this->cms->setControlFile("tpl/admin/control.json");
    }

    function indexTask($help){
        echo "这是首页，没有的页面也回到这里";
    }

    function loginTask(){
        $this->cms->loginScene("表单提交地址");
    }

    function formTask(){
        $this->cms->setActionTitle("修改文章");
        $this->cms->formScene(array(),"tpl/admin/form.php");
    }
}
