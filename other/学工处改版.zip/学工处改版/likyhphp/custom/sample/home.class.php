<?php
/**
 * Created by PhpStorm.
 * User: linyh
 * Date: 2014/12/2
 * Time: 10:41
 */

class home extends Activity {
    function indexTask(){
        apple::init();
    }
}
