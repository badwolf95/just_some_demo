<?php
class sqlCms extends CodeCmsActivity {
    function __construct() {
        $this->cms=CmsView::init("自动管理");

        $codeCmsModule=CodeCmsModule::init();
        $r=$codeCmsModule->getDetail(1);
        $this->loadData($r);

        $this->mode=EventModule::init();
        // 可以这么增加Control部分
//        $this->cms->controlWidget->reopen("tpl/admin/control.json");
    }
}