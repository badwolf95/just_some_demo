<?php
/**
 * Created by PhpStorm.
 * User: linyh
 * Date: 2014/12/2
 * Time: 10:41
 */

class home extends Activity {
    function indexTask(){
        echo "hello world";
        apple::init();
    }

    function codeTask(){
        var_dump(Captcha::getCode("TYPE_NUMBER_6"));
        var_dump(Captcha::getCode("TYPE_NUMBER_8",Captcha::TYPE_NUMBER_8));
        var_dump(Captcha::getCode("TYPE_CHAR_6",Captcha::TYPE_CHAR_6));
    }

    function cacheTask(){
        $fc= new FileCache("test");
        $cache=new SimpleCache($fc);
//        $fc->delete("111");
//        $fc->delete("222");
//        $fc->delete("333");
        echo $cache->cache("111",function(){return "111".time().";";},1);
        echo $cache->cache("222",function(){return "222".time().";";},10);
        echo $cache->cache("333",function(){return "333".time().";";},100);
        echo $cache->cache("111",function(){return "1111".time().";";});
        echo $cache->cache("222",function(){return "2222".time().";";});
        echo $cache->cache("333",function(){return "3333".time().";";});
    }

    function selectTask(){
        $db=SqlDB::init();
        $data=array('count(1)','student S'=>array('id','num'=>'studentNum'),'project P'=>array('*'));
        $condition=array('type'=>1,'age'=>'> =5','age '=>'<>12 ','icon'=>'like %.jpg', 'text'=>'', 'S.area'=>null, array('or','S.name','=','sg'),'`class` is not null');
        echo $db->selectSql($data,$condition,5,0,'S.age,age2',true,'group by age');
    }

    function sqlTask(){
        $db=SqlDB::init();
        $r=$db->getOne("select * from a where id=:id and name=:name",array(":id"=>1,":name"=>"sg"));
        var_dump($r);
        $r=$db->getOne("select * from a where id=? and name=?",2,"sg");
        var_dump($r);
        $r=$db->sqlExec("update a set `name`=? where id=?","sg",1);
        var_dump($r);
    }

    function imageTask(){
        $s=GDImageDeal::readImageByFilename("./site/images/b.jpg");
        $p1=GDImageDeal::readImageByFilename("./site/images/part4_2.png");
//        $s->appendImage($p1)->getImage()->outImage();
        $s->appendImage($p1, 50,50,200,200)->appendImage($p1, 200,200,50,50)->getGDImage()->outImage();
    }

    function fontTask(){
        View::displayAsHtml(array(),"tpl/preview.php");
    }

    function fileTask(){
        echo <<<fileForm
<form method="post" action="http://localhost/putuan/base/picture" enctype="multipart/form-data">
    <input type="file" name="picture"/>
    <input type="file" name="file3"/>
    <input type="file" name="file4"/>
    <input type="text" name="filename" value="hehe.png"/>
    <textarea name="file2">iVBORw0KGgoAAAANSUhEUgAAAPkAAAEMCAYAAAAGZxCOAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAHlhJREFUeNrsnTuMI8l5x4u7qz3ZPpk8w4BhSAB7nRiOhgsosoPphQNnHm5gwIqGEykcbubI25M5W0540TQjBQa8HGUKjO0JrOiMIxMpXBKGbdmQfUNbhqyT78b1cb7e6eHw0Y+q6qrq/x/om715NPtRv/oe9VVV6+bmRkAQ5K8e4RFAECCHIAiQQxAEyCEIAuQQBAFyCIIAOQRBgByCADkEQYAcgiBADkFQ/XqCR+C+nl0e9eSXjjzCzLfDtV+b80GayuP6/dFlgqfnv1qYoOIc0CnMdBDchxVPOZNHwuBPJPjXeMqAHKoH7D4fR5o/jqCP6QDwgBzSDzdBPTAA9jZdymMEtx6QQ+rhJrAjeXQtuaQFXY+EPcbbAeSQX3ADdkAOKYI75Di468glX8ljKGGf4u0Bcmg33B223KeO3sKZBD3CmwTk0GbAafhr4pD13ibKxvcl7HO8VTuFirf6Yu/PPQCcdCCPKY8EQIAckjBQ7H3h2W215fGWOy8IkDce8GOPb/FC3iNidEAOwD3Xa4Bul5B4A+C6dILxdEDeFMDJqr02/LFLcTvhZC7uZp4J/h6pl/leOoOtx7G1Sr1ASSwg9x1wyji/NfBRVJySMMRJ2Ykl8noDhj3k40BBZ9PD8Bog9xXwgKFra/oImjxC4+zapofyPaSTZMoCP5PX10OLAOQ+Qk6W9VDxaanwZCRqmPfNwA8Z+KIdFyrjALl3gBMMbxSecixu53cnFtxbOredoM1bzAO3HZB7BThBMFfkplOsPbAVDi5+GeW810t5H6iKq0EYJ1evkQLAyS2nzHRos/XjITJy489y/PoRz7aDYMmdtuLU4N9XPI2T8StPuCHodyXorqjjQksB5C5DTo28bNELLcjQd32OtnwG5Mnsmjr7XM09ttKxfdZNghYId92EFS8LOA2H9XxYhEHeAyUdX4rbZNsmDauB3ZJ/36Ln9IU83t0drZvb77cGaI2w5HVZsG06ZzB8ex5kZZMt+YlPig8BtihpR884T0Z/5RVJ646Va2DJlaqMBTnxEXC26AQYxd+zDT8umGVfWee3Iv+QXfe2g4FVB+TqrNZAFM+oez+BIwP6sjzkKwteZv59+9byt3qAHFKhouO/Z02ZocVu+TroR1xPkCMGF1WeU7vi3wNy6K7RFvjdcdNKPDMWPaswx58ORfWag4Omu+2AvLqrHhb4dZqs0cgGx6C/Kgi5qmfVB+RQFeWFfNn0xiZBp+z4Jf/vnli5FQh1C10eAXLIBOQDTND4YJ2pw9s3Qy9Q+7GtAJBDZZUne0uTMyZ4VB8ScUMOdUyCB8ih0tqXGFqKSlVeXoIei9sZdibBmwNyqLC4qmufRnDTNyoyC+VNY9/BE7S1Sto31ktWfITHtNGaJ7vddYKyReWpKpJvlzk6bLqWPh/ri1rSdSTp4Vqnjdr1apY8FLcTJLYJyx5Va5707FSsdHsiO414yzvscEdcZHLRjIGPXZhUBMj1QU5WPDC9FptnkKtYZUcCedPbATjBelDt/KuqutjWd42YXJ9GALxyHE3Pb1DhBMs9fz8U1Zedpr+n9fzmNBPR8IgBIK9ZMR6BEtAnt+52KcCHe6abDhReKHkbNNX4PcPeAeR+6woZdaWgU4e5ayGKdVGiLNwWh2eka+voU7bsQ0Duvuaw4kYtOrnCr8TmOeppfExJtsCCBSPIsr+RoE9zDrVqExJvFSVf4KYH+AyWXHvTrbzG25Z3p0u1jbTAklfXulWZAXAjlv36Fuz0KKWFwQumLZ2TOmL1xhfDsCsVsFUIxF2p5a5dPq/4K2V/v7n2swQAOqOJKLcuX1nRpBxy342uyts4d53HttPjUMNH/JM8/k7cVUdhGM3etqByt5siWk07NrXtlfeQZ/bu6jPYpl9oWiwxgRtvrSdHFr1bw8cbWefPW8h5b3A6ji26rNp2JYX2GoJ0x9aub6B7BXnNL6uou0bWI4J1t9Kyk8dHbSkQ+XI0VoPuBeQV986uW9ZsSwzlMiI9PkKF4R91+qGuZJzTkGcs92sP2hBNhxzCsjsbFvYrAq9tQpOzkMuHGwk1S/bapnN24xGzu9cmyZOMKoSKVGPRazzkPARGyasDj9vLkq16DHSchJ3aaFwSduWVcc5Azq453fypg8BuirWCHI2Aim6wyqu7sA+5zRb1Nl+ozNE4AXnODe7r1IJBTo/rIi+J7y+b1KEO4DDTSQyw2quzoAfcdosUXil1262HnOOckWWxN0FN0BHI2qraMtV5ff4crPrqtlV/U4fbbjXk8sFQD3hsEdh0PZM61vVKJzYgIed8rD7JabCUZduthJwb9EToqS0vGk/TdYxcWLCvyfqbH/9+yKHOehHLnI9VKPVXf/yv85rbdo89wDygK7Hm1kGuaHE9FVY7Eig/tRnqQNyNTxeKd6nTlrDHDoCuxJpbBbkFgK/gbsrQ1eDv/yKM//RvEwctNsW3VTcxJNj7dVn2AqBXtubWQF4z4I2CmwGnRva5PMYS9IEjcEcKQjgqI55IuCcWtHnyQt7ua5uyXQa+QD6tAfAlx9uRaJAk4B2OUdNx+hMJemwp3GU2P9gGd1R3TL6h3dO97av9eFllCPWRJTca1wA4FZr0GrrDSSTuF+JcSPD7FgJO1zSvCDh15C8k3APbACfxsOhsz69Veje1W3KuQTc5wWTJrnkj9yiTMJPr937Lc6EYfWoB3KqsN8ETSritTp5yfP75rjYr22vpteEe1XxzoWHAZ2y9m7wJ4TbPhRJACbvydQJOnVCiwj2XcPdsB5ytOXWs5zt+pc3xu1uQZ8bCTWlMpYKoA9/p+tUKugS8x7mCAwWADxzsfHdtHhG6aMnzVv6oEK28MWg43GlGfd8zJ8DimgBPFLQJFwFPKxlH3kDOdbwmqtmoZ3yJKZsfFOT8vSPZIYwcBHzmIuAZjfZ0vm5AnpkyagLwELO37qnIzKZTCfrAJcCrWDuLrPl4BzuhE5ALMzPKtK6Z1SDR0FqoEfCOIsBX03FdSLJVtOaB9ZBzT3QMwGtTGQgmHMvbCjhpKAH34n1zu104C7khN30AwLeqzHNpM+gdDW1BRQHUuM7JJpo0cRJytuK6k20niMG3iyejLEv8KVXHKRta40o2Fct4kcXzcSENNyE3YMXHyKJXakD7dLAnXizipqt6T77E4esue6LyfEYgN2DFZ5726Do0LGnNSccKatwjRXH4uQQ88fg9XTkFuWYrni50iMUd8rns9JzCCqDHZd12Hi5T5aZHnr+quTOQ82qVOq14hERbYdCnFUBvV/CaVBXYeOmmOwu55h73quGTTVSAvijj8he15tKKq6py9N1NTzV1CXKd85QHwLUy6ORCzwr+abvIs+dkm4rOvglueqprVdZdK+S8Zrqu6rYzzChTGqMXBb1I562qynHYADdduQuv25LrsuILhfEdQL8DvYjrnsv15rXZVFQ5XtqwLpuF1r0+yHkiypGm02PXTz2gU6e8VHVOhWPiqw0g8ZbKxek6LXmoy4qj6EVrjK4SJrK8XQXniWxcnw2Q63PVI7xrraBTB1q5EENa8VioyabTHHGEZrebIF7bBrkOSw4rbkZ5OtLlHsBVzTYc4HWUt+LaIOcCmK6GUwNwM9Y8Efuz7YkBwM98mUKqwEgmZU/0RNMF9jSdF26bOVGjOtgTb2fhVrWMcqorCThCsy3P21fIx65k1L/3oz8nT0b84M9+OHe4Ue161ovsjitckx4LdRtkUCjQbzjUWUt+WaXtPzJwgU101emFTCXsvjbUKAP4UKjdw261sk/Di15IgQorrhPyQPH5Fqrn2OqUtODX/GLeStAn8uh41PguyYrTJgjyoHfyRqirakwBb/SEI64x6WaeiZWQq066uVjplFo7KgiaS9Bdiy83eWOz7zz9yV9zco22WlI5u3BV8NJ0wDc8+0nVMFU55LyvU5NddZGJx9Otb8jSvZagE+wD2y07zzC7B/DT1i9/+oe/8eOffPz4PynrrnoxztSCx+B7pf6m0MgmS666AS8dni9OL2ix5uFcsGWP5dGzvZF9o/W/4jtPf/pvf/DNf/yjlvj6exo+iwpvAljwjZb8SsUkrCcO3LCzkxIoNifLLf/5bu1HbbaGx/LnC75Him8TjudrN+bfevwf4mN5tB//O/3/72n4jNXusqhm2+gJd1VZcV2Qq7ZOicsvTUKbSJBfidsE1bb8xSkfgqGn3pssWwp89t+6NKcQ4zQ5/MtnH/3z4UeP/kfX5xDcBPYIGfTNHSx/HatKNuuAvAPIH4A+Ytc8Tyzb5ePQ9HXKaxTfePy74vr/flv8zpN/EZ88+bl4+uhLVadfcG4FcO+HfCkUztGw3V1f+rIwhASdEm5C6N9BppJ+/dWv5X9b4mdffVv87Fffli77f4uPn/yX+C36Ko8iuhGtf2iJm88IbsTcuVz1AYdyShdEsR1yrxqGK6Bn9YuvvrU6Uj199CvxtPXl7Vd5PPh96QV8dfNY/PLr36T//RN5/JxCOBpZsCTfYLPIetNss0jlSW2HPPHtLboIelZffv2R+FJ8JEQG/D064uNC3vclWXX5DLDLzWYrTqGu8irJR5bf+9zHF0qgi7sx9CaJYH+b1gsA7QdWfKhjuFgH5AkgzwU61XyfCIXLLTmkLlt2wH5rxVf1/7rWSrDdknsdw0nQ6aWGovhKqT7CHjYU8JWLLgHX1tlZDXkTdkaRoKebHJyL5opgf+fhZJ48GgrN02pbNzc3OnqnG0WQt5r0tnlqKln3doOBX+1t15TkHFly3eskPNL4oqDiVp0adtBwq04dHCXnGlHuSoB//7utwEXIVbjZi4aCfs1JuRdC4fa1DupUgj5tiPse6ATdZsjnDbfqNFmFYvWTpnZ44na1mbnFs/WUgt5EyHsCWmXg5RE0GHZy35MGDLX1XIM8UfRyoYewkxt/2UDQLzwHveMU5FxcvwCa2tx4ysJ/Ig+awtqkMXafQXfOXVdlzaHtsFOCbiSPHgNP7vy4AZ2rr6Brg1zLODmJC+4vqp4Ge5AXF2eke3x0Ml93KV2YYi7ukp7XXKyz73OyDTVtrCF/1TUv/oQrBp3X97/bWhXEfPrZTega5NQAvqh4mhcuLcUM7ex4wkwnkP676qq+Lyh88QDyiJ6Jc5Az6FTcUWWP8hNscNgIjyPMeB5FwKeiq57jO9UQ5MRJRxfkuueTV4U8AAp+5xUEL2CZAT+19OmxC/o2tzHXh1sDoXEylm5LXtVlpyVpQ+DQaGufQt/nr5uGVs9khxE5asVTRq6cdNcZdHK3y66CQtsjwZpDWej7GeizVv6Zi267hJzu461OyE1MNa0SU3d5r3MISl38CdX2c2HQc3E7bKh0dVPD0u6paoecs+Mzmx8C5CzwU1pKSx4d4W5dRjqX/NpZyFkjQA5pBj527Zqlq54dTZg6DTkPgy0AOQTd08DEh5hc/qlszNTVtFMqBNniqgud4YYxyCta8z7aA+STpKs+EPdHB5yPyVMNbXZrIKguV/3Tz26mXkAurTlVJ5VZ0gguO+STFQ/F/Yk7Wpf5qmNJZlhzqOmK1v5/6hXkvJb6WRnIuUwWgly24n3xcPpt4pslF7xrY9ECGapZRgIOchlwMlKbakb8g7yC+x2hqUCOu+nrs+pmn352c+0l5Oy2vyr4Z5SAgzWHXHXTTzf8KNb92bXuhSZBJ9dlXPDPhmgykGOA93bAPPEa8gy0ReLzQ2nNQzQdyKE4nADfNA+eXPW595DzZm8EbZFquBjNB3IE8ETc7gSzSUb2e7Ni62IGnWKWvBsldnnjdghyFfClCVfdGsgZ9HSf7rygRxg3hywFnNrxfAfgKyuuO6tuHeQlQG+bcncgqADgkfzyTuze5mtpsu1qX+OtjLhOPd7TE6bC2uyQLdZ7lLPNnkkrHjUacgZ9X0yT7RUDjushqA64Cdi8O8VQRt3oZKsntj48hrYnYafe8XSP205Wv29xQwjE3e4hQeZH69sX0T1PN/z/tc6piFDh99nh9jbMabmzGpi+Xmst+ZpV74vtY40fXCCuia+7AaQ7gYQMtMq9wBYM/ZS9nKmp5A3AbqXvlI6yG4a8ku9rBMi3gx4w6Lugeclz1k336iH37H1hfl91KiSie540xdqzi5zdbHHfho7Jln9vU3q+QGFHPZbvZ1DH83IG8gzsQ46B2lvi85Cz9LobWgr1sUWPZ8HAj0xUUhl2jUOG78DB26gNcCchZ9DTKXvHJkHnBjfkuKpr+WOaMeyxw2D3RbW99BoPuLOQZ2DvMeyHGxp4qCrjnoF7WIM7rsK6x8Jg8UVDn/MmnctnXntlptOQZ2APxcNhDAK9L0Gfo9F98HCiOhI/DYSbnvVAPuuJDRfjBeRrln2YceNLu+4cc48ccMvLWPahLQ2Qk2ixR8/5kgG3xmvyCvK1mD0dxwzYoic5G10g9mfxfdAVN8Z5jYDvq4Fw7XmSp5TYdmFeQr4GPEFLiY/JPovO1jv2xGW01oVn93ziQUeaziSLbB7N8B7yAo1uW7a+CTLmYuaYgumCxSZjMbHRagPy7e75xOFGpzJW7+ssqFEMOF3vnM+XLQd+UAKcKSsmZYtosv9eV/ac9HXuarFRoyHnUsWkQe55Hp3oGluXz5s606MKUE/4fSUo5wXkeRrcgF10AP5Qysd3eZ716xIxL3U4MSboAPIygF/g9e+UskotHiZ7V9BqRxz3wmIDcgCuUZUTchyHkxXOMw5OlnvoYimuzXoCwI0rTRgJ/jpf+3l2RlUg6i0Sofg5IUtcAfRhzns4F7dDUdeK3/n6DLW5L5N3YMkfvmwaA39r+GNpuCURFbOz3FADcTdPvWc4l3Alrz0scd10ze9zdHoDlcNR3Jnvmtyy5PcS21L5B8jV9OaJATDSDLD2MVS+p3Smlonhv8IxurxGcruP93SCfVXWm+GOCno/VpX5AvLyMeFcM+BjtgpJTfcYsFvc1+ze5wY9hxVXmdhTUUE3ZtivAbl7kE81Wbp0WV2rpnCyNRsIfSWjucbR9wyZKVutVHEx02qKsm+gew25pgkQVsK94d5DUWwV0SJ6sc9rkZ8/3+JVKFvnTFOJrHegewt5ibFZL126knFqno4u2PYcdjx7paukyM9JNHViViz2oEqPPAU83UlSlRZsvQau9fDsWlOS7kzhadti9z5em5bHvlQMuM6Q5JQ7KkBusVRaLioI6bky42gL6NccAz8XxXaP3aVDjrvzQD4T6tcbjwy0IbjrDXDTT3yrvtIwrfZ5dvx/Q1Z9yTHuVOE9mKp5eOZD4YyPllxFD7zkxhv79nDYqpNVPVF0yvVntO7mRhoml5jaLafvwzv3CnJFcdpMteWxOFZ/LvJvFb1NB2tue3Z+9pWmVWcCQN5cSx4B8EKgp1tFzyqeashu+jrkujLUppaNCgC5fVa8qwDwRk1tVAR6O9PBppCPPegsu4DcHyveSMCzcboC0I+5nr6tyKuCAPk9Kx5W6HUXTQZcMeijjBWfAy9ArlJlYz9KOvWx+sg90PuifDIujZVjzZe6MPRIrgC5HVacxn3LLg44wNphD0Cfs0UvC/ovDBQOmfISpoDcDg1K/t1ZExYMKAn6tMJz/TiTadclU+8tAeTuQn6laqqjx6ATSGcG34ltkC99MQJOQ86uetFphksDjdAX0KOScelA83WRuz7WfPsjX96j65a8TEVShMxvYWCLxuddHk7TqUhUr9bbpgUgt0dhwd+f2bg/t+XWfC7KjXmbsOa6KuoGPo24NA3yIbAtBdSohNveN3BdsQa3/cTlacVeQc4Z3CIFMFe+vTzDKtpBanXZ6f1TKTPPqDtXCHjs24tz2ZIXbUAROK1kNaclrGaoGOwOgc2Lc9Kc9Qv+N73blxVidPq7l77u3NIUyGHF1SgqCFKoEHB63wQ07YCTHVGhfyd8kHd3VuAal/z7gc81E08aAnkMPpVY8zlvmHBqEvIcm2MQ6LTufZ87oohXj+ltuQY617QpxVDOLv9UYKVOKmroAFF1sbDYv/VRVpWWUCq4OcYrjJ745a7nXTgAVlyxNS8Ym1dNvhXZQ/6NgfF5QG6hAHm9z7Q0dOw1HON9NxDyAhMglphlpsWaU6i00A25KDcicsA750COW/K8kGOWmT7lfbal8iEci5ddNtqrzRHgru9Wgldcu8te1pL3DV0fIAfk0BaXfZrTZW/XBHkXSTj/IV9itpmbnWjF1X5UdhSA3HIh4WYJ5CVWilEFJ+JyQA4ZsuR1QQ533XPIsQKr/ricwiGlCzcodNWr5AMAeZPjRUi7x6TUxTawqCQghwB5Ta562VABkFuiOdx1b8MiZMQB+YdYcN/vIPHmmCVf20sNlhzuOuSQJc/bEeiw4oDc4Wu/Al/OeF7XNUIOdx2xIGTDeyi5UUYeNX6s3OXln8gFPAJjtVvpqQR016/k3Qo51HSJSlcF4s6ox0cn85XCgk2rBz+vOz/kOuQ7Xwa2JHbK0vdthJyh7nMnFIpiy4CnnRcg1wE597AJGLP+Pem25AcVwO4r8BZrX1/QWch55dBFiZ4VUuu+Bnt+ZZ7zHF1L7mUgbjeS8KYk1vUhtF2WOgCCRrTvOeex5KFmeHv7LLc8Ir7W14oBvwbkgBzuuv4poZ0dgA/Y21ANd9FwBe56CcgxzbB+zXImP3VD/iA/w3E3rVN36PtLcNqSc3nrDJa8VoUlO2GT8fhgg/s+bQLgPrjrpHjL9w/AnxF1qkAuzKzecpCu3iq/Dvm6TCX6poC8uiY7rEQIBrWr5wDkpHeyPZDn90YYzJzbUKvhPOTssl/W3IAA+UNdWhKPZ2V6mG5mwwvyZRbaBJCbF8fT7aIeluF4vE5NAbk6a05x+aY1wA85iwqZd9UnFf8ekAPyB4q3fB/TF/Vpm6c0zumqA3JAXki0yd0SkBtVv2CH26hwijeGBOQKH+g1g76uI7jsWuLx3pZ4elagcfs8Tm3Noia+Lf+0zZoPgaUxKz4q0En4rASQ67Pmm4AegEnl2vRMF5wEzSMXIScDciaPT8T+TSUmgFwf6NTI1scnuzwRAVLjqodbXPWowGlcg/xcHoFsXxEbk11JtaVNqwX7ulrroGIDhIo/36sCVtwlyCm2fibvbbg2YpC4YMW9hZx70XNYcy1WPJBfjhV0orZDTu74iWxL4ZZ1/gNAXr+o0a0XyETItCt5rg9c2SLDRXsq5WzQJbvmuzyTXZAngNyMNSfXaj0DTHEkMu1qrfiyhBUPLLbeL2Xb6VeYWDK2bQFRr3dQYbf91dq3Xzdg+EaXNg2PlQHCxuefWu9JxXuY2HZj3m+TJF8aNczx2rdj8FrYiofi4cql5yWrumwKmcpa703hxrJAJwHIFYtc9Oyw2gEv3AflA7yzoWOkyjYfQp9+UTB3rFNgpfFoBOSZ+HwJt72UInF/XHwp/JgTUNYTCQqEM4DcIOhzcTshIgt6gmx7Lqt1ugZ4mGf7aMtVxRPZZMmvbH0mjdq6mBNxWdAprkqA8k43fd2VHSqo5qo7+0zvf1Dh73tbvB0ByO0BfbgWn8dAeqMScT/BdFKwqm2b6i75LN1Rbdl9dWHLtFJAfgc6NdSXGYt+DNAfNOZ4rTGrArxuyMcV76PvkhVvLOQM+mTNdT9Gxv0e4MeaAE8ToYs64nBRvRgq3GDFY0DuToz+uumgc32/NsDXQgHjcbiCarS+S1a88ZBnQA/E3Tj666a67gz4RQaKFxqtlOlnPKiaMOQh17ZLVhyQ33cfyaKPmxqj8/1eZNzaUGcyic9tymU/UVSJtm7FnSgGat3c3IDyh9ZsxD122tivPb7fDt9v6qJfKnJri3oOukSJtoGi66WOKV2XjsbFQ0DubsPvsTt5wG5r3+Yhkgr3SWHKRNxl0V9xrb/Ja5gKffvWqQScOsMvMt964UqbgLu+JU6XB4F+xhb9nW8JOXk/5HqmgJHH8tw04GmsbDvgrHDt3M50+rDk+axdzG7aTChI4FjgntP9HLGXMqJ1yywIkS4sBjw7rEjPLHAphAPk+V9yyHB02cKPXIvV2XrH7J1QkjGypd5aIejKAefrm/O7P3Ehow7IqzdGsnxkEYcuvHDuoCL2Rq4Y7sTS65yI8ktDnenySuS1ESi0U6tzs+8AeXVwAv46sc2yr8FNlju2PZbckAzMI+3JUXbXhy6OtAByNY2SxksJqITd+HnN10TexoA7oJjhnjv2XIfcQbX3wD1yMXQC5O4C32O4yJWfsnWfG/ps6mT6mc4mdjlBuNZh9cTd9M50Y4O5jd4TIG+ehQ/ZmqagJ6qg5w4lPX/aqSQ+gA0Bctct/XUZ0DOdxpytGsE8hSWDADkENVyoeIMgQA5BECCHIAiQQxAEyCEIAuQQBAFyCIIAOQQBcgiCvNH/CzAAHhE40rrE8H8AAAAASUVORK5CYII=</textarea>
    <input type="submit"/>
</form>
fileForm;
    }

    function fileActionTask($file2, $filename){
//        var_dump($_FILES);
        $up=Uploader::init();
        $re=$up->upFile("file","upload/");
        $re2=$up->upBase64File($file2, $filename,"upload/");
        $re3=$up->upImage("file3", null, array(
            array("set"=>"big","width"=>640,"height"=>480),
            array("set"=>"middle","width"=>160,"height"=>120),
            array("set"=>"small","width"=>40,"height"=>30),
        ));
        $re4=$up->upImage("file4", null, array("set"=>"hehe","width"=>640,"height"=>480));
        var_dump($re);
        var_dump($re2);
        var_dump($re3);
        var_dump($re4);
    }

    function chineseTask(){
        echo Chinese::pinyin("普团网");
        var_dump(Chinese::xing("吕依然"));
        var_dump(Chinese::xing("邓松高筠"));
        var_dump(Chinese::xing("上官婉儿"));
        var_dump(Chinese::xing("爱新觉罗玄烨"));
        var_dump(Chinese::xing("小可爱"));
    }

    function dataTask(){
        View::displayDataMessage(new DataMessage(DataMessage::STATE_SUCCESS,"标题","具体的描述，这个参数可以省略"));
    }

    protected $className=array();
    protected function getNodesInfo(DOMNode $node){
        if ($node->hasChildNodes()){
            $subNodes = $node->childNodes;
            foreach ($subNodes as $subNode){
                if($subNode->nodeType==1&& $subNode->hasAttribute("class")){
                    $this->className=array_merge($this->className,explode(" ",$subNode->getAttribute("class")));
                }
                $this->getNodesInfo($subNode);
            }
        }
    }
    function domTask(){
        $s=Request::http_get("http://www.pzjsh.com");
//        echo($s);
        $doc = new DOMDocument();
        @$doc->loadHTML($s);
        $node=$doc->getElementsByTagName("html")->item(0);
        $this->getNodesInfo($node);
        var_dump($this->className);
    }
}
