<?php
/**
 * Created by PhpStorm.
 * User: linyh
 * Date: 2014/12/3
 * Time: 20:26
 */

class apple extends Data {
    /** @returnn apple */
    public static function init() {
        echo "apple 类成功运行";
        return parent::init();
    }
}