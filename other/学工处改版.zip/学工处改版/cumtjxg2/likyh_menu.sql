-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-11-14 14:17:26
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cumtjxg`
--

-- --------------------------------------------------------

--
-- 表的结构 `likyh_menu`
--

CREATE TABLE IF NOT EXISTS `likyh_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `point` int(11) NOT NULL DEFAULT '0',
  `level` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- 转存表中的数据 `likyh_menu`
--

INSERT INTO `likyh_menu` (`id`, `pid`, `name`, `point`, `level`, `icon`, `url`) VALUES
(1, 0, '机构设置', 0, NULL, NULL, NULL),
(2, 0, '心理健康', 0, NULL, NULL, NULL),
(3, 0, '学生资助', 0, NULL, NULL, NULL),
(4, 2, '心理健康', 0, NULL, NULL, NULL),
(9, 0, '学工新闻', 0, NULL, NULL, NULL),
(10, 9, '工作动态', 0, NULL, NULL, NULL),
(11, 9, '科技创新', 0, NULL, NULL, NULL),
(12, 9, '就业指导', 0, NULL, NULL, NULL),
(13, 0, '创客空间', 0, NULL, NULL, NULL),
(14, 13, '科技社团', 0, NULL, NULL, NULL),
(15, 13, '创客新闻', 0, NULL, NULL, NULL),
(16, 13, '大众创业', 0, NULL, NULL, NULL),
(17, 13, '万众创新', 0, NULL, NULL, NULL),
(19, 0, '学生党建', 0, NULL, NULL, NULL),
(20, 19, '党建文件', 0, NULL, NULL, NULL),
(21, 19, '支部风采', 0, NULL, NULL, NULL),
(22, 46, '班级风采', 0, NULL, NULL, NULL),
(43, 29, '测评公示', 0, NULL, NULL, NULL),
(24, 0, '奔腾报&E时代', 0, NULL, NULL, NULL),
(25, 24, '奔腾报', 0, NULL, NULL, NULL),
(26, 24, 'E时代', 0, NULL, NULL, NULL),
(27, 3, '学生资助', 0, NULL, NULL, NULL),
(29, 0, '学风建设', 0, NULL, NULL, NULL),
(30, 29, '学风建设', 0, NULL, NULL, NULL),
(32, 13, '开源程序', 0, NULL, NULL, NULL),
(33, 13, '在研项目', 0, NULL, NULL, NULL),
(34, 0, '通知通告', 0, NULL, NULL, NULL),
(37, 0, '团学组织', 0, NULL, NULL, NULL),
(36, 34, '通知通告', 0, NULL, NULL, NULL),
(38, 37, '支教历程', 0, NULL, NULL, NULL),
(39, 37, '志愿服务', 0, NULL, NULL, NULL),
(40, 0, '出国留学', 0, NULL, NULL, NULL),
(41, 40, '出国留学', 0, NULL, NULL, NULL),
(44, 29, '每月一评', 0, NULL, NULL, NULL),
(45, 29, '学院先锋', 0, NULL, NULL, NULL),
(46, 0, '班级风采', 0, NULL, NULL, NULL),
(47, 29, '未命名1', 0, NULL, NULL, NULL),
(48, 29, '未命名2', 0, NULL, NULL, NULL),
(49, 29, '未命名3', 0, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
