<?php
class article extends Activity {
    protected $articleMode;
    function __construct() {
        $this->articleMode=ArticleMode::init();
    }

    // 文章列表页面
    function listTask($menu_id=null,$text=null,$page=1){
        $menuMode=MenuModule::init();
        $url=WebRouter::init()->getQuestion(array("menu_id"=>$menu_id))."&page=#page#";
        $page=new Page($page,$url);
        // 查询文章
        $sonMenu=$menuMode->getPosterity($menu_id);
        list($result['article'],$total)=$this->articleMode->getList(array("LA"),array('menu_id'=>$sonMenu,"title"=>$text,"enable"=>1),array("publish_time"=>"desc"),
           $page->getPageSize(),$page->getOffset());
        foreach($result['article'] as &$v){
            $v['content']=htmlspecialchars(str_replace('&nbsp;','',strip_tags(htmlspecialchars_decode($v['content']))));
        }
        $page->setTotal($total);
        // 查询上级分类
        list($result['ancestorNav'],$ancestorTotal)=$menuMode->getAncestor($menu_id);
        // 设置当前分类
        $result['currentMenuId']=$menu_id;
        $result['currentNav']=$result['ancestorNav'][0]['id'];
        // 设置页码
        $result['page']=$page->getWidget()->setDisplayContent(false,false,true);
        View::displayAsHtml($result,"list.php");
    }
    function listJsonTask($menu_id=null,$page=1){
        $menuMode=MenuModule::init();
        $url=WebRouter::init()->getQuestion(array("menu_id"=>$menu_id))."&page=#page#";
        $page=new Page($page,$url,8);
        $sonMenu=$menuMode->getPosterity($menu_id);
        list($result['data'],$result['total'])=$this->articleMode->getList(array("LA"),array('menu_id'=>$sonMenu,"enable"=>1),
            array(),$page->getPageSize(),$page->getOffset());
        View::displayAsJson($result);
    }

    // 文章详情页面
    function contentTask($id){
        $menuMode=MenuModule::init();
        $result['article']=$this->articleMode->getDetail($id);
        if(empty($result['article'])|| $result['article']['enable']==0)
            return new Intent(404,"不存在该文章");
        if(isset($result['article']['article_url'])&&!empty($result['article']['article_url'])){
            $url=$result['article']['article_url'];
            View::displayAsTips($url);
        }else{
            $userMode=UserModule::init();
            $result['article']['user']=$userMode->getDetail($result['article']['owner']);
            $result['article']['auditor']=$userMode->getDetail($result['article']['auditor']);
            // 查询上级分类
            list($result['ancestorNav'],$ancestorTotal)=$menuMode->getAncestor($result['article']['menu_id']);
            // 设置当前分类
            $result['currentMenuId']=$result['article']['menu_id'];
            $result['currentNav']=$result['ancestorNav'][0]['id'];
            // 查询子分类
            list($result['subNav'],$subTotal)=$menuMode->getNotBottomSon($result['currentNav']);
            // 记录阅读次数
            $this->articleMode->scanAdd($id);
            View::displayAsHtml($result,"content.php");
        }
    }

    // 记录回执
    function receiptTask($id,$title,$content){
        $result['article']=$this->articleMode->getDetail($id);
        if(empty($result['article'])|| $result['article']['enable']==0)
            return new Intent(404,"不存在该文章");
        if(empty($title)|| empty($content)){
            View::displayDataMessage(new DataMessage(DataMessage::STATE_ERROR,"数据信息不完整"));
            return null;
        }

        $receiptMode=ArticleModule::init("receipt");
        $updateRe=$receiptMode->update(array(
            "title"=>$title,
            "content"=>$content,
            "article_id"=>$id
        ));
        if($updateRe->judgeState()){
            View::displayAsTips(null,"留言成功，请耐心等待作者的回复");
        }else{
            View::displayAsTips(null,"留言失败，请重试或联系网站管理员");
        }
        return null;
    }

    // 点赞
    function praiseTask($id){
        $scanRe=$this->articleMode->praiseAdd($id);
        View::displayDataMessage($scanRe);
    }

    // 热门文章模块
    function hotTask(){
        list($result['article'],$total)=$this->articleMode->getList(array("LA"),array(),
            array("praise"=>"desc"),10,0);
        View::displayAsHtml($result,"fragment/hot.php");
    }

    function newsQuickTask($menu_id){
        list($result['article'],$total)=$this->articleMode->getList(array("LA"),array("menu_id"=>$menu_id),
            array("praise"=>"desc"),2);
        View::displayAsHtml($result,"fragment/quick.php");
    }

    // 首页文章ul
    function sMenuListTask($menu_id=2, $rows=6){
        list($result['article'],$total)=$this->articleMode->getList(array("LA"),array('menu_id'=>$menu_id,"enable"=>1),array(),$rows);
        View::displayAsHtml($result,"fragment/sMenuList.php");
    }
}