<?php
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 2015/8/17
 * Time: 21:03
 */

class admin extends adminBase{
    function __construct() {
        parent::__construct();
        $this->cms->setPageTitle("管理员管理");
        $this->cms->setControlFile("admin/tpl/admin/admin-nav.json");
        $this->admin=UserModule::init();
        $userInfo = $this->user->getLoginInfo();
        if($userInfo['type']!='admin'){
            View::displayAsTips(null,"组织管理账号尚未开放");
            exit();
        }
    }

    function indexTask($page){
        $url=WebRouter::init()->getQuestion("page=#page#");
        $page=new Page($page,$url);
        list($r['admin_info'],$admin_total) = $this->admin->getList(array("LU"),array(),array(),$page->getPageSize(),$page->getOffset());
        $page->setTotal($admin_total);
        $r['page']=$page->getWidget(4,"all");
        $this->cms->tableScene($r,"admin/tpl/admin/admin-table.php");
    }

    function changeEnableTask($id,$enable){
        $admin=UserModule::init();
        $r['admin_info']=$admin->getDetail($id);
        if(empty($r['admin_info']))
            return new Intent(404,"不存在该管理员");
        $data['id']=$id;
        $data['enable']=$enable;
        $dm=$admin->update($data);
        View::displayDataMessage($dm);
        return null;
    }

    function addTask(){
        $this->cms->formScene(array(),"admin/tpl/admin/admin-add.php");
    }

    function addSubmitTask($username,$password,$nickname){
        $admin = UserModule::init('likyh_user','likyh_user_info');
        $data['user']=trim($username);
        $data['code']=getPassWord(trim($username),trim($password));
        $data['nickname']=trim($nickname);
        $data['type']='user';
        $data['real_name']=trim($nickname);
        $dm=$admin->update($data);
        if($dm->judgeState()){
            $url=WebRouter::init()->getAction("index");
            View::displayAsTips($url,$dm->getTitle());
        }else{
            View::displayDataMessage($dm);
        }
//        var_dump($_POST);
    }
}