<?php
import("custom.admin.adminBase");
class CodeAdminBase extends CodeCmsActivity {
    /** @var  UserModule */
    protected $user;
    function __construct() {
        parent::__construct();
        $this->user=UserModule::init();
        $userInfo=checkLoginOrExit($this->user);
        $this->cms->setUserName($userInfo['email']);
    }
}
