<?php
class receipt extends CodeAdminBase {
    function tableTask($condition=array(), $sortArray=array(), $page=1){
        $article = ArticleMode::init("receipt");
        $url=WebRouter::init()->getQuestion("page=#page#");
        $page=new Page($page,$url);
        list($r['receipt_info'],$receipt_total)=$article->getList(array("receipt"),$condition,$sortArray,$page->getPageSize(),$page->getOffset());
        $page->setTotal($receipt_total);
        $r['page']=$page->getWidget(4,"all");
        $this->cms->tableScene($r,"admin/tpl/article/receipt.php");
    }
}
