<?php
/**
 * Created by PhpStorm.
 * User: linyh
 * Date: 2015/8/8
 * Time: 21:46
 */

class user extends Activity {
    function indexTask(){
        $cms=CmsView::init();
        $url=WebRouter::init()->getAction("login");
        $cms->loginScene($url);
    }

    function loginTask($user, $pass){
        $userModule=UserModule::init();
        $message=$userModule->login($user, $pass);
        if($message->state!=DataMessage::STATE_SUCCESS){
            View::displayDataMessage($message);
            return;
        }
        $userInfo=$userModule->getLoginInfo();
//        if($userInfo['type']!='admin'){
//            View::displayAsTips(null,"组织管理账号尚未开放");
//            return;
//        }
        header("Location:".WebRouter::init()->getPage("article","table"));
        return;
    }

    function loginOutTask(){
        $userModule=UserModule::init();
        $userModule->loginout();
        $url=WebRouter::init()->getPage("user","index");
        View::displayAsTips($url,"退出成功");
    }

    function modifyPassWordTask(){
        $cms=CmsView::init();
        $cms->formScene(array(),"admin/tpl/admin/admin-modifyCode.php");
    }

    function modifyPasswordSubmitTask($data){
        $userModule=UserModule::init();
        $user_info=$userModule->getLoginInfo();
        $message=$userModule->passwordChange($user_info['user'],$data['oldPassword'],$data['newPassword']);
        View::displayDataMessage($message);
        $userModule->loginout();
        $url=WebRouter::init()->getPage("user","index");
        View::displayAsTips($url,"请重新登录");

    }
}