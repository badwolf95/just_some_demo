<?php
/**
 * Created by PhpStorm.
 * User: dell
 * Date: 2015/8/24
 * Time: 20:42
 */
class dash extends CodeAdminBase {
    function __construct() {
        parent::__construct();
        $userInfo = $this->user->getLoginInfo();
        if($userInfo['type']!='admin'){
            View::displayAsTips(null,"抱歉，您不具有此权限");
            exit();
        }
        $this->cms->setPageTitle("首页管理");

        $this->fieldAdd("id","ID",self::TYPE_PRIMARY,self::TABLE_STRING,self::FORM_HIDDEN);
        $this->fieldAdd("pic_url","上传路径",self::TABLE_STRING,self::TABLE_URL,self::FORM_FILE);
        $this->fieldAdd("url","跳转链接",self::TYPE_VARCHAR,self::TABLE_STRING,self::FORM_TEXT);
        $this->fieldAdd("title","标题",self::TYPE_VARCHAR,self::TABLE_STRING,self::FORM_TEXT);
        $this->fieldAdd("create_time","创建时间",self::TYPE_TIME,null,null);
        $this->fieldAdd("hidden","操作", self::TYPE_CUSTOM,self::TABLE_CUSTOM,self::FORM_NONE)
            ->fieldModify("hidden",array("showFunction"=>function($data,$config){
                if($data['enable']=='true'){
                    $url=WebRouter::init()->getAction("hidden",["id"=>$data['id'],'enable'=>'false']);
                    return "<a href='{$url}'>隐藏</a>";
                }else{
                    $url=WebRouter::init()->getAction("hidden",["id"=>$data['id'],'enable'=>'true']);
                    return "<a href='{$url}'>显示</a>";
                }
            }));
        $this->mode=ArticleModule::init("likyh_photo");
        $this->addControl();
    }

    function hiddenTask($id, $enable='true'){
        $data['enable']=$enable;
        $data['id']=$id;
        $dm=$this->mode->update($data);
        if($dm->judgeState()){
            $url=WebRouter::init()->getAction("table");
            View::displayAsTips($url,$dm->getTitle());
        }else{
            View::displayDataMessage($dm);
        }
    }
    function modifySubmitTask($data){
        $userInfo=$this->user->getLoginInfo();
        $up=Uploader::init();
        list($state,$info)=$up->upImage("pic_url",null,array("width"=>710,"height"=>480,"set"=>"thumb"));
        if(isset($info)){
            $data['pic_url']=$info['url'];
        }
        $data['owner']=$userInfo['id'];
        $dm=$this->mode->update($data);
        if($dm->judgeState()){
            $url=WebRouter::init()->getAction("table");
            View::displayAsTips($url,$dm->getTitle());
        }else{
            View::displayDataMessage($dm);
        }
    }
}