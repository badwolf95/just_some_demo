<?php
function checkLoginOrExit(UserModule $userMode){
    if($userMode->getLoginId()==null){
        header("Location:".WebRouter::init()->getPage("user","index"));
        exit();
    }
    $userInfo=$userMode->getLoginInfo();
    return $userInfo;
}
class adminBase extends Activity {
    /** @var CmsView  */
    protected $cms;
    /** @var  UserModule */
    protected $user;
    function __construct() {

        $this->user=UserModule::init();
        $userInfo=checkLoginOrExit($this->user);
        $this->cms=CmsView::init(null, null, array(
            "navFile"=>"admin/nav.json",
            "userInfoFile"=>"admin/userinfo.json",
            "controlFile"=>"",
        ));
       $this->cms->setUserName($userInfo['email']);
    }
}
//class adminBase extends CodeCmsActivity {
//    /** @var  UserModule */
//    protected $user;
//    function __construct() {
//        parent::__construct();
//        $this->user=UserModule::init();
//        $userInfo=checkLoginOrExit($this->user);
//        $this->cms->setUserName($userInfo['email']);
//    }
//}