<?php
class category extends adminBase{
    function __construct() {
        parent::__construct();
        $this->cms->setPageTitle("分类管理");
    }

    function getMenuMap(){
        $menu = MenuModule::init('likyh_menu');
        // 生成菜单二维数组
        $menuTree = $menu->getMenuTree();
        $menuMap = array();
        foreach($menuTree as $subTree) {
            $menuMap[$subTree['name']] = array();
            foreach($subTree['children'] as $item) {
                $menuMap[$subTree['name']][$item['id']] = $item['name'];
            }
        }
        return $menuMap;
    }

    function indexTask($id=0){
        $cats=MenuModule::init();
        $r['catTree']=$cats->getMenuTree($id);
        $r['pid']=$id;
        $this->cms->tableScene($r,"admin/tpl/category/category-table.php");
    }

    function addTask($pid){
        $r['pid']=$pid;
        $this->cms->formScene($r,"admin/tpl/category/category-add.php");
    }

    function addSubmitTask($data){
        $cats=MenuModule::init();
        if($cats->update($data)){
            if(!$data['pid']){
                $url=WebRouter::init()->getAction("category",'id='.$data['pid']);
                $message="主类添加成功";
            }else{
                $url=WebRouter::init()->getAction("category",'id='.$data['pid']);
                $message="子类添加成功";
            }
            View::displayAsTips($url,$message);
        }
    }

    function modifyTask($id){
        $cats=MenuModule::init();
        $r=$cats->getDetail($id);
        $this->cms->formScene($r,"admin/tpl/category/category-modify.php");
    }

    function modifySubmitTask($data){
        $cats=MenuModule::init();
        if($cats->update($data)){
            $r['message']="类别修改成功";
            $r['url']=WebRouter::init()->getAction("category",'id='.$data['pid']);
        }else{
            $r['message']="修改失败，请重试";
        }
        View::displayAsHtml($r,"plugin/state/tips.php");
    }

    function deleteTask($id){
        $cats=MenuModule::init();
        $cats_detial=$cats->getDetail($id);
        $cats_info=$cats->getMenuTree($id);
        if(!empty($cats_info)){
            $r['url']=WebRouter::init()->getAction("category",'id='.$cats_detial['pid']);
            $r['message']="该类别不能被删除";
        }else{
            if($cats->deleteRelated($id)){
                $r['url']=WebRouter::init()->getAction("category",'id='.$cats_detial['pid']);
                $r['message']="类别删除成功";
            }else{
                $r['message']="删除失败，请重试！";
            }
        }
        View::displayAsHtml($r,"plugin/state/tips.php");
    }
}