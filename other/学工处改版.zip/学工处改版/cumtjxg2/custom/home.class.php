<?php
class home extends Activity {
    /** @var  UserModule */
    protected $user;
    function __construct(){
        $this->user=UserModule::init();
    }

    function indexTask(){
        $picture = ArticleModule::init("likyh_photo");
        list($result['picture_info'],$picture_total)=$picture->getList(null,array(),array("create_time"=>"desc"),30,0);
        $menuMode=MenuModule::init();
        list($result['menu'],$total)=$menuMode->getList(null,array("pid"=>29));
        foreach($result['menu'] as $v){
            if($v['id']==47) $result['name1']=$v['name'];
            if($v['id']==48) $result['name2']=$v['name'];
            if($v['id']==49) $result['name3']=$v['name'];
        }
        View::displayAsHtml($result,"index.php");
    }

    function navTask($current=0){
        $menuMode=MenuModule::init();
        list($result['nav'],$total)=$menuMode->getList(null,array("pid"=>0));
        $result['current']=(int)$current;
        View::displayAsHtml($result,"fragment/nav.php");
    }

    function subNavTask($menu_id=1){
        $menuMode=MenuModule::init();
        // 查询子分类
        list($result['subNav'],$subTotal)=$menuMode->getNotBottomSon($menu_id);
        View::displayAsHtml($result,"fragment/subNav.php");
    }

    function titleNavTask($menu_id=1){
        $menuMode=MenuModule::init();
        // 查询上级分类
        list($result['ancestorNav'],$ancestorTotal)=$menuMode->getAncestor($menu_id);
        View::displayAsHtml($result,"fragment/titleNav.php");
    }

    function peopleTask($menu_id=23){
        $article = ArticleMode::init();
        list($result['article'],$article_total) = $article->getList(array(),array("menu_id"=>$menu_id,"enable"=>1),array("create_time"=>"desc"),6,0);
        View::displayAsHtml($result,"fragment/people.php");
    }

    function departNewsTask($menu_id){
        $article = ArticleMode::init();
        $menu = MenuModule::init();
        $submenu = $menu->getBottom($menu_id);
        list($result['article'],$article_total) = $article->getList(array(),array("menu_id"=>$submenu,"enable"=>1),array("create_time"=>"desc"),5,0);
        $result['menu_id']=$menu_id;
        View::displayAsHtml($result,"fragment/departNews.php");
    }

    function spaceTask($menu_id){
        $article = ArticleMode::init();
        list($result['article'],$article_total) = $article->getList(array(),array("menu_id"=>$menu_id,"enable"=>1),array("create_time"=>"desc"),5,0);
        $result['menu_id']=$menu_id;
        View::displayAsHtml($result,"fragment/space.php");
    }


    function officeTask($menu_id){
        $article = ArticleMode::init();
        list($result['article'],$article_total) = $article->getList(array(),array("menu_id"=>$menu_id,"enable"=>1),array("publish_time"=>"desc"),6,0);
        foreach($result['article'] as &$v){
            $v['content']=htmlspecialchars(str_replace('&nbsp;','',strip_tags(htmlspecialchars_decode($v['content']))));
        }
        View::displayAsHtml($result,"fragment/office.php");
    }

}