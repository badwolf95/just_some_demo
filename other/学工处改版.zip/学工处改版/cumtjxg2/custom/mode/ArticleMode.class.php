<?php
/**
 * Created by PhpStorm.
 * User: linyh
 * Date: 2015/7/16
 * Time: 13:58
 */

class ArticleMode extends ArticleModule {
    /** @return ArticleMode */
    public static function init($tableName = 'likyh_article') {
        return parent::init($tableName);
    }

    function __construct($tableName){
        parent::__construct($tableName);
        $this->tableInfo=array(
            "$tableName LA"=>array("id","type","menu_id","pic_url","title","content","owner","author_name","remark",
                "auth_time","publish_time","create_time","read_times","praise","enable","article_id","*")
        );
        $this->referInfo=array();
        SimpleSession::init();
    }
    // 获取列表 $tableArray可以是LA和LM的组合
    public function getList($tableArray=array("LA","LM"), $condition, $sortArray=array(), $rows=null, $offset=0){
        if($tableArray==null) $tableArray=array("LA","LM");
        $selectSql=$this->getFormatSelectSql($tableArray);
        arrayDealArray($condition,function($key,$value)use($selectSql){
            if(!empty($value)) $selectSql->addCondition($key,"%$value%","like");
        },array("content","title",));
        $selectSql->addConditionArray($condition);
        $selectSql->setSortBy($sortArray);
        $sql=$selectSql->getSql($rows,$offset);
        list($data,$total)=$this->db->getList($sql);

        if(array_search("LM", $tableArray)){
            $menuModule=MenuModule::init();
            foreach($data as &$v){
                list($v['menu'],$menuTotal)=$menuModule->getAncestor($v['menu_id']);
            }
        }
        return array($data,$total);
    }

    function scanAdd($id){
        if(isset($_SESSION[CONFIG_SITE_NAME][$this->tableName]['read_time'.$id])&&
            $_SESSION[CONFIG_SITE_NAME][$this->tableName]['read_time'.$id])
            return new DataMessage(DataMessage::STATE_INFO,"已经阅读过");
        $sql="update `{$this->tableName}` set `read_times`=`read_times`+1 where `id`=".(int)$id;
        if($this->db->sqlExec($sql)>0){
            $_SESSION[CONFIG_SITE_NAME][$this->tableName]['read_time'.$id]=true;
            return new DataMessage(DataMessage::STATE_SUCCESS,"阅读量增加成功");
        }else{
            new DataMessage(DataMessage::STATE_ERROR,"阅读量增加失败");
        }
    }

    function praiseAdd($id){
        if(isset($_SESSION[CONFIG_SITE_NAME][$this->tableName]['praise'.$id])&&
        $_SESSION[CONFIG_SITE_NAME][$this->tableName]['praise'.$id])
            return new DataMessage(DataMessage::STATE_INFO,"已经赞过");
        $sql="update `{$this->tableName}` set `praise`=`praise`+1 where `id`=".(int)$id;
        if($this->db->sqlExec($sql)>0){
            $_SESSION[CONFIG_SITE_NAME][$this->tableName]['praise'.$id]=true;
            return new DataMessage(DataMessage::STATE_SUCCESS,"点赞成功");
        }else{
            return new DataMessage(DataMessage::STATE_ERROR,"点赞失败");
        }
    }
}