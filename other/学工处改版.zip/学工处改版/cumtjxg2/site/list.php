<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width,user-scalable=0,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <base href="<?php echo $system['siteRoot'];?>" />
    <title>文章列表 - 计算机学院学工网站 - 中国矿业大学</title>
    <link rel="stylesheet" href="plugin/awesome/font-awesome.min.css"/>
    <link rel="stylesheet" href="plugin/reset.css"/>
    <link rel="stylesheet" href="style/index.css"/>
    <!--<link rel="stylesheet" href="style/article.css"/>-->
    <link rel="stylesheet" href="style/news-article.css"/>
    <link rel="stylesheet" href="style/media.css"/>
    <script src="plugin/jquery-1.11.2.min.js"></script>
    <script src="script/index.js"></script>
    <script src="script/article.js"></script>
    <!--<script src="script/banner.js"></script>-->
</head>
<!--[if lte IE 8]>
<script>
    {
        alert("您正在使用 Internet Explorer 8以下低版本的IE浏览器,在本页面的显示效果可能有差异。建议您升级到Internet Explorer 8以上或者使用Firefox/Chrome/Safari/Opera浏览器" +
        "。若您正在使用360浏览器，请调整到极速模式查看本页。");
        window.open("http://blog.likyh.com/post/1d697107_81f42db");
    }
</script>
<![endif]-->
<body>
<div class="container">
    <div class="main-container">
        <?php import_tpl("fragment/header.php");?>
        <div class="wrapper">
            <?php import_part("custom.home","nav",array("current"=>$r['currentNav'])); ?>
        </div>
        <div class="content">
            <div class="article-box">
                <div class="news-option">
                    <?php import_part("custom.home","subNav",array("menu_id"=>$r['currentMenuId'])); ?>
                    <h3>本版热门</h3>
                    <?php import_part("custom.article","newsQuick",array("menu_id"=>$r['currentMenuId'])); ?>
                </div>
                <div class="article-part">
                    <div class="article-part-title">
                        <h3><?php import_part("custom.home","titleNav",array("menu_id"=>$r['currentMenuId'])); ?></h3>
                    </div>
                    <div class="part-list">
                        <ul class="part-List">
                            <?php foreach($r['article'] as $i){?>
                                <li>
                                    <div class="article-img"><a href="<?php e_action("content","id={$i['id']}");?>">
                                            <img src="<?=$i['pic_url']?:"默认图片"?>" alt="">
                                        </a></div>
                                    <div class="article-detail">
                                        <h3><a href="<?php e_action("content","id={$i['id']}");?>"><?=$i['title']?></a>
                                            <span class="send-time"><i class="fa fa-clock-o"></i><?=date("Y/m/d",strtotime($i['publish_time']))?></span>
                                        </h3>
                                        <p class="article-info"><?=TextFilter::htmlCut($i['content'],0,120)?></p>
                                        <p class="condition">
                                        <span class="read-times">
                                            <i class="fa fa-eye"></i><span class="read-times-num"><?=$i['read_times']?></span>
                                        </span>
                                        <span class="praise">
                                            <i class="fa fa-thumbs-o-up"></i><span class="praise-num"><?=$i['praise']?></span>
                                        </span>
                                        </p>
                                    </div>
                                </li>
                            <?php } ?>
                        </ul>
                        <?=$r['page']?>
                    </div>
                </div>
                <?php import_part("custom.article","hot"); ?>
            </div>
        </div>
    </div>
    <?php import_tpl("fragment/footer.php");?>
</div>
</body>
</html>