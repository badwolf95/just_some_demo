/**
 * Created by linyh on 2015/7/25.
 */
define(['jquery',"css!style/form.css"],function($){

})