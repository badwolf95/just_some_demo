require(["jquery"],function($){
    $(".likyh-module").each(function(){
        var likyhModuleName=$(this).attr("data-likyh-module");
        if(likyhModuleName==null|| likyhModuleName.length==0) return;
        require([likyhModuleName],function(module){
            console.log($(this));
        })
    });
    require(['nav'],function(module){
        console.log($(this));
    })
});
