/**
 * Created by linyh on 2015/7/28.
 */

define(['jquery',"css!style/item.css"],function($){

})