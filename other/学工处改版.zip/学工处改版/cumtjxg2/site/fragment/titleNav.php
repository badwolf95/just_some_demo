<a href="<?php e_page("home","index"); ?>">首页</a>
<?php foreach($r['ancestorNav'] as $i){?>
    / <a href="<?php e_page("article","list","menu_id={$i['id']}"); ?>"><?=$i['name'];?></a>
<?php } ?>