<?php foreach($r['article'] as $i){ ?>
<li>
    <div class="date">
        <p class="year-month"><?=((int)substr($i['publish_time'],0,4))?>/<?=substr($i['publish_time'],5,2)?></p>
        <p class="day"><?=substr($i['publish_time'],8,2)?></p>
    </div>
    <div class="news-info">
        <h3 class="news-title"><a href="<?php e_page("article","content","id={$i['id']}"); ?>">
                <?php if(mb_strlen($i['title'])<15){
                    echo $i['title'];
                }else{
                    echo mb_substr($i['title'],0,20,"UTF-8");
                    echo "...";?>
                <?php }?></a></h3>
        <p class="news-text"><?=TextFilter::htmlCut($i['content'],0,30)?>……</p>
    </div>
</li>
<?php } ?>
