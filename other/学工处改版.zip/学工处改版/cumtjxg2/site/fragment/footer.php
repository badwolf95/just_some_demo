<footer>
    <p>苏ICP备05007141号-1  地址：江苏省徐州市大学路1号中国矿业大学南湖校区</p>
    <p>制作与维护:LikyhStudio Copyright@ 2004-2018 LikyhStudio
        <script src="http://s4.cnzz.com/z_stat.php?id=1256290713&web_id=1256290713" language="JavaScript"></script></p>
</footer>