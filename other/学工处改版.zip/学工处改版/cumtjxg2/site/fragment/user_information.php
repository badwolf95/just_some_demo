<div class="user-information">
    <img class="user-photo" src="style/image/user-photo.png" alt="">
    <h3 class="user-name"> <?=$r['user_info']['real_name']?></h3>
    <ul>
        <li class="user-grade"><?=$r['user_info']['real_name']?><?="  "?><?=$r['user_info']['graduation']-4?>级</li>
        <li class="basic-info"><?=$r['user_info']['email']?></li>
        <li class="basic-info"><?=$r['user_info']['tel']?></li>
        <li class="basic-info">中国矿业大学</li>
        <li class="basic-info"><?=$r['user_info']['school']?></li>
    </ul>
</div>