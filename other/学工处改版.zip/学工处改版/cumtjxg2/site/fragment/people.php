<?php foreach($r['article'] as $i){ ?>
<li><a href="<?php e_page("article","content","id={$i['id']}"); ?>"><img src="<?=$i['pic_url'];?>" alt=""></a><p class="name"><?=$i['title'];?></p></li>
<?php } ?>
