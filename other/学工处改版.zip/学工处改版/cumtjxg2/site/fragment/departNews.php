<?php foreach($r['article'] as $i){?>
<li>
    <p><span class="date"><?=date("Y/m/d",strtotime($i['create_time']))?></span><a href="<?php e_page("article","content","id={$i['id']}"); ?>" class="news-title"><?=$i['title']?></a></p>
</li>
<?php } ?>
<a href="<?php e_page("article","list","menu_id={$r['menu_id']}"); ?>" class="more-news">More</a>

