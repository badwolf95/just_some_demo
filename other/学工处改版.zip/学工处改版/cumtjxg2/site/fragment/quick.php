<?php foreach($r['article'] as $i){?>
    <div class="news-box"><a href="<?php e_action("content","id={$i['id']}");?>">
        <img src="<?=$i['pic_url']?:"默认图片"?>" alt=""><p><?=$i['title']?></p>
    </a></div>
<?php } ?>