<header>
    <div class="logo">
        <a href="<?php e_page("home","index"); ?>"><img src="style/image/logo.png" alt=""/></a>
    </div>
    <div class="log">
        <div class="log-key">
            <form action="<?php e_page("article","list"); ?>">
                <input type="text" name="text" class="search" placeholder="search"><input type="submit" class="submit-button" value="">
            </form>
        </div>
    </div>
</header>