<ul>
<?php foreach($r['subNav'] as $i){ ?>
    <li><i class="fa fa-file"></i>
        <a href="<?php e_page("article","list","menu_id={$i['id']}"); ?>"><?=$i['name'];?></a></li>
<?php } ?>
</ul>