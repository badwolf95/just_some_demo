<div class="most-active">
    <h2>热门文章</h2>
    <h4>MOST ACTIVE</h4>
    <ul>
    <?php foreach($r['article'] as $i){?>
        <li>
            <a href="<?php e_action("content","id={$i['id']}");?>"><?=$i['title']?></a>
            <p>
                <span class="read-times">
                    <i class="fa fa-eye"></i>
                    <span class="read-times-num"><?=$i['read_times']?></span>
                </span>
                <span class="praise">
                    <i class="fa fa-thumbs-o-up"></i>
                    <span class="praise-num"><?=$i['praise']?></span>
                </span>
                <span class="send-time"><?=date("m/d",strtotime($i['publish_time']))?></span>
            </p>
        </li>
    <?php } ?>
    </ul>
</div>