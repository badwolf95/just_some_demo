<div class="log">
    <div class="log-key">
        <form action="<?php e_page("article","list"); ?>">
            <input type="text" name="text" class="search" placeholder="search"><input type="submit" class="submit-button" value="">
        </form>
    </div>
</div>
<div class="log-button">
<?php if(empty($r['userInfo'])): ?>
    <a href="<?php e_page("user","index","#login"); ?>">登录</a>
    <a href="<?php e_page("user","index","#register"); ?>">注册</a>
<?php else: ?>
    <a href="<?php e_page("dash","index");?>">您好，<?=$r['userInfo']['real_name'];?></a>
<?php endif; ?>
</div>