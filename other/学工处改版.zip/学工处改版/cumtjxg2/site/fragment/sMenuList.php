<ul>
<?php foreach($r['article'] as $i){?>
    <li><a href="<?php e_page("article","content","id={$i['id']}");?>"><?=$i['title']?></a></li>
<?php } ?>
</ul>