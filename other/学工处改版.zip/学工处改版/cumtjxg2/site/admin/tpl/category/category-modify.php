<form action="<?php e_action("modifySubmit"); ?>" method="post"  enctype="multipart/form-data">
    <input type="hidden" name="data[id]" id="id" value="<?php echo $r['id']?>">
    <input type="hidden" name="data[pid]" id="pid" value="<?php echo $r['pid']?>">
    <br/>
    <fieldset>
        <legend>商品分类信息</legend>
        <?php if(!$r['pid']){?>
            <label for="name">主类名称</label>
            <input type="text" name="data[name]" id="name" value="<?php echo $r['name']?>" required="required" placeholder="请输入主类名称"><br/>
        <?php }else{?>
            <label for="name">子类名称</label>
            <input type="text" name="data[name]" id="name" value="<?php echo $r['name']?>" placeholder="请输入子类名称"><br/>
        <?php }?>
        <input type="submit" value="保存">
    </fieldset>
</form>