<br/>
<form action="<?php e_action("addSubmit"); ?>" method="post"  enctype="multipart/form-data">
    <input type="hidden" name="data[pid]" value="<?php echo $r['pid']?>">
    <fieldset>
        <?php if(!$r['pid']){?>
            <legend>主类信息</legend>
            <label for="name">主类名称</label>
            <input type="text" name="data[name]" id="name" placeholder="请输入主类名称" required="required"><br/>
        <?php }else{?>
            <legend>子类信息</legend>
            <label for="name">子类名称</label>
            <input type="text" name="data[name]" id="name" placeholder="请输入子类名称" required="required"><br/>
        <?php }?>
        <input type="submit" value="保存">
    </fieldset>
</form>