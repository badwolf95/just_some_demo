<br>
<?php if($r['pid']==0){?><a href='<?php e_action("add","pid");?>'>添加主类别</a><br/><br/><?php }?>
<?php if($r['pid']!=0){?><a href='<?php e_action("add","pid={$r['pid']}");?>'>添加子类</a><br/><br/><?php }?>
<table id="dataTable">
    <thead>
    <tr>
        <th>ID</th>
        <th>分类名称</th>
<!--        <th>优先级</th>-->
        <th>子类管理</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($r['catTree'] as $v){?>
        <tr>
            <td><?php echo $v['id']?></td>
            <td><?php echo $v['name']?></td>
<!--            <td>--><?php //echo $v['point']?><!--</td>-->
            <td><a href='<?php e_action("index","id={$v['id']}");?>'>查看子类</a></td>
            <td>
                <a href='<?php e_action("modify","id={$v['id']}");?>'>修改</a>
                / <a href='<?php e_action("delete","id={$v['id']}");?>' onclick="return confirm('确定删除吗？');">删除</a>
            </td>
        </tr>
    <?php }?>
    </tbody>
</table>
