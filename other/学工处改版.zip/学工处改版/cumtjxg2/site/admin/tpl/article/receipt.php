<br/>
<br/>

<table id="dataTable">
    <thead>
    <tr>
        <th>ID</th>
        <th>标题</th>
        <th>内容</th>
        <th>文章ID</th>
        <th>发布时间</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($r['receipt_info'] as $v){?>
        <tr>
            <td><?=$v['id'];?></td>
            <td><?=$v['title']?></td>
            <td><?=$v['content']?></td>
            <td><?= $v['article_id']?></td>
            <td><?=$v['create_time']?></td>
            <td><a href="<?php e_action("modify","id={$v['id']}")?>">回复</a></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
<?php echo $r['page']; ?>