<form action="<?php e_page("article","index");?>" method="get">
    <fieldset>
        <legend></legend>
        <label for="menu_idInput">文章分类</label>
        <select name="menu_id" id="menu_idInput">
            <option value='' selected>不属于分类</option>
            <?php foreach($r['menuMap'] as $k=>$v){?>
                <optgroup label="<?=$k?>">
                    <?php foreach($v as $subK=>$subV){?>
                        <option value="<?=$subK?>" <?php if(isset($r['menu_id'])&&($r['menu_id']==$subK)) echo 'selected'?>>
                            <?=$subV?></option>
                    <?php } ?>
                </optgroup>
            <?php }?>
        </select>
        <input type="submit">
    </fieldset></br>
</form>

<table id="dataTable">
    <thead>
    <tr>
        <th>ID</th>
        <th>所属分类</th>
        <th>标题</th>
        <th>发布人</th>
        <th>发布时间</th>
        <th>阅读次数</th>
        <th>点赞人数</th>
        <th>是否通过审核</th>
        <th>审核时间</th>
        <th>审核人</th>
        <th>操作</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($r['article_info'] as $v){?>
        <tr>
            <td><?php echo $v['id'];?></td>
            <td><?php echo mb_substr($r[$v['id']]['menu_type'],0,-1)?></td>
            <td><a target="_blank" href="<?php e_url("","article","content","id={$v['id']}")?>"><?php if(mb_strlen($v['title'])<10)
                    echo $v['title'];
                else{
                    echo mb_substr($v['title'],0,10,"UTF-8");
                    echo "...";
                }?></a>
            </td>
            <td><?php echo $v['owner']?></td>
            <td><?php echo substr($v['publish_time'],0,10);?></td>
            <td><?php echo $v['read_times']?></td>
            <td><?php echo $v['praise']?></td>
            <td>
                <?php if($v['enable']==0){ echo "未通过"?>
                <?php if($r['user_info']['type']=='admin'){?>
                    <a href="<?php e_action("changeEnable","id={$v['id']}&enable=1")?>">(确认通过)</a> <?php }?>
                <?php }else{ echo "已通过"?>
                <?php if($r['user_info']['type']=='admin'){?>
                    <a href="<?php e_action("changeEnable","id={$v['id']}&enable=0")?>">(拒绝通过)</a><?php }?>
                <?php }?>
            </td>
            <td><?php echo substr($v['auth_time'],0,10);?></td>
            <td><?php echo $v['auditor']?></td>
            <td><a href="<?php e_action("modify","id={$v['id']}")?>">编辑</a><?php if($v['type']!='system'){?> <a href="<?php e_action("delete","id={$v['id']}")?>" onclick="return confirm('确定删除吗？');">删除</a><?php }?></td>
            <td><a href="<?php e_page("receipt","table","condition[article_id]={$v['id']}")?>">查看回执</a></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
<?php echo $r['page']; ?>