<form action="<?php e_action("addUrlSubmit");?>" method="post" enctype="multipart/form-data">
    <fieldset>
        <legend>基本信息</legend>
        <label for="menu_idInput">所属分类</label>
        <select name="data[menu_id]" id="menu_idInput">
            <option value='' selected>不属于分类</option>
            <?php foreach($r['menuMap'] as $k=>$v){?>
                <optgroup label="<?=$k?>">
                    <?php foreach($v as $subK=>$subV){ ?>
                        <option value="<?=$subK?>">
                            <?=$subV?></option>
                    <?php } ?>
                </optgroup>
            <?php }?>
        </select><br/>
        <label for="title">标题</label>
        <input type="text" name="data[title]" id="title" placeholder="请输入文章标题"/><br/>
        <label for="article_url">文章链接</label>
        <input type="text" name="data[article_url]" id="article_url" placeholder="请输入文章链接"/><br/>
        <label for="pic_url">缩略图</label>
        <input type="file" name="pic_url" id="pic_url"/><br/>
    </fieldset>
    <input type="submit">
</form>