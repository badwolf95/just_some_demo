<form action="<?php e_action("modifySubmit"); ?>" method="post"  enctype="multipart/form-data">
    <fieldset>
        <legend>基本信息</legend>
        <input type="hidden" name="data[id]" id="id" value="<?=$r['article_info']['id']?>">
        <label for="menu_idInput">所属分类</label>
        <select name="data[menu_id]" id="menu_idInput">
            <option value='' selected>不属于分类</option>
            <?php foreach($r['menuMap'] as $k=>$v){?>
                <optgroup label="<?=$k?>">
                    <?php foreach($v as $subK=>$subV){ ?>
                        <option value="<?=$subK?>" <?php if($subK==$r['article_info']['menu_id']) echo 'selected'?>>
                            <?=$subV?></option>
                    <?php } ?>
                </optgroup>
            <?php }?>
        </select><br/>
        <label for="title">标题</label>
        <input type="text" name="data[title]" id="title" value="<?=$r['article_info']['title'];?>" placeholder="请输入文章标题"/><br/>
        <label for="publish_time">发布时间</label>
        <input type="date" name="data[publish_time]" id="publish_time" value="<?=$r['article_info']['publish_time'];?>" placeholder="请输入发布时间"/><br/>
        <label for="author_name">作者</label>
        <input type="text" name="data[author_name]" id="author_name" value="<?=$r['article_info']['author_name'];?>" placeholder="请输入作者"/><br/>
        <label for="pic_url">缩略图</label>
        <input type="file" name="pic_url" id="pic_url"/><br/>
        <img src="<?php echo $r['article_info']['pic_url'] ?>" alt="">
    </fieldset>
    <fieldset>
        <legend>文章内容</legend>
        <div class="likyh-module ueditor" data-likyh-module="ueditor">
            <script>
                ueditorController='<?php e_url("admin","ueditor","index");?>';
            </script>
            <script id="contentInput" name="data[content]" class="ueditor" type="text/plain"><?=isset($r['article_info']['content'])?$r['article_info']['content']:''?></script>
        </div>
    </fieldset>
    <input type="submit">
</form>