<table id="dataTable">
    <thead>
    <tr>
        <th>ID</th>
        <th>用户名</th>
        <th>昵称</th>
        <th>创建时间</th>
        <th>类型</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($r['admin_info'] as $v){?>
        <tr>
            <td><?php echo $v['id'];?></td>
            <td><?php echo $v['user'];?></td>
            <td><?php echo $v['nickname']?></td>
            <td><?php echo $v['create_time']?></td>
            <td><?php echo $v['type'];?></td>
<!--            <td><a href="--><?php //e_action("check","id={$v['id']}")?><!--">审核</a></td>-->
            <td>
                <?php if($v['enable']==0){ echo "未通过"?>
                    <a href="<?php e_action("changeEnable","id={$v['id']}&enable=1")?>">(确认通过)</a>
                <?php }else{ echo "已通过"?>
                    <a href="<?php e_action("changeEnable","id={$v['id']}&enable=0")?>">(拒绝通过)</a>
                <?php }?>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>
<?php echo $r['page']; ?>