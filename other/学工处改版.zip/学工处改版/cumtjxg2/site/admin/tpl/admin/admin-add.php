<form action="<?php e_action("addSubmit");?>" method="post" enctype="multipart/form-data">
    <fieldset>
        <legend>管理员信息</legend>
        <label for="username">用户名</label>
        <input type="text" id="username" name="username" placeholder="请输入管理员用户名"><br/>
        <label for="password">密码</label>
        <input type="password" id="password" name="password" placeholder="请输入管理员密码"><br/>
        <label for="nickname">昵称</label>
        <input type="text" id="nickname" name="nickname" placeholder="请输入昵称"><br/>
        <input type="submit" value="提交">
    </fieldset>
</form>