<form action="<?php e_action("modifyPasswordSubmit"); ?>" method="post"  enctype="multipart/form-data">
    <fieldset>
        <legend></legend>
        <label for="oldPassword">请输入旧密码</label>
        <input type="password" name="data[oldPassword]" id="oldPassword"  placeholder="请输入旧密码"/><br/>
        <label for="newPassword">请输入新密码</label>
        <input type="password" name="data[newPassword]" id="newPassword"  placeholder="请输入新密码"/><br/>
        <label for="repetPassword">请重新输入新密码</label>
        <input type="password" name="data[repetPassword]" id="repetPassword"  placeholder="请重新输入新密码"/><br/>
        <input type="submit" value="修改" />
    </fieldset>
</form>