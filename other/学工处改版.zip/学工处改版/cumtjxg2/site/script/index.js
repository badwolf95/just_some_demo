/**
 * Created by Administrator on 2015/8/18.
 */
$(document).ready(function() {

    // <div class="office">
    var $col = $('li.news-col');
    var $ul = $('.office ul');
    $col.mouseover(function(){
        var $this = $(this);
        var $t = $this.index();
        $col.removeClass('current');
        $this.addClass('current');
        $ul.css('display','none');
        $ul.eq($t).css('display','block');
    });

    // <div class="space">
    var $spacetab = $('.greek-tab h3');
    var $mul = $('.makerNews ul');
    $spacetab.mouseover(function(){
        var $this = $(this);
        var $n = $this.index();
        $spacetab.removeClass('current');
        $this.addClass('current');
        $mul.css('display','none');
        $mul.eq($n).css('display','block');
    });

    // <div class="plantform">
    var $buildtab = $('.build-tab h3');
    var $bul = $('.buildNews ul');
    $buildtab.mouseover(function(){
        var $this = $(this);
        var $n = $this.index();
        $buildtab.removeClass('current');
        $this.addClass('current');
        $bul.css('display','none');
        $bul.eq($n).css('display','block');
    });

    // <div class="classNews">
    var $classtab = $('.class-tab h3');
    var $cdul = $('.classDailyNews ul');
    $classtab.mouseover(function(){
        var $this = $(this);
        var $n = $this.index();
        $classtab.removeClass('current');
        $this.addClass('current');
        $cdul.css('display','none');
        $cdul.eq($n).css('display','block');
    });

    // <div class="departNews">
    var $manatab = $('.manage-tab h3');
    var $manaul = $('.managementNews ul');
    $manatab.mouseover(function(){
        var $this = $(this);
        var $n = $this.index();
        $manatab.removeClass('current');
        $this.addClass('current');
        $manaul.css('display','none');
        $manaul.eq($n).css('display','block');
    });

    // <div class="communistNews">
    var $youthtab = $('.youth-tab h3');
    var $youl = $('.youthNews ul');
    $youthtab.mouseover(function(){
        var $this = $(this);
        var $n = $this.index();
        $youthtab.removeClass('current');
        $this.addClass('current');
        $youl.css('display','none');
        $youl.eq($n).css('display','block');
    });

    //  banner
    var $pic = $('.banner-pic');
    var animateLock=false;
     var notCurrentWidth=(99.9-57.9)/($pic.length-1)-1+"%";
    tiggerBannerSlide($pic.eq(0));
    $pic.hover(function(){
        tiggerBannerSlide($(this))
    },function(){});
    function tiggerBannerSlide($this){
        //if(animateLock) return;
        animateLock=true;
        $pic.stop().not($this).animate({width:notCurrentWidth});
        $this.animate({width:"57.9%"},function(){
            $this.addClass('current');
            animateLock=false;
        });
    }
});