/**
 * Created by Administrator on 2015/8/18.
 */
$(document).ready(function() {
    //回执打开隐藏
    $(".receipt-wrapper").hide();
    $(".close").click(function(){
        $(".receipt-wrapper").css("display","none");
    });
    $(".send-receipt").click(function(){
        $(".receipt-wrapper").css("display","block");
        $("body").css({overflow:"hidden"});
    });
    $(".no-login-note").hide();

});