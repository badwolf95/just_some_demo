<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <base href="<?php echo $system['siteRoot'];?>" />
    <link rel="stylesheet" href="plugin/awesome/font-awesome.min.css"/>
    <link rel="stylesheet" href="plugin/reset.css"/>
    <link rel="stylesheet" href="style/index.css"/>
    <link rel="stylesheet" href="style/login.css"/>
    <script src="plugin/jquery-1.11.2.min.js"></script>
    <script src="script/login.js"></script>
</head>
<body>
<div class="container">
    <div class="main-container">
        <div class="wrapper">
            <div class="introduction">
                <h2 class="orange num5">怀旧</h2>
                <h2 class="cyan num6">创业孵化</h2>
                <h2 class="yellow num8">联谊预告</h2>
                <h3 class="blue num1">校友新闻</h3>
                <h3 class="blue num2">粤港深校友</h3>
                <h3 class="orange num3">名人校友</h3>
                <h4 class="orange num4">行业精英</h4>
                <h4 class="cyan num7">慈善救助</h4>
                <h4 class="yellow num9">校友联谊</h4>
            </div>
        </div>
    </div>
    <?php import_tpl("fragment/footer.php"); ?>
</div>

</body>
</html>