<?php
//echo "HelloWorld";
echo phpinfo();